import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Briefcase,
  Dumbbell,
  Film,
  Gamepad2,
  Globe,
  HeartPulse,
  Map as MapIcon,
  Music,
  Pause,
  Play,
  Sliders,
  UserPlus,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  CameraMode,
  ChatMessage,
  Club,
  ControllerMode,
  CreatedPlayerProfile,
  LeaderboardEntry,
  ManagerState,
  MatchHUDState,
  MatchHighlightSummary,
  MultiplayerRoom,
  Platform,
  PlayerInjury,
  ReplayHUDState,
  StadiumTheme,
  TrainingFocus,
  TreatmentProtocol,
} from './types/game';
import { createInitialClubs } from './data/leagues';
import { DEFAULT_CREATED_PLAYER } from './data/playerCustomization';
import {
  advanceManagerWeek,
  applyFastTrackRehab,
  applyTrainingToClub,
  createInitialManagerState,
  evaluateLiveTacticalSuggestion,
  getMedicalMetrics,
  insertCreatedPlayerIntoClub,
  pickBestLineup,
  reconcileFitLineup,
} from './state/managerEngine';
import { FootballEngine } from './game/FootballEngine';
import { soundEngine } from './audio/SoundEngine';
import {
  CloudSaveRecord,
  fetchCloudLeaderboard,
  loadCloudSaves,
  saveCareerToCloud,
  signInWithGoogle,
  signOutUser,
  subscribeAuth,
  syncCloudLeaderboard,
} from './firebase';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ManagerHub } from './components/ManagerHub';
import { CreatePlayerModal } from './components/CreatePlayerModal';
import { WorldMapModal } from './components/WorldMapModal';
import { MultiplayerChatModal } from './components/MultiplayerChatModal';
import { LiveTacticsDrawer } from './components/LiveTacticsDrawer';
import { LiveTacticalAIOverlay } from './components/LiveTacticalAIOverlay';
import { HighlightReelOverlay } from './components/HighlightReelOverlay';
import { EFootballControlsOverlay } from './components/EFootballControlsOverlay';

type GameScreen = 'title' | 'playing' | 'paused' | 'fulltime' | 'replay';
type ActiveModal =
  | null
  | 'manager'
  | 'create_player'
  | 'world_map'
  | 'multiplayer'
  | 'live_tactics';

const CAMERA_ORDER: CameraMode[] = ['broadcast', 'follow', 'pro_player', 'tactical'];

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<FootballEngine | null>(null);

  // Core Club & Manager State
  const [clubs, setClubs] = useState<Record<string, Club>>(() => createInitialClubs());
  const [manager, setManager] = useState<ManagerState>(() => {
    const initial = createInitialClubs();
    return createInitialManagerState('arsenal', initial, 'Alex Mercer');
  });
  const [awayClubId, setAwayClubId] = useState<string>('real_madrid');

  // Created Star Player
  const [createdPlayer, setCreatedPlayer] = useState<CreatedPlayerProfile>(() => ({
    ...DEFAULT_CREATED_PLAYER,
  }));

  // 3D Viewport & Match Settings
  const [screen, setScreen] = useState<GameScreen>('title');
  const [modal, setModal] = useState<ActiveModal>(null);
  const [playMode, setPlayMode] = useState<'match' | 'training_roam'>('match');
  const [stadiumTheme, setStadiumTheme] = useState<StadiumTheme>('night_floodlights');
  const [cameraMode, setCameraMode] = useState<CameraMode>('broadcast');
  const [playerLockToStar, setPlayerLockToStar] = useState<boolean>(false);
  const [controllerMode, setControllerMode] = useState<ControllerMode>('efootball_touch');
  const [muted, setMuted] = useState<boolean>(false);
  const [musicPlaying, setMusicPlaying] = useState<boolean>(false);
  const userStoppedMusicRef = useRef<boolean>(false);
  const [inGymBanner, setInGymBanner] = useState<boolean>(false);
  const [aiOverlayMinimized, setAiOverlayMinimized] = useState<boolean>(false);
  const [dismissedAiScenarioKey, setDismissedAiScenarioKey] = useState<string | null>(null);
  const [fullTimeScore, setFullTimeScore] = useState<{ home: number; away: number } | null>(null);
  const [matchHighlights, setMatchHighlights] = useState<MatchHighlightSummary[]>([]);
  const [replayState, setReplayState] = useState<ReplayHUDState>({
    active: false,
    highlightId: null,
    paused: false,
    speed: 1,
    camera: 'tv_broadcast',
    currentTime: 0,
    duration: 0,
    autoPlay: true,
  });
  const [platform, setPlatform] = useState<Platform>(() =>
    typeof window !== 'undefined' && window.innerWidth < 768 ? 'Mobile' : 'PC'
  );

  // Live HUD State updated at ~12Hz from FootballEngine
  const [hud, setHud] = useState<MatchHUDState>({
    homeName: 'ARS',
    awayName: 'RMA',
    homeColor: '#EF0107',
    awayColor: '#1E293B',
    homeScore: 0,
    awayScore: 0,
    matchMinute: 0,
    half: 1,
    shotPower: 0,
    activePlayerName: 'Alex Mercer',
    activePlayerNumber: 10,
    activePlayerStamina: 98,
    possessionHome: 50,
    teamHasPossession: 'home',
    goalBanner: null,
    injuryBanner: null,
    injuredPlayerCount: 0,
    mode: 'match',
    radarDots: [],
  });

  // WebSocket Multiplayer, Chat & WebRTC Voice State
  const wsRef = useRef<WebSocket | null>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const [peerId, setPeerId] = useState('');
  const [rooms, setRooms] = useState<MultiplayerRoom[]>([]);
  const [activeRoom, setActiveRoom] = useState<MultiplayerRoom | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [voiceActive, setVoiceActive] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const remoteAudiosRef = useRef<Map<string, HTMLAudioElement>>(new Map());

  // Firebase Auth & Cloud Saves
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [cloudSaves, setCloudSaves] = useState<CloudSaveRecord[]>([]);
  const [cloudStatus, setCloudStatus] = useState<string | null>(null);

  const homeClub = clubs[manager.clubId] || Object.values(clubs)[0];
  const awayClub = clubs[awayClubId] || clubs.real_madrid || Object.values(clubs)[1];
  const medicalMetrics = getMedicalMetrics(homeClub, manager);

  const liveTacticalSuggestion = useMemo(
    () =>
      evaluateLiveTacticalSuggestion({
        homeScore: hud.homeScore,
        awayScore: hud.awayScore,
        matchMinute: hud.matchMinute,
        possessionHome: hud.possessionHome,
        currentTactics: manager.tactics,
        opponentName: awayClub.shortName,
      }),
    [
      hud.homeScore,
      hud.awayScore,
      hud.matchMinute,
      hud.possessionHome,
      manager.tactics,
      awayClub.shortName,
    ]
  );

  const activeClubIdRef = useRef(manager.clubId);
  activeClubIdRef.current = manager.clubId;
  const clubsRef = useRef(clubs);
  clubsRef.current = clubs;

  // Live 3D Pitch / Training Injury Handler
  const handlePlayerInjury = useCallback((playerId: string, injury: PlayerInjury) => {
    const clubId = activeClubIdRef.current;
    const currentClub = clubsRef.current[clubId];
    const target = currentClub?.roster.find((p) => p.id === playerId);
    if (!currentClub || !target) return;

    const updatedRoster = currentClub.roster.map((p) =>
      p.id === playerId ? { ...p, injury } : p
    );

    setClubs((prev) => {
      const c = prev[clubId];
      if (!c) return prev;
      return {
        ...prev,
        [clubId]: {
          ...c,
          roster: c.roster.map((p) => (p.id === playerId ? { ...p, injury } : p)),
        },
      };
    });

    setManager((prev) => {
      const reconciled = reconcileFitLineup(updatedRoster, prev.startingXIIds, prev.benchIds);
      return {
        ...prev,
        ...reconciled,
        injuryReportLog: [
          {
            id: `inj_live_${playerId}_${prev.currentWeek}_${Date.now()}`,
            week: prev.currentWeek,
            playerId,
            playerName: target.name,
            injuryType: injury.type,
            severity: injury.severity,
            source: injury.source,
            event: 'Injured' as const,
            weeksOut: injury.weeksRemaining,
          },
          ...(prev.injuryReportLog || []),
        ].slice(0, 25),
      };
    });
  }, []);

  // Match End Handler
  const handleMatchEnd = useCallback(
    (homeScore: number, awayScore: number) => {
      setFullTimeScore({ home: homeScore, away: awayScore });
      setMatchHighlights(engineRef.current?.getMatchHighlights() || []);
      setScreen('fulltime');
      setClubs((prevClubs) => {
        const res = advanceManagerWeek(prevClubs, manager, {
          homeGoals: homeScore,
          awayGoals: awayScore,
        });
        setManager(res.manager);

        // Sync result to server leaderboard
        const won = homeScore > awayScore ? 1 : 0;
        const draw = homeScore === awayScore ? 1 : 0;
        const loss = homeScore < awayScore ? 1 : 0;
        const elo = 1400 + res.manager.careerStats.wins * 25 - res.manager.careerStats.losses * 15;
        void fetch('/api/leaderboard', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: firebaseUser?.uid || peerId || 'local_manager',
            managerName: res.manager.managerName,
            clubName: prevClubs[res.manager.clubId]?.name || 'Club',
            clubColor: prevClubs[res.manager.clubId]?.homeKit.primary || '#10B981',
            platform,
            eloRating: elo,
            wins: res.manager.careerStats.wins + won,
            draws: res.manager.careerStats.draws + draw,
            losses: res.manager.careerStats.losses + loss,
            goalsScored: res.manager.careerStats.goalsFor + homeScore,
            trophiesWon: res.manager.trophies.length,
          }),
        }).catch(() => {});

        return res.clubs;
      });
    },
    [manager, firebaseUser, peerId, platform]
  );

  // Mount Three.js FootballEngine once inside dedicated container
  useEffect(() => {
    const mountEl = canvasMountRef.current;
    if (!mountEl) return;

    const engine = new FootballEngine(mountEl, {
      homeClub,
      awayClub,
      createdPlayer,
      tactics: manager.tactics,
      startingXIIds: manager.startingXIIds,
      injuryPreventionPct: medicalMetrics.injuryPreventionPct,
      currentWeek: manager.currentWeek,
      stadiumTheme,
      cameraMode,
      mode: 'title_showcase',
      playerLockToStar,
      onHUDUpdate: setHud,
      onMatchEnd: handleMatchEnd,
      onPlayerInjury: handlePlayerInjury,
      onGymZoneEnter: setInGymBanner,
      onHighlightsChange: setMatchHighlights,
      onReplayUpdate: setReplayState,
    });
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // Intentionally mounted once; config updates propagate via updateConfig()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Synchronize engine config whenever match/tactics/camera/mode changes
  useEffect(() => {
    const engine = engineRef.current;
    if (!engine) return;
    const engineMode =
      screen === 'title'
        ? 'title_showcase'
        : playMode === 'training_roam'
          ? 'training_roam'
          : 'match';

    engine.updateConfig({
      homeClub,
      awayClub,
      createdPlayer,
      tactics: manager.tactics,
      startingXIIds: manager.startingXIIds,
      injuryPreventionPct: medicalMetrics.injuryPreventionPct,
      currentWeek: manager.currentWeek,
      stadiumTheme,
      cameraMode,
      mode: engineMode,
      playerLockToStar,
      onMatchEnd: handleMatchEnd,
      onPlayerInjury: handlePlayerInjury,
      onGymZoneEnter: setInGymBanner,
      onHighlightsChange: setMatchHighlights,
      onReplayUpdate: setReplayState,
    });
    engine.setPaused(screen === 'paused' || screen === 'fulltime' || modal !== null);
  }, [
    homeClub,
    awayClub,
    createdPlayer,
    manager.tactics,
    manager.startingXIIds,
    manager.currentWeek,
    medicalMetrics.injuryPreventionPct,
    stadiumTheme,
    cameraMode,
    screen,
    playMode,
    playerLockToStar,
    modal,
    handleMatchEnd,
    handlePlayerInjury,
  ]);

  // Kuami Eugene Soundtrack Auto-Start on Entry & Interaction
  useEffect(() => {
    const unsubMusic = soundEngine.subscribeMusicState(setMusicPlaying);
    soundEngine.startKuamiEugeneSong();

    const unlockSong = () => {
      if (!userStoppedMusicRef.current && !soundEngine.isMusicPlaying()) {
        soundEngine.startKuamiEugeneSong();
      }
    };
    window.addEventListener('pointerdown', unlockSong, { passive: true });
    window.addEventListener('keydown', unlockSong, { passive: true });

    return () => {
      unsubMusic();
      window.removeEventListener('pointerdown', unlockSong);
      window.removeEventListener('keydown', unlockSong);
    };
  }, []);

  useEffect(() => {
    soundEngine.setMusicDuck(screen === 'playing' || screen === 'replay');
  }, [screen]);

  const handleToggleKuamiSong = useCallback(() => {
    const nowPlaying = soundEngine.toggleMusic();
    userStoppedMusicRef.current = !nowPlaying;
  }, []);

  // Global Keyboard Shortcuts (Enter on Title, C Camera, M Mute, Esc Pause)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
        return;
      }

      if (screen === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
        e.preventDefault();
        setPlayMode('match');
        setDismissedAiScenarioKey(null);
        setScreen('playing');
        soundEngine.playWhistle('kickoff');
        if (!userStoppedMusicRef.current) {
          soundEngine.startKuamiEugeneSong();
        }
        return;
      }

      if (screen === 'replay' && e.code === 'Space') {
        e.preventDefault();
        engineRef.current?.setReplayOptions({ paused: !replayState.paused });
        return;
      }

      if (e.code === 'Escape') {
        if (modal) {
          setModal(null);
        } else if (screen === 'replay') {
          engineRef.current?.stopHighlightReplay();
          setScreen('fulltime');
        } else if (screen === 'playing') {
          setScreen('paused');
        } else if (screen === 'paused') {
          setScreen('playing');
        }
      } else if (e.code === 'KeyC' && screen === 'playing' && !modal) {
        setCameraMode((prev) => {
          const idx = CAMERA_ORDER.indexOf(prev);
          return CAMERA_ORDER[(idx + 1) % CAMERA_ORDER.length];
        });
      } else if (e.code === 'KeyM') {
        setMuted((prev) => {
          soundEngine.setMuted(!prev);
          return !prev;
        });
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [screen, modal, replayState.paused]);

  // Firebase Auth Subscription & Cloud Data Load
  useEffect(() => {
    const unsub = subscribeAuth(async (user) => {
      setFirebaseUser(user);
      if (user) {
        try {
          const saves = await loadCloudSaves(user.uid);
          setCloudSaves(saves);
        } catch (err) {
          console.error('Cloud saves load failed:', err);
        }
      } else {
        setCloudSaves([]);
      }
    });
    return () => unsub();
  }, []);

  // Load Leaderboards (Server + Firestore merged)
  const refreshLeaderboard = useCallback(async () => {
    try {
      const [serverRes, cloudEntries] = await Promise.all([
        fetch('/api/leaderboard').then((r) => r.json()).catch(() => ({ entries: [] })),
        fetchCloudLeaderboard().catch(() => [] as LeaderboardEntry[]),
      ]);
      const merged = new Map<string, LeaderboardEntry>();
      for (const e of serverRes.entries || []) merged.set(e.id, e);
      for (const e of cloudEntries) merged.set(e.id, e);
      setLeaderboard(
        Array.from(merged.values()).sort((a, b) => b.eloRating - a.eloRating)
      );
    } catch {
      // ignore transient leaderboard errors
    }
  }, []);

  useEffect(() => {
    void refreshLeaderboard();
  }, [refreshLeaderboard]);

  // WebRTC Peer Connection Helpers
  const createRTCPeer = useCallback(
    (targetPeerId: string, initiator: boolean) => {
      const existing = peerConnsRef.current.get(targetPeerId);
      if (existing) return existing;

      const pc = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
      });

      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => {
          pc.addTrack(track, localStreamRef.current!);
        });
      }

      pc.onicecandidate = (ev) => {
        if (ev.candidate && wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(
            JSON.stringify({
              type: 'voice:signal',
              targetPeerId,
              signal: { candidate: ev.candidate },
            })
          );
        }
      };

      pc.ontrack = (ev) => {
        let audio = remoteAudiosRef.current.get(targetPeerId);
        if (!audio) {
          audio = new Audio();
          audio.autoplay = true;
          remoteAudiosRef.current.set(targetPeerId, audio);
        }
        audio.srcObject = ev.streams[0];
      };

      peerConnsRef.current.set(targetPeerId, pc);

      if (initiator) {
        void pc.createOffer().then(async (offer) => {
          await pc.setLocalDescription(offer);
          wsRef.current?.send(
            JSON.stringify({
              type: 'voice:signal',
              targetPeerId,
              signal: { sdp: pc.localDescription },
            })
          );
        });
      }
      return pc;
    },
    []
  );

  // WebSocket Multiplayer & Chat Connection
  useEffect(() => {
    let reconnectTimer = 0;
    let closedByUnmount = false;

    const connect = () => {
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => setWsConnected(true);

      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(String(event.data));
          if (msg.type === 'connected') {
            setPeerId(msg.peerId);
            setRooms(msg.rooms || []);
            setChatMessages(msg.chatHistory || []);
          } else if (msg.type === 'rooms:list') {
            setRooms(msg.rooms || []);
          } else if (msg.type === 'room:joined' || msg.type === 'room:updated') {
            setActiveRoom(msg.room);
          } else if (msg.type === 'room:left') {
            setActiveRoom(null);
          } else if (msg.type === 'chat:message') {
            setChatMessages((prev) => [...prev.slice(-79), msg.message]);
          } else if (msg.type === 'leaderboard:update') {
            setLeaderboard(msg.entries || []);
          } else if (msg.type === 'match:snapshot') {
            engineRef.current?.applyRemoteSnapshot(msg.snapshot);
          } else if (msg.type === 'voice:peer-ready' && voiceActive) {
            createRTCPeer(msg.peerId, true);
          } else if (msg.type === 'voice:signal') {
            const pc = createRTCPeer(msg.fromPeerId, false);
            if (msg.signal?.sdp) {
              await pc.setRemoteDescription(new RTCSessionDescription(msg.signal.sdp));
              if (msg.signal.sdp.type === 'offer') {
                const answer = await pc.createAnswer();
                await pc.setLocalDescription(answer);
                ws.send(
                  JSON.stringify({
                    type: 'voice:signal',
                    targetPeerId: msg.fromPeerId,
                    signal: { sdp: pc.localDescription },
                  })
                );
              }
            } else if (msg.signal?.candidate) {
              await pc.addIceCandidate(new RTCIceCandidate(msg.signal.candidate));
            }
          }
        } catch {
          // ignore malformed messages
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!closedByUnmount) {
          reconnectTimer = window.setTimeout(connect, 2500);
        }
      };
    };

    connect();
    return () => {
      closedByUnmount = true;
      clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [createRTCPeer, voiceActive]);

  // Periodically sync host snapshot when in a live multiplayer match
  useEffect(() => {
    if (!activeRoom || screen !== 'playing' || activeRoom.hostId !== peerId) return;
    const timer = window.setInterval(() => {
      const snap = engineRef.current?.getMultiplayerSnapshot();
      if (snap && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'match:snapshot',
            snapshot: snap,
            scoreHome: snap.homeScore,
            scoreAway: snap.awayScore,
          })
        );
      }
    }, 100);
    return () => clearInterval(timer);
  }, [activeRoom, screen, peerId]);

  const toggleVoiceChat = async () => {
    setVoiceError(null);
    if (voiceActive) {
      localStreamRef.current?.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
      peerConnsRef.current.forEach((pc) => pc.close());
      peerConnsRef.current.clear();
      setVoiceActive(false);
      wsRef.current?.send(JSON.stringify({ type: 'voice:status', enabled: false }));
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      localStreamRef.current = stream;
      setVoiceActive(true);
      wsRef.current?.send(JSON.stringify({ type: 'voice:status', enabled: true }));
    } catch {
      setVoiceError('Microphone permission denied or unavailable.');
    }
  };

  // Manager Mode Handlers
  const handleSelectClub = (clubId: string) => {
    const newManager = createInitialManagerState(clubId, clubs, createdPlayer.name);
    setManager(newManager);
    // Pick an exciting rival as away club
    const rival = Object.values(clubs).find((c) => c.id !== clubId);
    if (rival) setAwayClubId(rival.id);
  };

  const handleUpdateTactics = (nextTactics: ManagerState['tactics']) => {
    setManager((prev) => {
      if (prev.tactics.formation !== nextTactics.formation) {
        const picked = pickBestLineup(homeClub.roster, nextTactics.formation);
        return { ...prev, tactics: nextTactics, ...picked };
      }
      return { ...prev, tactics: nextTactics };
    });
  };

  const handleSwapPlayers = (starterId: string, benchId: string) => {
    const benchPlayer = homeClub.roster.find((p) => p.id === benchId);
    if (benchPlayer?.injury) return;
    setManager((prev) => {
      const nextXI = prev.startingXIIds.map((id) => (id === starterId ? benchId : id));
      const nextBench = prev.benchIds.map((id) => (id === benchId ? starterId : id));
      return { ...prev, startingXIIds: nextXI, benchIds: nextBench };
    });
  };

  const handleBuyPlayer = (sellerClubId: string, playerId: string) => {
    const seller = clubs[sellerClubId];
    const buyer = clubs[manager.clubId];
    const player = seller?.roster.find((p) => p.id === playerId);
    if (!seller || !buyer || !player) return;
    if (buyer.transferBudget < player.marketValue || buyer.roster.length >= 28) return;

    setClubs((prev) => ({
      ...prev,
      [buyer.id]: {
        ...prev[buyer.id],
        transferBudget: prev[buyer.id].transferBudget - player.marketValue,
        roster: [...prev[buyer.id].roster, player],
      },
      [seller.id]: {
        ...prev[seller.id],
        transferBudget: prev[seller.id].transferBudget + player.marketValue,
        roster: prev[seller.id].roster.filter((p) => p.id !== playerId),
      },
    }));

    setManager((prev) => ({
      ...prev,
      benchIds: [...prev.benchIds, player.id],
      ledger: [
        {
          id: `buy_${Date.now()}`,
          week: prev.currentWeek,
          category: 'Transfer',
          description: `Signed ${player.name} from ${seller.shortName}`,
          amount: -player.marketValue,
        },
        ...prev.ledger,
      ],
    }));
  };

  const handleSellPlayer = (playerId: string) => {
    const club = clubs[manager.clubId];
    const player = club?.roster.find((p) => p.id === playerId);
    if (!club || !player || club.roster.length <= 13 || player.isCreatedStar) return;

    setClubs((prev) => ({
      ...prev,
      [club.id]: {
        ...prev[club.id],
        transferBudget: prev[club.id].transferBudget + player.marketValue,
        roster: prev[club.id].roster.filter((p) => p.id !== playerId),
      },
    }));

    setManager((prev) => {
      const remaining = club.roster.filter((p) => p.id !== playerId);
      const picked = pickBestLineup(remaining, prev.tactics.formation);
      return {
        ...prev,
        ...picked,
        ledger: [
          {
            id: `sell_${Date.now()}`,
            week: prev.currentWeek,
            category: 'Transfer',
            description: `Sold ${player.name} (${player.ovr} OVR)`,
            amount: player.marketValue,
          },
          ...prev.ledger,
        ],
      };
    });
  };

  const handleUpgradeFacility = (facility: 'stadium' | 'gym' | 'medical') => {
    const club = clubs[manager.clubId];
    if (!club) return;
    const medicalTier = club.medicalTier || 1;
    const cost =
      facility === 'stadium'
        ? club.stadiumTier * 18_000_000
        : facility === 'gym'
          ? club.gymTier * 10_000_000
          : medicalTier * 12_000_000;
    const tier =
      facility === 'stadium'
        ? club.stadiumTier
        : facility === 'gym'
          ? club.gymTier
          : medicalTier;
    if (tier >= 5 || club.transferBudget < cost) return;

    setClubs((prev) => ({
      ...prev,
      [club.id]: {
        ...prev[club.id],
        transferBudget: prev[club.id].transferBudget - cost,
        stadiumTier: facility === 'stadium' ? club.stadiumTier + 1 : club.stadiumTier,
        stadiumCapacity:
          facility === 'stadium'
            ? Math.round(club.stadiumCapacity * 1.15)
            : club.stadiumCapacity,
        gymTier: facility === 'gym' ? club.gymTier + 1 : club.gymTier,
        medicalTier: facility === 'medical' ? medicalTier + 1 : medicalTier,
      },
    }));

    setManager((prev) => ({
      ...prev,
      ledger: [
        {
          id: `fac_${Date.now()}`,
          week: prev.currentWeek,
          category: facility === 'medical' ? 'Medical' : 'Facility',
          description:
            facility === 'stadium'
              ? `Expanded ${club.stadiumName} (Tier ${club.stadiumTier + 1})`
              : facility === 'gym'
                ? `Upgraded ${club.gymName} (Tier ${club.gymTier + 1})`
                : `Upgraded Club Medical Center (Tier ${medicalTier + 1})`,
          amount: -cost,
        },
        ...prev.ledger,
      ],
    }));
  };

  const handleToggleMedicalStaff = (staffId: string) => {
    const staff = manager.medicalStaff.find((s) => s.id === staffId);
    const club = clubs[manager.clubId];
    if (!staff || !club) return;

    if (!staff.hired) {
      if (club.transferBudget < staff.hireCost) return;
      setClubs((prev) => ({
        ...prev,
        [club.id]: {
          ...prev[club.id],
          transferBudget: prev[club.id].transferBudget - staff.hireCost,
        },
      }));
      setManager((prev) => ({
        ...prev,
        medicalStaff: prev.medicalStaff.map((s) =>
          s.id === staffId ? { ...s, hired: true } : s
        ),
        ledger: [
          {
            id: `med_hire_${Date.now()}`,
            week: prev.currentWeek,
            category: 'Medical',
            description: `Hired ${staff.name} (${staff.role})`,
            amount: -staff.hireCost,
          },
          ...prev.ledger,
        ],
      }));
    } else {
      setManager((prev) => ({
        ...prev,
        medicalStaff: prev.medicalStaff.map((s) =>
          s.id === staffId ? { ...s, hired: false } : s
        ),
      }));
    }
  };

  const handleSetMedicalProtocol = (protocol: TreatmentProtocol) => {
    setManager((prev) => ({ ...prev, medicalProtocol: protocol }));
  };

  const handleFastTrackRehab = (playerId: string) => {
    const FAST_TRACK_COST = 350_000;
    const club = clubs[manager.clubId];
    const target = club?.roster.find((p) => p.id === playerId);
    if (!club || !target?.injury || club.transferBudget < FAST_TRACK_COST) return;

    const priorInjury = target.injury;
    const res = applyFastTrackRehab(club, playerId, manager.currentWeek);
    setClubs((prev) => ({
      ...prev,
      [club.id]: {
        ...res.club,
        transferBudget: res.club.transferBudget - FAST_TRACK_COST,
      },
    }));

    setManager((prev) => {
      const reconciled = res.recovered
        ? reconcileFitLineup(res.club.roster, prev.startingXIIds, prev.benchIds)
        : { startingXIIds: prev.startingXIIds, benchIds: prev.benchIds };
      return {
        ...prev,
        ...reconciled,
        injuryReportLog: res.recovered
          ? [
              {
                id: `rec_ft_${playerId}_${prev.currentWeek}_${Date.now()}`,
                week: prev.currentWeek,
                playerId,
                playerName: res.playerName,
                injuryType: priorInjury.type,
                severity: priorInjury.severity,
                source: priorInjury.source,
                event: 'Recovered' as const,
              },
              ...(prev.injuryReportLog || []),
            ].slice(0, 25)
          : prev.injuryReportLog,
        ledger: [
          {
            id: `ft_${Date.now()}`,
            week: prev.currentWeek,
            category: 'Medical',
            description: `Fast-Track Rehab (${res.playerName})`,
            amount: -FAST_TRACK_COST,
          },
          ...prev.ledger,
        ],
      };
    });
  };

  const handleRunTrainingSession = () => {
    const club = clubs[manager.clubId];
    if (!club) return;
    const { club: trainedClub, events } = applyTrainingToClub(
      club,
      manager.teamTrainingFocus,
      manager,
      manager.currentWeek
    );
    setClubs((prev) => ({ ...prev, [club.id]: trainedClub }));
    setManager((prev) => {
      const reconciled = reconcileFitLineup(
        trainedClub.roster,
        prev.startingXIIds,
        prev.benchIds
      );
      return {
        ...prev,
        ...reconciled,
        injuryReportLog:
          events.length > 0
            ? [...events, ...(prev.injuryReportLog || [])].slice(0, 25)
            : prev.injuryReportLog,
      };
    });
  };

  const handleSimulateWeek = () => {
    setClubs((prevClubs) => {
      const res = advanceManagerWeek(prevClubs, manager);
      setManager(res.manager);
      return res.clubs;
    });
  };

  const handlePlayNextMatch = () => {
    const nextFix = manager.fixtures.find(
      (f) =>
        f.week === manager.currentWeek &&
        !f.played &&
        (f.homeClubId === manager.clubId || f.awayClubId === manager.clubId)
    );
    if (nextFix) {
      const oppId =
        nextFix.homeClubId === manager.clubId ? nextFix.awayClubId : nextFix.homeClubId;
      setAwayClubId(oppId);
    }
    setPlayMode('match');
    if (stadiumTheme === 'training_gym') setStadiumTheme('night_floodlights');
    setModal(null);
    setDismissedAiScenarioKey(null);
    setScreen('playing');
    engineRef.current?.resetMatchState();
    soundEngine.playWhistle('kickoff');
    if (!userStoppedMusicRef.current) {
      soundEngine.startKuamiEugeneSong();
    }
  };

  const handleEnterTrainingGym = (clubIdOverride?: string) => {
    if (clubIdOverride && clubIdOverride !== manager.clubId) {
      handleSelectClub(clubIdOverride);
    }
    setPlayMode('training_roam');
    setStadiumTheme('training_gym');
    setCameraMode('follow');
    setModal(null);
    setScreen('playing');
    if (!userStoppedMusicRef.current) {
      soundEngine.startKuamiEugeneSong();
    }
  };

  const handleSaveStarToSquad = () => {
    const res = insertCreatedPlayerIntoClub(homeClub, createdPlayer, manager);
    setClubs((prev) => ({ ...prev, [homeClub.id]: res.club }));
    setManager(res.manager);
    setPlayerLockToStar(true);
    setModal(null);
  };

  // Cloud Save Handlers
  const handleSaveToCloud = async (slotName: string) => {
    if (!firebaseUser) return;
    try {
      setCloudStatus('Syncing cross-platform career to Firestore...');
      const saveId = `slot_${manager.clubId}`;
      const injuredSummary = homeClub.roster
        .filter((p) => Boolean(p.injury))
        .map((p) => {
          const inj = p.injury!;
          return `${p.id}|${inj.type}|${inj.severity}|${inj.weeksRemaining}|${inj.initialWeeks}|${inj.recoveryProgress}|${inj.source}|${inj.occurredWeek}`;
        });

      await saveCareerToCloud({
        uid: firebaseUser.uid,
        displayName: firebaseUser.displayName || createdPlayer.name,
        saveId,
        slotName,
        platform,
        manager,
        transferBudget: homeClub.transferBudget,
        wageBudget: homeClub.wageBudget,
        stadiumTier: homeClub.stadiumTier,
        gymTier: homeClub.gymTier,
        medicalTier: homeClub.medicalTier || 1,
        injuredSummary,
        squadIds: homeClub.roster.map((p) => p.id),
        createdPlayer,
      });

      const elo =
        1400 + manager.careerStats.wins * 25 - manager.careerStats.losses * 15;
      await syncCloudLeaderboard({
        uid: firebaseUser.uid,
        managerName: firebaseUser.displayName || createdPlayer.name,
        clubName: homeClub.name,
        clubColor: homeClub.homeKit.primary,
        platform,
        eloRating: elo,
        wins: manager.careerStats.wins,
        draws: manager.careerStats.draws,
        losses: manager.careerStats.losses,
        goalsScored: manager.careerStats.goalsFor,
        trophiesWon: manager.trophies.length,
      });

      const saves = await loadCloudSaves(firebaseUser.uid);
      setCloudSaves(saves);
      await refreshLeaderboard();
      setCloudStatus(`Synced "${slotName}" from ${platform} — ready on Mobile, Console, and PC.`);
    } catch (err) {
      setCloudStatus(err instanceof Error ? err.message : 'Cloud sync failed.');
    }
  };

  const handleLoadCloudSave = (save: CloudSaveRecord) => {
    const nextClubs = createInitialClubs();
    if (nextClubs[save.clubId]) {
      nextClubs[save.clubId].transferBudget = save.transferBudget;
      nextClubs[save.clubId].wageBudget = save.wageBudget;
      nextClubs[save.clubId].stadiumTier = save.stadiumLevel;
      nextClubs[save.clubId].gymTier = save.gymLevel;
      nextClubs[save.clubId].medicalTier = save.medicalLevel ?? 1;

      if (save.injuredSummary && save.injuredSummary.length > 0) {
        const injuryByPlayerId = new Map<string, PlayerInjury>();
        for (const item of save.injuredSummary) {
          const [pid, type, severity, weeksRem, initWeeks, progress, source, occWeek] =
            item.split('|');
          if (pid && type && severity) {
            injuryByPlayerId.set(pid, {
              type: type as PlayerInjury['type'],
              severity: severity as PlayerInjury['severity'],
              weeksRemaining: Math.max(1, Number(weeksRem) || 1),
              initialWeeks: Math.max(1, Number(initWeeks) || 1),
              recoveryProgress: Math.max(0, Math.min(99, Number(progress) || 0)),
              source: source === 'Training' ? 'Training' : 'Match',
              occurredWeek: Math.max(1, Number(occWeek) || 1),
            });
          }
        }
        nextClubs[save.clubId].roster = nextClubs[save.clubId].roster.map((p) => ({
          ...p,
          injury: injuryByPlayerId.get(p.id) ?? null,
        }));
      }
    }
    setClubs(nextClubs);
    setCreatedPlayer((prev) => ({
      ...prev,
      ...save.createdPlayer,
      secondaryPosition: save.createdPlayer.secondaryPosition ?? null,
      traits: save.createdPlayer.traits ?? prev.traits,
    }));
    const restoredManager = createInitialManagerState(
      save.clubId,
      nextClubs,
      save.createdPlayer.name
    );
    restoredManager.seasonNumber = save.seasonNumber;
    restoredManager.currentWeek = save.currentWeek;
    restoredManager.trophies = save.trophies;
    restoredManager.careerStats = save.careerStats;
    restoredManager.medicalProtocol = save.medicalProtocol ?? 'Standard Care';
    if (Array.isArray(save.hiredMedicalIds)) {
      restoredManager.medicalStaff = restoredManager.medicalStaff.map((s) => ({
        ...s,
        hired: save.hiredMedicalIds!.includes(s.id),
      }));
    }
    restoredManager.tactics = {
      ...restoredManager.tactics,
      formation: save.formation,
      mentality: save.mentality,
      pressing: save.pressing,
      passingStyle: save.passingStyle,
    };
    if (nextClubs[save.clubId]) {
      const reconciled = reconcileFitLineup(
        nextClubs[save.clubId].roster,
        restoredManager.startingXIIds,
        restoredManager.benchIds
      );
      restoredManager.startingXIIds = reconciled.startingXIIds;
      restoredManager.benchIds = reconciled.benchIds;
    }
    setManager(restoredManager);
    setCloudStatus(`Loaded "${save.slotName}" (originally saved on ${save.platform}).`);
  };

  return (
    <ErrorBoundary>
      <div className="relative w-screen h-screen overflow-hidden bg-[#070B12] select-none">
        {/* Isolated 3D WebGL Viewport Container */}
        <div ref={canvasMountRef} className="fixed inset-0 z-0" />

        {/* ==================== TITLE SCREEN ==================== */}
        {screen === 'title' && (
          <div className="fixed inset-0 z-10 flex flex-col justify-between p-6 md:p-12 pointer-events-none">
            {/* Subtle top bar: active club, Kuami Eugene song & quick sound toggle */}
            <div className="flex items-center justify-between gap-2 pointer-events-auto">
              <div className="text-xs font-medium text-slate-300 bg-[#0B111B]/90 border border-white/10 rounded-lg px-3.5 py-2">
                {homeClub.name} · {homeClub.stadiumName} · {platform}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleToggleKuamiSong}
                  className={`inline-flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-semibold transition-colors ${
                    musicPlaying && !muted
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300'
                      : 'bg-[#0B111B]/90 border-white/10 text-slate-300 hover:text-white'
                  }`}
                  title="Toggle Kuami Eugene Highlife Anthem"
                >
                  <Music className="w-3.5 h-3.5" />
                  <span>Kuami Eugene Mix</span>
                </button>
                <button
                  onClick={() => {
                    const next = !muted;
                    setMuted(next);
                    soundEngine.setMuted(next);
                  }}
                  className="p-2.5 rounded-lg bg-[#0B111B]/90 border border-white/10 text-slate-200 hover:text-white transition-colors"
                  aria-label="Toggle Audio"
                >
                  {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Hero Lockup over negative space */}
            <div className="max-w-7xl w-full space-y-6 pointer-events-auto my-auto">
              {/* Bespoke Inline SVG Championship Lockup */}
              <div className="flex items-center gap-4">
                <svg
                  width="64"
                  height="72"
                  viewBox="0 0 64 72"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden="true"
                >
                  <path
                    d="M32 3L59 13V34C59 50.5 47.4 63.6 32 69C16.6 63.6 5 50.5 5 34V13L32 3Z"
                    fill="#0B111B"
                    stroke="#10B981"
                    strokeWidth="2.5"
                  />
                  <path
                    d="M32 11L51 18V33.5C51 45.8 42.8 55.8 32 60.2C21.2 55.8 13 45.8 13 33.5V18L32 11Z"
                    fill="#111927"
                    stroke="rgba(255,255,255,0.18)"
                    strokeWidth="1.2"
                  />
                  <circle cx="32" cy="34" r="10" stroke="#F8FAFC" strokeWidth="2" />
                  <polygon points="32,26 37,31 35,38 29,38 27,31" fill="#10B981" />
                </svg>
                <div>
                  <p className="text-xs font-semibold tracking-[0.22em] text-emerald-400 uppercase">
                    Championship Football · eFootball Controls
                  </p>
                  <h1 className="font-display text-5xl md:text-7xl font-extrabold tracking-tight text-white leading-none">
                    ATADWE MOBILE
                  </h1>
                </div>
              </div>

              <p className="text-sm md:text-base text-slate-200 max-w-xl leading-relaxed">
                Authentic 3D pitch realism under stadium floodlights, eFootball analog &amp; 4-button action controls, Kuami Eugene Highlife matchday anthem, 30 licensed clubs with gyms, Manager Mode, and cross-platform multiplayer.
              </p>

              {/* Big Single-Line Action Bar: Kick Off to Multiplayer */}
              <div className="flex flex-nowrap items-stretch gap-3 overflow-x-auto pb-1">
                <button
                  onClick={() => {
                    setPlayMode('match');
                    setDismissedAiScenarioKey(null);
                    setScreen('playing');
                    engineRef.current?.resetMatchState();
                    soundEngine.playWhistle('kickoff');
                    if (!userStoppedMusicRef.current) {
                      soundEngine.startKuamiEugeneSong();
                    }
                  }}
                  className="inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-xl bg-emerald-500 text-slate-950 font-display text-lg md:text-xl font-extrabold tracking-wide hover:bg-emerald-400 transition-colors shadow-lg whitespace-nowrap shrink-0"
                >
                  <Play className="w-5 h-5 fill-current" />
                  Kick Off 3D Match
                </button>
                <button
                  onClick={() => setModal('manager')}
                  className="inline-flex items-center justify-center gap-2.5 px-5 py-4 rounded-xl bg-[#0B111B]/95 border border-white/15 text-white text-sm md:text-base font-bold hover:bg-white/10 transition-colors shadow-lg whitespace-nowrap shrink-0"
                >
                  <Briefcase className="w-5 h-5 text-emerald-400" />
                  Manager Mode
                </button>
                <button
                  onClick={() => setModal('create_player')}
                  className="inline-flex items-center justify-center gap-2.5 px-5 py-4 rounded-xl bg-[#0B111B]/95 border border-white/15 text-slate-100 text-sm md:text-base font-bold hover:border-emerald-400/60 transition-colors shadow-lg whitespace-nowrap shrink-0"
                >
                  <UserPlus className="w-5 h-5 text-sky-400" />
                  Create Player &amp; Gym
                </button>
                <button
                  onClick={() => setModal('world_map')}
                  className="inline-flex items-center justify-center gap-2.5 px-5 py-4 rounded-xl bg-[#0B111B]/95 border border-white/15 text-slate-100 text-sm md:text-base font-bold hover:border-emerald-400/60 transition-colors shadow-lg whitespace-nowrap shrink-0"
                >
                  <MapIcon className="w-5 h-5 text-amber-400" />
                  League &amp; Stadium Maps
                </button>
                <button
                  onClick={() => setModal('multiplayer')}
                  className="inline-flex items-center justify-center gap-2.5 px-5 py-4 rounded-xl bg-[#0B111B]/95 border border-white/15 text-slate-100 text-sm md:text-base font-bold hover:border-emerald-400/60 transition-colors shadow-lg whitespace-nowrap shrink-0"
                >
                  <Globe className="w-5 h-5 text-emerald-400" />
                  Multiplayer · Voice · Cloud
                </button>
              </div>
            </div>

            {/* Single Flat Control-Hint Line */}
            <div className="text-xs text-slate-300 font-medium tracking-wide">
              eFootball Stick / WASD Move · Dash / Shift Sprint · Shoot / Space · Pass · Through · Switch · C Camera · Esc Pause
            </div>
          </div>
        )}

        {/* ==================== PLAYING HUD (>=85% Unobstructed) ==================== */}
        {screen !== 'title' && screen !== 'replay' && (
          <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-between p-4">
            {/* Top Broadcast Scoreboard & Compact Controls */}
            <div className="flex flex-wrap items-start justify-between gap-3">
              {/* Top-Left Column: Broadcast Score Bug + Real-Time Tactical AI HUD */}
              <div className="flex flex-col items-start gap-2">
                {/* Broadcast Score Bug */}
                <div className="pointer-events-auto flex items-center rounded-lg border border-white/15 bg-[#0B111B]/95 overflow-hidden shadow-lg">
                  <div className="flex items-center gap-2 px-3 py-2 border-r border-white/10">
                    <span
                      className="w-2.5 h-5 rounded-sm"
                      style={{ backgroundColor: hud.homeColor }}
                    />
                    <span className="font-display font-bold text-base tracking-wide text-white">
                      {hud.homeName}
                    </span>
                  </div>
                  {hud.mode === 'match' ? (
                    <>
                      <div className="px-3.5 py-2 font-mono-tabular text-lg font-bold text-emerald-400">
                        {hud.homeScore} - {hud.awayScore}
                      </div>
                      <div className="flex items-center gap-2 px-3 py-2 border-l border-white/10">
                        <span className="font-display font-bold text-base tracking-wide text-white">
                          {hud.awayName}
                        </span>
                        <span
                          className="w-2.5 h-5 rounded-sm"
                          style={{ backgroundColor: hud.awayColor }}
                        />
                      </div>
                      <div className="px-3 py-2 bg-[#111927] border-l border-white/10 font-mono-tabular text-xs font-bold text-slate-200">
                        {hud.matchMinute}&apos; · H{hud.half}
                      </div>
                    </>
                  ) : (
                    <div className="px-4 py-2 text-xs font-semibold text-emerald-300">
                      {homeClub.gymName} · Training Free-Roam
                    </div>
                  )}
                </div>

                {/* Real-Time Tactical AI Overlay */}
                {screen === 'playing' &&
                  hud.mode === 'match' &&
                  !modal &&
                  dismissedAiScenarioKey !== liveTacticalSuggestion.scenarioKey && (
                    <LiveTacticalAIOverlay
                      suggestion={liveTacticalSuggestion}
                      currentTactics={manager.tactics}
                      minimized={aiOverlayMinimized}
                      onToggleMinimize={() => setAiOverlayMinimized((m) => !m)}
                      onApply={handleUpdateTactics}
                      onDismiss={() =>
                        setDismissedAiScenarioKey(liveTacticalSuggestion.scenarioKey)
                      }
                    />
                  )}
              </div>

              {/* Compact Top-Right Audio & Pause Controls */}
              <div className="pointer-events-auto flex flex-wrap items-center gap-1.5">
                <button
                  onClick={handleToggleKuamiSong}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border text-xs font-semibold transition-colors ${
                    musicPlaying && !muted
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300'
                      : 'bg-[#0B111B]/95 border-white/15 text-slate-300 hover:text-white'
                  }`}
                  title="Toggle Kuami Eugene Song"
                >
                  <Music className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Kuami Song</span>
                </button>
                <button
                  onClick={() => {
                    const next = !muted;
                    setMuted(next);
                    soundEngine.setMuted(next);
                  }}
                  className="p-2 rounded-lg bg-[#0B111B]/95 border border-white/15 text-slate-200 hover:text-white"
                  aria-label="Toggle Mute"
                >
                  {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => setScreen(screen === 'paused' ? 'playing' : 'paused')}
                  className="p-2 rounded-lg bg-[#0B111B]/95 border border-white/15 text-slate-200 hover:text-white"
                  aria-label="Pause Menu"
                >
                  <Pause className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Center Goal / Injury / Gym Zone Banner */}
            <div className="flex flex-col items-center justify-center">
              {hud.goalBanner && (
                <div className="px-8 py-3 rounded-xl border border-emerald-400/50 bg-[#0B111B]/95 shadow-2xl">
                  <p className="font-display text-3xl md:text-4xl font-extrabold tracking-wider text-emerald-400">
                    {hud.goalBanner}
                  </p>
                </div>
              )}
              {hud.injuryBanner && (
                <div className="mt-2 px-5 py-2 rounded-lg border border-rose-500/50 bg-[#0B111B]/95 shadow-xl flex items-center gap-2">
                  <HeartPulse className="w-4 h-4 text-rose-400 shrink-0" />
                  <p className="text-xs md:text-sm font-bold tracking-wide text-rose-200">
                    {hud.injuryBanner}
                  </p>
                </div>
              )}
              {inGymBanner && playMode === 'training_roam' && (
                <div className="mt-2 px-4 py-1.5 rounded-lg border border-sky-400/40 bg-[#0B111B]/95 text-xs font-semibold text-sky-300 flex items-center gap-2">
                  <Dumbbell className="w-4 h-4" />
                  Inside {homeClub.gymName} — Stamina Recovering &amp; Conditioning Active
                </div>
              )}
            </div>

            {/* Bottom Perimeter: Radar Minimap & Player Nameplate (Centered cleanly clear of eFootball controls when active) */}
            <div
              className={
                controllerMode === 'efootball_touch' && screen === 'playing' && !modal
                  ? 'hidden lg:flex items-end justify-center gap-3 mb-1'
                  : 'flex items-end justify-between gap-4'
              }
            >
              {/* Tactical Pitch Radar Minimap */}
              <div className="w-36 h-24 rounded-lg border border-white/15 bg-[#0B111B]/90 relative overflow-hidden">
                <div className="absolute inset-1.5 border border-white/20">
                  <div className="absolute top-0 bottom-0 left-1/2 w-px bg-white/20" />
                </div>
                {hud.radarDots.map((dot, idx) => {
                  // Map pitch Z (-1..1) horizontally and X (-1..1) vertically for classic wide broadcast radar
                  const left = `${50 + dot.z * 44}%`;
                  const top = `${50 + dot.x * 42}%`;
                  const bg =
                    dot.team === 'ball'
                      ? '#FFFFFF'
                      : dot.team === 'controlled'
                        ? '#10B981'
                        : dot.team === 'home'
                          ? hud.homeColor
                          : '#F43F5E';
                  const size = dot.team === 'ball' ? 'w-2 h-2' : 'w-1.5 h-1.5';
                  return (
                    <span
                      key={idx}
                      style={{ left, top, backgroundColor: bg }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full ${size}`}
                    />
                  );
                })}
              </div>

              {/* Active Player Nameplate & Shot Power */}
              <div className="w-52 rounded-lg border border-white/15 bg-[#0B111B]/95 p-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-white truncate">
                    #{hud.activePlayerNumber} {hud.activePlayerName}
                  </span>
                  <span className="font-mono-tabular text-emerald-400 font-bold">
                    {hud.activePlayerStamina}%
                  </span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-emerald-400 transition-all duration-100"
                    style={{ width: `${hud.activePlayerStamina}%` }}
                  />
                </div>
                {hud.shotPower > 0.05 && (
                  <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-amber-400 to-rose-500"
                      style={{ width: `${Math.round(hud.shotPower * 100)}%` }}
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Authentic eFootball Mobile Virtual Stick & 4-Button Arc */}
            {controllerMode === 'efootball_touch' && screen === 'playing' && !modal && (
              <EFootballControlsOverlay
                isDefending={hud.teamHasPossession === 'away'}
                shotPower={hud.shotPower}
                onStickMove={(dx, dz) => engineRef.current?.setTouchMove(dx, dz)}
                onSprintChange={(sprinting) => engineRef.current?.setTouchSprint(sprinting)}
                onStartShot={() => engineRef.current?.startTouchShot()}
                onReleaseShot={() => engineRef.current?.releaseTouchShot()}
                onAction={(action) => engineRef.current?.triggerTouchAction(action)}
              />
            )}
          </div>
        )}

        {/* ==================== PAUSE MODAL ==================== */}
        {screen === 'paused' && !modal && (
          <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/75 p-4">
            <div className="w-full max-w-md rounded-xl border border-white/10 bg-[#0B111B] p-6 space-y-4 shadow-2xl">
              <h2 className="font-display text-3xl font-bold text-white">Match Paused</h2>
              <p className="text-xs text-slate-400">
                {homeClub.name} vs {awayClub.name} · {homeClub.stadiumName}
              </p>

              <div className="space-y-2 pt-2">
                <button
                  onClick={() => setScreen('playing')}
                  className="w-full py-2.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-sm hover:bg-emerald-400"
                >
                  Resume Play
                </button>
                <button
                  onClick={() => setModal('live_tactics')}
                  className="w-full py-2.5 rounded-lg border border-white/15 bg-[#111927] text-white font-semibold text-sm hover:bg-white/10"
                >
                  Live Tactics &amp; AI Touchline Coach
                </button>
                <button
                  onClick={() => setModal('manager')}
                  className="w-full py-2.5 rounded-lg border border-white/15 bg-[#111927] text-white font-semibold text-sm hover:bg-white/10"
                >
                  Manager Office
                </button>
                <button
                  onClick={() => setModal('world_map')}
                  className="w-full py-2.5 rounded-lg border border-white/15 bg-[#111927] text-white font-semibold text-sm hover:bg-white/10"
                >
                  World &amp; Facility Maps
                </button>
                <button
                  onClick={() => setPlayerLockToStar((p) => !p)}
                  className="w-full py-2.5 rounded-lg border border-white/15 bg-[#111927] text-slate-200 font-semibold text-xs hover:bg-white/10 flex items-center justify-between px-4"
                >
                  <span className="inline-flex items-center gap-2">
                    <Sliders className="w-3.5 h-3.5 text-sky-400" />
                    Control Mode
                  </span>
                  <span className="text-emerald-400">
                    {playerLockToStar ? 'Player Lock (Created Star)' : 'Full Team Control'}
                  </span>
                </button>
                <button
                  onClick={() =>
                    setControllerMode((m) => (m === 'efootball_touch' ? 'classic_pc' : 'efootball_touch'))
                  }
                  className="w-full py-2.5 rounded-lg border border-white/15 bg-[#111927] text-slate-200 font-semibold text-xs hover:bg-white/10 flex items-center justify-between px-4"
                >
                  <span className="inline-flex items-center gap-2">
                    <Gamepad2 className="w-3.5 h-3.5 text-amber-400" />
                    Controller Layout
                  </span>
                  <span className="text-emerald-400">
                    {controllerMode === 'efootball_touch'
                      ? 'eFootball Touch & Stick'
                      : 'Classic Keyboard Only'}
                  </span>
                </button>
                <button
                  onClick={() => setScreen('title')}
                  className="w-full py-2.5 rounded-lg text-slate-400 hover:text-white text-xs font-semibold"
                >
                  Return to Title Screen
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==================== FULL-TIME RESULT MODAL ==================== */}
        {screen === 'fulltime' && fullTimeScore && (
          <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/80 p-4">
            <div className="w-full max-w-md rounded-xl border border-emerald-500/30 bg-[#0B111B] p-6 text-center space-y-5 shadow-2xl">
              <p className="text-xs font-semibold tracking-widest text-emerald-400 uppercase">
                Full Time · {homeClub.stadiumName}
              </p>
              <div className="flex items-center justify-center gap-6">
                <div>
                  <p className="font-display text-xl font-bold text-white">{homeClub.shortName}</p>
                  <p className="font-mono-tabular text-5xl font-extrabold text-emerald-400">
                    {fullTimeScore.home}
                  </p>
                </div>
                <span className="font-display text-2xl text-slate-500">-</span>
                <div>
                  <p className="font-display text-xl font-bold text-white">{awayClub.shortName}</p>
                  <p className="font-mono-tabular text-5xl font-extrabold text-white">
                    {fullTimeScore.away}
                  </p>
                </div>
              </div>

              {/* Match Highlights Preview Summary */}
              <div className="rounded-lg border border-white/10 bg-[#111927] p-3 text-left space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="inline-flex items-center gap-1.5 font-semibold text-white">
                    <Film className="w-3.5 h-3.5 text-emerald-400" />
                    Match Highlight Reel
                  </span>
                  <span className="font-mono-tabular text-emerald-400 font-bold">
                    {matchHighlights.length} {matchHighlights.length === 1 ? 'Clip' : 'Clips'}
                  </span>
                </div>
                {matchHighlights.length > 0 ? (
                  <div className="max-h-28 overflow-y-auto space-y-1 pr-1">
                    {matchHighlights.map((hl, idx) => (
                      <button
                        key={hl.id}
                        onClick={() => {
                          engineRef.current?.startHighlightReplay(hl.id);
                          setScreen('replay');
                        }}
                        className="w-full flex items-center justify-between px-2.5 py-1.5 rounded bg-[#0B111B] border border-white/5 hover:border-emerald-400/50 text-xs transition-colors"
                      >
                        <span className="text-slate-200 truncate">
                          <span className="font-mono-tabular text-slate-400 mr-1.5">
                            {String(idx + 1).padStart(2, '0')}
                          </span>
                          {hl.title}
                        </span>
                        <span className="font-mono-tabular text-emerald-400 font-semibold ml-2 shrink-0">
                          {hl.minute}&apos;
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400">
                    No goals, woodwork hits, or keeper saves were triggered in this match.
                  </p>
                )}
              </div>

              <p className="text-xs text-slate-300">
                League standings, matchday gate revenue, and weekly training progress have been updated for Matchweek {manager.currentWeek}.
              </p>
              <div className="flex flex-col gap-2">
                {matchHighlights.length > 0 && (
                  <button
                    onClick={() => {
                      engineRef.current?.startHighlightReplay(matchHighlights[0]?.id);
                      setScreen('replay');
                    }}
                    className="w-full py-2.5 rounded-lg bg-sky-500 text-slate-950 font-bold text-sm hover:bg-sky-400 inline-flex items-center justify-center gap-2"
                  >
                    <Film className="w-4 h-4" />
                    Watch Highlight Reel ({matchHighlights.length})
                  </button>
                )}
                <button
                  onClick={() => {
                    engineRef.current?.stopHighlightReplay();
                    setScreen('playing');
                    setModal('manager');
                  }}
                  className="w-full py-2.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-sm hover:bg-emerald-400"
                >
                  Continue in Manager Office
                </button>
                <button
                  onClick={() => {
                    engineRef.current?.resetMatchState();
                    setDismissedAiScenarioKey(null);
                    setScreen('playing');
                    soundEngine.playWhistle('kickoff');
                  }}
                  className="w-full py-2.5 rounded-lg border border-white/15 bg-[#111927] text-white font-semibold text-xs hover:bg-white/10"
                >
                  Rematch
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==================== POST-MATCH HIGHLIGHT REEL VIEW ==================== */}
        {screen === 'replay' && (
          <HighlightReelOverlay
            highlights={matchHighlights}
            replayState={replayState}
            homeClub={homeClub}
            awayClub={awayClub}
            muted={muted}
            onToggleMute={() => {
              const next = !muted;
              setMuted(next);
              soundEngine.setMuted(next);
            }}
            onSelectHighlight={(id) => engineRef.current?.setReplayOptions({ highlightId: id, paused: false })}
            onTogglePlay={() => engineRef.current?.setReplayOptions({ paused: !replayState.paused })}
            onRestartClip={() => engineRef.current?.setReplayOptions({ currentTime: 0, paused: false })}
            onSeek={(timeSec) => engineRef.current?.setReplayOptions({ currentTime: timeSec })}
            onChangeSpeed={(speed) => engineRef.current?.setReplayOptions({ speed })}
            onChangeCamera={(camera) => engineRef.current?.setReplayOptions({ camera })}
            onToggleAutoPlay={() => engineRef.current?.setReplayOptions({ autoPlay: !replayState.autoPlay })}
            onExitReplay={() => {
              engineRef.current?.stopHighlightReplay();
              setScreen('fulltime');
            }}
          />
        )}

        {/* ==================== MODALS ==================== */}
        {modal === 'manager' && (
          <ManagerHub
            clubs={clubs}
            manager={manager}
            onSelectClub={handleSelectClub}
            onUpdateTactics={handleUpdateTactics}
            onSwapPlayers={handleSwapPlayers}
            onSetTrainingFocus={(focus: TrainingFocus) =>
              setManager((prev) => ({ ...prev, teamTrainingFocus: focus }))
            }
            onRunTrainingSession={handleRunTrainingSession}
            onBuyPlayer={handleBuyPlayer}
            onSellPlayer={handleSellPlayer}
            onUpgradeFacility={handleUpgradeFacility}
            onToggleMedicalStaff={handleToggleMedicalStaff}
            onSetMedicalProtocol={handleSetMedicalProtocol}
            onFastTrackRehab={handleFastTrackRehab}
            onSimulateWeek={handleSimulateWeek}
            onPlayNextMatch={handlePlayNextMatch}
            onEnterTrainingGym={() => handleEnterTrainingGym()}
            onClose={() => setModal(null)}
          />
        )}

        {modal === 'create_player' && (
          <CreatePlayerModal
            profile={createdPlayer}
            club={homeClub}
            onChange={setCreatedPlayer}
            onSaveToSquad={handleSaveStarToSquad}
            onEnterTrainingGym={() => {
              handleSaveStarToSquad();
              handleEnterTrainingGym();
            }}
            onClose={() => setModal(null)}
          />
        )}

        {modal === 'world_map' && (
          <WorldMapModal
            clubs={clubs}
            activeClubId={manager.clubId}
            onSelectClubStadium={(clubId, theme) => {
              handleSelectClub(clubId);
              setStadiumTheme(theme);
              setPlayMode('match');
              setModal(null);
              setDismissedAiScenarioKey(null);
              setScreen('playing');
              engineRef.current?.resetMatchState();
              soundEngine.playWhistle('kickoff');
              if (!userStoppedMusicRef.current) {
                soundEngine.startKuamiEugeneSong();
              }
            }}
            onEnterTrainingComplex={(clubId) => handleEnterTrainingGym(clubId)}
            onClose={() => setModal(null)}
          />
        )}

        {modal === 'live_tactics' && (
          <LiveTacticsDrawer
            club={homeClub}
            opponent={awayClub}
            manager={manager}
            matchMinute={hud.matchMinute}
            homeScore={hud.homeScore}
            awayScore={hud.awayScore}
            onUpdateTactics={handleUpdateTactics}
            onSwapPlayers={handleSwapPlayers}
            onClose={() => setModal(null)}
          />
        )}

        {modal === 'multiplayer' && (
          <MultiplayerChatModal
            wsConnected={wsConnected}
            peerId={peerId}
            platform={platform}
            onChangePlatform={setPlatform}
            rooms={rooms}
            activeRoom={activeRoom}
            onCreateRoom={(roomName) => {
              wsRef.current?.send(
                JSON.stringify({
                  type: 'room:create',
                  roomName,
                  playerName: createdPlayer.name,
                  clubId: homeClub.id,
                  clubName: homeClub.name,
                  stadiumTheme,
                  platform,
                  voiceEnabled: voiceActive,
                })
              );
            }}
            onJoinRoom={(roomId) => {
              wsRef.current?.send(
                JSON.stringify({
                  type: 'room:join',
                  roomId,
                  playerName: createdPlayer.name,
                  clubId: homeClub.id,
                  clubName: homeClub.name,
                  platform,
                  voiceEnabled: voiceActive,
                })
              );
            }}
            onLeaveRoom={() => wsRef.current?.send(JSON.stringify({ type: 'room:leave' }))}
            chatMessages={chatMessages}
            onSendChat={(text, channel) => {
              wsRef.current?.send(
                JSON.stringify({
                  type: 'chat:send',
                  channel: channel === 'room' && activeRoom ? activeRoom.id : 'global',
                  senderName: createdPlayer.name,
                  clubName: homeClub.shortName,
                  platform,
                  text,
                })
              );
            }}
            voiceActive={voiceActive}
            voiceError={voiceError}
            onToggleVoice={toggleVoiceChat}
            leaderboard={leaderboard}
            firebaseUser={firebaseUser}
            cloudSaves={cloudSaves}
            cloudStatus={cloudStatus}
            onSignInGoogle={async () => {
              try {
                await signInWithGoogle();
                setCloudStatus('Signed in with Google.');
              } catch (err) {
                setCloudStatus(err instanceof Error ? err.message : 'Sign-in cancelled.');
              }
            }}
            onSignOut={() => void signOutUser()}
            onSaveCloud={handleSaveToCloud}
            onLoadCloud={handleLoadCloudSave}
            onClose={() => setModal(null)}
          />
        )}
      </div>
    </ErrorBoundary>
  );
}
