import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  CameraMode,
  Club,
  CreatedPlayerProfile,
  HighlightType,
  InjurySeverity,
  MatchHUDState,
  MatchHighlightSummary,
  Player,
  PlayerInjury,
  ReplayCameraAngle,
  ReplayHUDState,
  ReplaySpeed,
  StadiumTheme,
  TacticalSetup,
} from '../types/game';
import { FORMATIONS, createPlayerInjury } from '../state/managerEngine';
import {
  FootballerRig,
  GOAL_DEPTH,
  GOAL_HEIGHT,
  GOAL_WIDTH,
  PITCH_LENGTH,
  PITCH_WIDTH,
  buildClubGymPavilion,
  buildGoalStructure,
  buildTechnicalDugouts,
  buildTwilightSkyDome,
  createAdBoardTexture,
  createContactShadowTexture,
  createFootballerRig,
  createPitchRoughnessTexture,
  createPitchTexture,
  createSoccerBallTexture,
} from './ProceduralAssets';
import { soundEngine } from '../audio/SoundEngine';

// Pre-allocated scratch math helpers (zero GC inside animation loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _camPos = new THREE.Vector3();
const _magnus = new THREE.Vector3();
const _dummy = new THREE.Object3D();

const REPLAY_FPS = 30;
const REPLAY_PRE_FRAMES = 144; // ~4.8s buildup
const REPLAY_POST_FRAMES = 48; // ~1.6s aftermath
const MAX_HIGHLIGHTS = 12;

function lerpAngle(a: number, b: number, t: number): number {
  let diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return a + diff * t;
}

interface ReplayFrame {
  ball: Float32Array; // [x, y, z, rx, ry, rz]
  actors: Float32Array; // [x, z, facing, legL, legR, armL, armR] * actors.length
}

interface RecordedHighlight {
  summary: MatchHighlightSummary;
  targetGoalZ: number;
  frames: ReplayFrame[];
}

interface PendingHighlight {
  type: HighlightType;
  title: string;
  subtitle: string;
  minute: number;
  team: 'home' | 'away';
  playerName: string;
  playerNumber: number;
  scoreText: string;
  targetGoalZ: number;
  shotSpeedKmh: number;
  peakIndex: number;
  postRemaining: number;
  frames: ReplayFrame[];
}

interface PitchActor {
  id: string;
  player: Player;
  team: 'home' | 'away';
  slotIndex: number;
  rig: FootballerRig;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  facing: number;
  stamina: number;
  kickAnim: number;
  kickFoot: 'left' | 'right';
  gaitPhase: number;
  isGK: boolean;
}

export interface EngineConfig {
  homeClub: Club;
  awayClub: Club;
  createdPlayer: CreatedPlayerProfile;
  tactics: TacticalSetup;
  startingXIIds?: string[];
  injuryPreventionPct?: number;
  currentWeek?: number;
  stadiumTheme: StadiumTheme;
  cameraMode: CameraMode;
  mode: 'title_showcase' | 'match' | 'training_roam';
  playerLockToStar: boolean;
  onHUDUpdate: (hud: MatchHUDState) => void;
  onMatchEnd?: (homeScore: number, awayScore: number) => void;
  onPlayerInjury?: (playerId: string, injury: PlayerInjury) => void;
  onGymZoneEnter?: (inGym: boolean) => void;
  onHighlightsChange?: (highlights: MatchHighlightSummary[]) => void;
  onReplayUpdate?: (state: ReplayHUDState) => void;
}

export class FootballEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private maxAnisotropy: number;

  private frameId = 0;
  private lastTime = 0;
  private disposed = false;
  private paused = false;

  private config: EngineConfig;
  private actors: PitchActor[] = [];
  private controlledActorIndex = 9; // Striker by default

  // Ball state & realistic physics
  private ballMesh: THREE.Mesh;
  private ballShadow: THREE.Mesh;
  private ballPos = new THREE.Vector3(0, 0.22, 0);
  private ballVel = new THREE.Vector3(0, 0, 0);
  private ballSpin = new THREE.Vector3(0, 0, 0);
  private readonly ballRadius = 0.22;

  // Match & Gameplay state
  private homeScore = 0;
  private awayScore = 0;
  private matchSeconds = 0;
  private readonly matchHalfDuration = 75; // 75 real seconds per half = 45 match minutes
  private half: 1 | 2 = 1;
  private matchEnded = false;
  private goalCelebrationTimer = 0;
  private celebratingScorerIndex = -1;
  private celebratingTeam: 'home' | 'away' | null = null;
  private celebrationStyle: 'arms_wide' | 'siuu_leap' | 'knee_slide' = 'arms_wide';
  private celebrationElapsed = 0;
  private celebrationTarget = new THREE.Vector3();
  private goalBanner: string | null = null;
  private homeTouches = 1;
  private awayTouches = 1;
  private kickCooldown = 0;
  private dribbleTouchCooldown = 0;
  private hudEmitTimer = 0;
  private cameraShake = 0;
  private inGymZone = false;
  private injuryCooldown = 8;
  private matchInjuryCount = 0;
  private injuryBanner: string | null = null;
  private injuryBannerTimer = 0;
  private injuredThisMatch = new Set<string>();

  // Stadium scene dynamic references
  private environmentGroup = new THREE.Group();
  private actorsGroup = new THREE.Group();
  private rainPoints: THREE.Points | null = null;
  private crowdMesh: THREE.InstancedMesh | null = null;
  private crowdBaseMatrices: THREE.Matrix4[] = [];
  private homeGoalNet: THREE.Mesh | null = null;
  private awayGoalNet: THREE.Mesh | null = null;
  private netRippleHome = 0;
  private netRippleAway = 0;
  private keyLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;
  private shadowTex: THREE.CanvasTexture;

  // Input state (held vs edge-triggered)
  private heldKeys = new Set<string>();
  private touchMove = new THREE.Vector2(0, 0);
  private touchSprint = false;
  private chargingShot = false;
  private shotPower = 0;
  private remoteInput = new THREE.Vector2(0, 0);

  // Highlight Reel Recorder & 3D Replay Director
  private lastTouchActor: PitchActor | null = null;
  private lastShotSpeedMps = 0;
  private replaySampleAccum = 0;
  private replayPreBuffer: ReplayFrame[] = [];
  private pendingHighlights: PendingHighlight[] = [];
  private recordedHighlights: RecordedHighlight[] = [];
  private highlightCooldownSave = 0;
  private highlightCooldownPost = 0;
  private highlightCooldownChance = 0;
  private replayActive = false;
  private replayPaused = false;
  private replaySpeed: ReplaySpeed = 1;
  private replayCamera: ReplayCameraAngle = 'tv_broadcast';
  private replayTime = 0;
  private replayPrevTime = 0;
  private replayAutoPlay = true;
  private replayClipIndex = 0;
  private replayEmitTimer = 0;

  constructor(container: HTMLElement, config: EngineConfig) {
    this.container = container;
    this.config = config;

    // 1. Software WebGL detection
    this.isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Renderer setup
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth || 1280, container.clientHeight || 720);
    this.maxAnisotropy = this.renderer.capabilities.getMaxAnisotropy();

    container.appendChild(this.renderer.domElement);

    // 3. Scene & Studio RoomEnvironment
    this.scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    this.camera = new THREE.PerspectiveCamera(
      48,
      (container.clientWidth || 1280) / (container.clientHeight || 720),
      0.2,
      420
    );
    this.camera.position.set(0, 26, 46);

    this.shadowTex = createContactShadowTexture();

    // 4. Lighting Rig
    this.hemiLight = new THREE.HemisphereLight(0xcbd5e1, 0x14532d, 0.7);
    this.scene.add(this.hemiLight);

    this.keyLight = new THREE.DirectionalLight(0xfffbeb, 2.25);
    this.keyLight.position.set(28, 48, 22);
    this.keyLight.castShadow = !this.isSoftwareGl;
    const shadowSize = this.isSoftwareGl ? 512 : 2048;
    this.keyLight.shadow.mapSize.set(shadowSize, shadowSize);
    this.keyLight.shadow.camera.left = -60;
    this.keyLight.shadow.camera.right = 60;
    this.keyLight.shadow.camera.top = 60;
    this.keyLight.shadow.camera.bottom = -60;
    this.keyLight.shadow.camera.near = 5;
    this.keyLight.shadow.camera.far = 130;
    this.keyLight.shadow.bias = -0.0005;
    this.keyLight.shadow.normalBias = 0.02;
    this.scene.add(this.keyLight);

    const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.9);
    rimLight.position.set(-34, 28, -32);
    this.scene.add(rimLight);

    // 5. Ball Mesh
    const ballGeo = new THREE.SphereGeometry(this.ballRadius, 24, 24);
    const ballMat = new THREE.MeshStandardMaterial({
      map: createSoccerBallTexture(),
      roughness: 0.36,
      metalness: 0.06,
    });
    this.ballMesh = new THREE.Mesh(ballGeo, ballMat);
    this.ballMesh.castShadow = true;
    this.scene.add(this.ballMesh);

    this.ballShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(0.85, 0.85),
      new THREE.MeshBasicMaterial({
        map: this.shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.65,
      })
    );
    this.ballShadow.rotation.x = -Math.PI / 2;
    this.ballShadow.position.y = 0.014;
    this.scene.add(this.ballShadow);

    this.scene.add(this.environmentGroup);
    this.scene.add(this.actorsGroup);

    this.rebuildEnvironment();
    this.rebuildActors();
    this.bindEvents();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.lastTime = performance.now();
    this.tick();
  }

  public updateConfig(partial: Partial<EngineConfig>) {
    const prevTheme = this.config.stadiumTheme;
    const prevMode = this.config.mode;
    const prevHomeId = this.config.homeClub.id;
    const prevAwayId = this.config.awayClub.id;
    const prevStarSig = JSON.stringify(this.config.createdPlayer);

    this.config = { ...this.config, ...partial };

    if (
      prevTheme !== this.config.stadiumTheme ||
      prevHomeId !== this.config.homeClub.id
    ) {
      this.rebuildEnvironment();
    }

    const nextStarSig = JSON.stringify(this.config.createdPlayer);
    if (
      prevMode !== this.config.mode ||
      prevHomeId !== this.config.homeClub.id ||
      prevAwayId !== this.config.awayClub.id
    ) {
      this.resetMatchState();
      this.rebuildActors();
    } else if (prevStarSig !== nextStarSig) {
      this.rebuildActors();
    } else if (partial.tactics && !this.replayActive) {
      this.repositionFormationTargets();
    }
  }

  public setPaused(paused: boolean) {
    this.paused = paused;
  }

  public setTouchMove(dx: number, dz: number) {
    this.touchMove.set(dx, dz);
  }

  public setTouchSprint(sprinting: boolean) {
    this.touchSprint = sprinting;
  }

  public startTouchShot() {
    if (this.config.mode === 'title_showcase' || this.paused || this.replayActive) return;
    if (!this.chargingShot) {
      this.chargingShot = true;
      this.shotPower = 0.25;
    }
  }

  public releaseTouchShot() {
    if (!this.chargingShot) return;
    this.chargingShot = false;
    this.performKick(this.shotPower, this.shotPower * 0.28, this.shotPower > 0.48);
    this.shotPower = 0;
  }

  public triggerTouchAction(
    action: 'pass' | 'through' | 'shoot' | 'lob' | 'switch' | 'tackle' | 'press' | 'matchup' | 'clear'
  ) {
    if (action === 'pass') this.performKick(0.54, 0.06, false, false);
    else if (action === 'through') this.performKick(0.76, 0.14, false, true);
    else if (action === 'shoot') this.performKick(0.95, 0.28, true, false);
    else if (action === 'lob') this.performKick(0.75, 0.45, false, true);
    else if (action === 'switch') this.switchControlledPlayer();
    else if (action === 'tackle') this.performSlidePress();
    else if (action === 'press') this.performPressAction();
    else if (action === 'matchup') this.switchControlledPlayer();
    else if (action === 'clear') this.performClearAction();
  }

  public applyRemoteSnapshot(snapshot: {
    ballPos?: [number, number, number];
    ballVel?: [number, number, number];
    homeScore?: number;
    awayScore?: number;
  }) {
    if (snapshot.ballPos) {
      this.ballPos.set(snapshot.ballPos[0], snapshot.ballPos[1], snapshot.ballPos[2]);
    }
    if (snapshot.ballVel) {
      this.ballVel.set(snapshot.ballVel[0], snapshot.ballVel[1], snapshot.ballVel[2]);
    }
    if (typeof snapshot.homeScore === 'number') this.homeScore = snapshot.homeScore;
    if (typeof snapshot.awayScore === 'number') this.awayScore = snapshot.awayScore;
  }

  public getMultiplayerSnapshot() {
    return {
      ballPos: [this.ballPos.x, this.ballPos.y, this.ballPos.z],
      ballVel: [this.ballVel.x, this.ballVel.y, this.ballVel.z],
      homeScore: this.homeScore,
      awayScore: this.awayScore,
      matchMinute: Math.min(90, Math.floor((this.matchSeconds / this.matchHalfDuration) * 45) + (this.half === 2 ? 45 : 0)),
    };
  }

  public setRemoteInput(dx: number, dz: number) {
    this.remoteInput.set(dx, dz);
  }

  public resetMatchState() {
    this.stopHighlightReplay();
    this.homeScore = 0;
    this.awayScore = 0;
    this.matchSeconds = 0;
    this.half = 1;
    this.matchEnded = false;
    this.goalBanner = null;
    this.goalCelebrationTimer = 0;
    this.celebratingScorerIndex = -1;
    this.celebratingTeam = null;
    this.celebrationElapsed = 0;
    this.lastTouchActor = null;
    this.lastShotSpeedMps = 0;
    this.replaySampleAccum = 0;
    this.replayPreBuffer = [];
    this.pendingHighlights = [];
    this.recordedHighlights = [];
    this.highlightCooldownSave = 0;
    this.highlightCooldownPost = 0;
    this.highlightCooldownChance = 0;
    this.injuryCooldown = 8;
    this.matchInjuryCount = 0;
    this.injuryBanner = null;
    this.injuryBannerTimer = 0;
    this.injuredThisMatch.clear();
    this.config.onHighlightsChange?.([]);
    this.resetKickoff();
  }

  private resetKickoff() {
    this.flushPendingHighlights();
    this.celebratingScorerIndex = -1;
    this.celebratingTeam = null;
    this.celebrationElapsed = 0;
    this.ballPos.set(0, this.ballRadius, 0);
    this.ballVel.set(0, 0, 0);
    this.ballSpin.set(0, 0, 0);
    this.repositionFormationTargets(true);
  }

  public getMatchHighlights(): MatchHighlightSummary[] {
    return this.recordedHighlights.map((h) => h.summary);
  }

  public startHighlightReplay(highlightId?: string) {
    this.flushPendingHighlights();
    if (this.recordedHighlights.length === 0) return;

    let idx = 0;
    if (highlightId) {
      const found = this.recordedHighlights.findIndex((h) => h.summary.id === highlightId);
      if (found >= 0) idx = found;
    }

    this.replayActive = true;
    this.replayPaused = false;
    this.replayClipIndex = idx;
    this.replayTime = 0;
    this.replayPrevTime = 0;
    this.goalBanner = null;
    this.netRippleAway = 0;
    this.netRippleHome = 0;

    // Hide player selection ring during broadcast replay
    for (const actor of this.actors) {
      actor.rig.ring.visible = false;
    }

    this.applyReplayFrame(this.recordedHighlights[idx], 0);
    this.emitReplayState();
  }

  public stopHighlightReplay() {
    if (!this.replayActive) return;
    this.replayActive = false;
    this.replayPaused = false;
    this.netRippleAway = 0;
    this.netRippleHome = 0;
    if (this.actors[this.controlledActorIndex]) {
      this.actors[this.controlledActorIndex].rig.ring.visible = true;
    }
    this.emitReplayState();
  }

  public setReplayOptions(opts: {
    paused?: boolean;
    speed?: ReplaySpeed;
    camera?: ReplayCameraAngle;
    currentTime?: number;
    autoPlay?: boolean;
    highlightId?: string;
  }) {
    if (typeof opts.autoPlay === 'boolean') this.replayAutoPlay = opts.autoPlay;
    if (opts.speed) this.replaySpeed = opts.speed;
    if (opts.camera) this.replayCamera = opts.camera;
    if (typeof opts.paused === 'boolean') this.replayPaused = opts.paused;

    if (opts.highlightId) {
      const found = this.recordedHighlights.findIndex((h) => h.summary.id === opts.highlightId);
      if (found >= 0) {
        this.replayClipIndex = found;
        this.replayTime = 0;
        this.replayPrevTime = 0;
        this.netRippleAway = 0;
        this.netRippleHome = 0;
      }
    }

    const activeClip = this.recordedHighlights[this.replayClipIndex];
    if (activeClip && typeof opts.currentTime === 'number') {
      this.replayTime = THREE.MathUtils.clamp(opts.currentTime, 0, activeClip.summary.durationSec);
      this.replayPrevTime = this.replayTime;
      this.applyReplayFrame(activeClip, this.replayTime);
    }
    this.emitReplayState();
  }

  private repositionFormationTargets(snapImmediately = false) {
    const slots = FORMATIONS[this.config.tactics.formation];
    const halfW = PITCH_WIDTH * 0.46;
    const halfL = PITCH_LENGTH * 0.47;

    for (const actor of this.actors) {
      if (this.config.mode === 'training_roam') continue;
      const slot = slots[actor.slotIndex % slots.length];
      if (!slot) continue;
      const sideSign = actor.team === 'home' ? 1 : -1;
      const tx = slot.nx * halfW * sideSign;
      const tz = slot.nz * halfL * sideSign;
      if (snapImmediately) {
        actor.pos.set(tx, 0, tz);
        actor.vel.set(0, 0, 0);
        actor.facing = actor.team === 'home' ? Math.PI : 0;
        actor.kickAnim = 0;
        actor.rig.group.position.copy(actor.pos);
        actor.rig.group.rotation.y = actor.facing;
        actor.rig.torso.rotation.set(0, Math.PI, 0);
        actor.rig.leftArm.rotation.set(0, 0, 0);
        actor.rig.rightArm.rotation.set(0, 0, 0);
        actor.rig.leftLeg.rotation.set(0, 0, 0);
        actor.rig.rightLeg.rotation.set(0, 0, 0);
      }
    }
  }

  private clearGroup(group: THREE.Group) {
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      child.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) m.material.forEach((mat) => mat.dispose());
          else m.material?.dispose();
        }
      });
    }
  }

  private rebuildEnvironment() {
    this.clearGroup(this.environmentGroup);
    this.rainPoints = null;
    this.crowdMesh = null;
    this.crowdBaseMatrices = [];

    const theme = this.config.stadiumTheme;
    const home = this.config.homeClub;

    // Sky & Fog atmosphere
    if (theme === 'golden_hour') {
      this.scene.background = new THREE.Color('#1E293B');
      this.scene.fog = new THREE.FogExp2('#292524', 0.0045);
      this.keyLight.color.set('#FDBA74');
      this.keyLight.intensity = 2.5;
      this.hemiLight.color.set('#FDE68A');
      this.hemiLight.groundColor.set('#14532D');
      this.hemiLight.intensity = 0.8;
    } else if (theme === 'rainy_derby') {
      this.scene.background = new THREE.Color('#0B1320');
      this.scene.fog = new THREE.FogExp2('#0B1320', 0.0085);
      this.keyLight.color.set('#CBD5E1');
      this.keyLight.intensity = 1.7;
      this.hemiLight.color.set('#94A3B8');
      this.hemiLight.groundColor.set('#0F172A');
      this.hemiLight.intensity = 0.65;
    } else if (theme === 'training_gym') {
      this.scene.background = new THREE.Color('#0F172A');
      this.scene.fog = new THREE.FogExp2('#0F172A', 0.0038);
      this.keyLight.color.set('#FEF9C3');
      this.keyLight.intensity = 2.2;
      this.hemiLight.color.set('#BAE6FD');
      this.hemiLight.groundColor.set('#166534');
      this.hemiLight.intensity = 0.85;
    } else {
      // Bright Night Stadium Floodlights
      this.scene.background = new THREE.Color('#060A14');
      this.scene.fog = new THREE.FogExp2('#060A14', 0.0042);
      this.keyLight.color.set('#FFFBEB');
      this.keyLight.intensity = 2.45;
      this.hemiLight.color.set('#E2E8F0');
      this.hemiLight.groundColor.set('#14532D');
      this.hemiLight.intensity = 0.78;
    }

    // Procedural Sky Dome matching stadium time-of-day
    this.environmentGroup.add(buildTwilightSkyDome(theme));

    // Surrounding outer turf & stadium concourse (prevents floating void)
    const outerGround = new THREE.Mesh(
      new THREE.PlaneGeometry(340, 340),
      new THREE.MeshStandardMaterial({
        color: '#0D2918',
        roughness: 0.95,
        metalness: 0.0,
      })
    );
    outerGround.rotation.x = -Math.PI / 2;
    outerGround.position.y = -0.02;
    outerGround.receiveShadow = true;
    this.environmentGroup.add(outerGround);

    // Track / Concrete Apron around pitch
    const apron = new THREE.Mesh(
      new THREE.PlaneGeometry(PITCH_WIDTH + 20, PITCH_LENGTH + 20),
      new THREE.MeshStandardMaterial({
        color: '#1E293B',
        roughness: 0.88,
        metalness: 0.08,
      })
    );
    apron.rotation.x = -Math.PI / 2;
    apron.position.y = -0.008;
    apron.receiveShadow = true;
    this.environmentGroup.add(apron);

    // Striped Grass Pitch with micro-roughness specular sheen
    const pitchTex = createPitchTexture(theme, this.maxAnisotropy);
    const pitchRoughTex = createPitchRoughnessTexture(theme);
    const pitchMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(PITCH_WIDTH + 6, PITCH_LENGTH + 6),
      new THREE.MeshStandardMaterial({
        map: pitchTex,
        roughnessMap: pitchRoughTex,
        roughness: theme === 'rainy_derby' ? 0.5 : 0.86,
        metalness: theme === 'rainy_derby' ? 0.12 : 0.02,
      })
    );
    pitchMesh.rotation.x = -Math.PI / 2;
    pitchMesh.position.y = 0;
    pitchMesh.receiveShadow = true;
    this.environmentGroup.add(pitchMesh);

    // 3D Goals (Away goal at -Z, Home goal at +Z)
    const awayGoal = buildGoalStructure(-PITCH_LENGTH / 2, -1);
    this.awayGoalNet = awayGoal.netMesh;
    this.environmentGroup.add(awayGoal.group);

    const homeGoal = buildGoalStructure(PITCH_LENGTH / 2, 1);
    this.homeGoalNet = homeGoal.netMesh;
    this.environmentGroup.add(homeGoal.group);

    // Corner Flags (4 corners)
    const flagPoleMat = new THREE.MeshStandardMaterial({ color: '#F8FAFC', roughness: 0.4 });
    const flagClothMat = new THREE.MeshStandardMaterial({ color: home.homeKit.primary, roughness: 0.7 });
    const corners: [number, number][] = [
      [-PITCH_WIDTH / 2, -PITCH_LENGTH / 2],
      [PITCH_WIDTH / 2, -PITCH_LENGTH / 2],
      [-PITCH_WIDTH / 2, PITCH_LENGTH / 2],
      [PITCH_WIDTH / 2, PITCH_LENGTH / 2],
    ];
    for (const [cx, cz] of corners) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.4, 8), flagPoleMat);
      pole.position.set(cx, 0.7, cz);
      const cloth = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.24, 0.02), flagClothMat);
      cloth.position.set(cx + 0.19, 1.25, cz);
      this.environmentGroup.add(pole, cloth);
    }

    // Perimeter LED Ad Boards
    const adTex = createAdBoardTexture(home);
    adTex.repeat.set(4, 1);
    const adMat = new THREE.MeshStandardMaterial({
      map: adTex,
      emissive: new THREE.Color('#FFFFFF'),
      emissiveMap: adTex,
      emissiveIntensity: 0.45,
      roughness: 0.4,
    });
    const eastBoard = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.0, PITCH_LENGTH + 4), adMat);
    eastBoard.position.set(PITCH_WIDTH / 2 + 4.5, 0.5, 0);
    this.environmentGroup.add(eastBoard);

    const northBoard = new THREE.Mesh(new THREE.BoxGeometry(PITCH_WIDTH + 6, 1.0, 0.3), adMat);
    northBoard.position.set(0, 0.5, -PITCH_LENGTH / 2 - 5.5);
    this.environmentGroup.add(northBoard);

    const southBoard = new THREE.Mesh(new THREE.BoxGeometry(PITCH_WIDTH + 6, 1.0, 0.3), adMat);
    southBoard.position.set(0, 0.5, PITCH_LENGTH / 2 + 5.5);
    this.environmentGroup.add(southBoard);

    if (theme === 'training_gym') {
      // Club Training Ground + Walkable Gym Pavilion + Slalom Cones
      const gymPavilion = buildClubGymPavilion(home);
      this.environmentGroup.add(gymPavilion);

      const coneMat = new THREE.MeshStandardMaterial({ color: '#F97316', roughness: 0.5 });
      for (let i = 0; i < 8; i++) {
        const cone = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.48, 12), coneMat);
        cone.position.set(-14 + (i % 2) * 3.5, 0.24, -18 + i * 5);
        cone.castShadow = true;
        this.environmentGroup.add(cone);
      }
    } else {
      // Full Stadium Stands, Technical Dugouts, Floodlight Towers & Animated Instanced Crowd
      const westBoard = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.0, PITCH_LENGTH + 4), adMat);
      westBoard.position.set(-PITCH_WIDTH / 2 - 4.5, 0.5, 0);
      this.environmentGroup.add(westBoard);
      this.environmentGroup.add(buildTechnicalDugouts(home, this.config.awayClub));

      const concreteMat = new THREE.MeshStandardMaterial({ color: '#1E293B', roughness: 0.85, metalness: 0.1 });
      const seatMat = new THREE.MeshStandardMaterial({ color: home.homeKit.primary, roughness: 0.75 });

      const buildStand = (w: number, h: number, d: number, x: number, z: number, rotY = 0) => {
        const g = new THREE.Group();
        g.position.set(x, 0, z);
        g.rotation.y = rotY;
        const tier1 = new THREE.Mesh(new THREE.BoxGeometry(w, h * 0.45, d * 0.55), seatMat);
        tier1.position.set(0, h * 0.225, -d * 0.2);
        const tier2 = new THREE.Mesh(new THREE.BoxGeometry(w, h, d * 0.45), concreteMat);
        tier2.position.set(0, h * 0.5, d * 0.28);
        const canopy = new THREE.Mesh(new THREE.BoxGeometry(w + 2, 0.5, d * 0.9), concreteMat);
        canopy.position.set(0, h + 1.8, 0.5);
        g.add(tier1, tier2, canopy);
        this.environmentGroup.add(g);
      };

      buildStand(PITCH_LENGTH + 18, 14, 18, -PITCH_WIDTH / 2 - 16, 0, -Math.PI / 2);
      buildStand(PITCH_LENGTH + 18, 14, 18, PITCH_WIDTH / 2 + 16, 0, Math.PI / 2);
      buildStand(PITCH_WIDTH + 16, 13, 16, 0, -PITCH_LENGTH / 2 - 16, 0);
      buildStand(PITCH_WIDTH + 16, 13, 16, 0, PITCH_LENGTH / 2 + 16, Math.PI);

      // 4 Tall Stadium Floodlight Towers with Bright LED Panels & Volumetric Light Cones
      const towerMat = new THREE.MeshStandardMaterial({ color: '#475569', roughness: 0.4, metalness: 0.8 });
      const ledMat = new THREE.MeshStandardMaterial({
        color: '#FFFFFF',
        emissive: new THREE.Color(theme === 'golden_hour' ? '#FDE68A' : '#FEF9C3'),
        emissiveIntensity: 3.2,
      });
      const beamMat = new THREE.MeshBasicMaterial({
        color: theme === 'golden_hour' ? '#FDBA74' : '#FEF9C3',
        transparent: true,
        opacity: theme === 'golden_hour' ? 0.025 : 0.045,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      });
      const towerCoords: [number, number][] = [
        [-PITCH_WIDTH / 2 - 12, -PITCH_LENGTH / 2 - 12],
        [PITCH_WIDTH / 2 + 12, -PITCH_LENGTH / 2 - 12],
        [-PITCH_WIDTH / 2 - 12, PITCH_LENGTH / 2 + 12],
        [PITCH_WIDTH / 2 + 12, PITCH_LENGTH / 2 + 12],
      ];
      for (const [tx, tz] of towerCoords) {
        const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.85, 28, 10), towerMat);
        mast.position.set(tx, 14, tz);
        const head = new THREE.Mesh(new THREE.BoxGeometry(5.5, 2.8, 0.7), ledMat);
        head.position.set(tx, 27.5, tz);
        head.lookAt(0, 0, 0);

        const beamGeo = new THREE.ConeGeometry(16, 46, 16, 1, true);
        beamGeo.translate(0, -23, 0);
        beamGeo.rotateX(Math.PI / 2);
        const beam = new THREE.Mesh(beamGeo, beamMat);
        beam.position.set(tx, 27.2, tz);
        beam.lookAt(0, 0, 0);

        this.environmentGroup.add(mast, head, beam);
      }

      // Instanced Crowd Spectators around Stands
      const crowdCount = 420;
      const fanGeo = new THREE.BoxGeometry(0.45, 0.9, 0.45);
      const fanMat = new THREE.MeshStandardMaterial({ roughness: 0.8, metalness: 0.05 });
      this.crowdMesh = new THREE.InstancedMesh(fanGeo, fanMat, crowdCount);
      this.crowdMesh.frustumCulled = false;

      const cPrimary = new THREE.Color(home.homeKit.primary);
      const cSecondary = new THREE.Color(home.homeKit.secondary);
      const cNeutral = new THREE.Color('#E2E8F0');
      const fanColor = new THREE.Color();

      for (let i = 0; i < crowdCount; i++) {
        const side = i % 4;
        let fx = 0;
        let fy = 3 + ((i * 7) % 6) * 1.4;
        let fz = 0;
        if (side === 0) {
          fx = -PITCH_WIDTH / 2 - 11 - ((i * 7) % 6) * 1.6;
          fz = ((i / crowdCount) - 0.5) * (PITCH_LENGTH + 6);
        } else if (side === 1) {
          fx = PITCH_WIDTH / 2 + 11 + ((i * 7) % 6) * 1.6;
          fz = ((i / crowdCount) - 0.5) * (PITCH_LENGTH + 6);
        } else if (side === 2) {
          fx = ((i / crowdCount) - 0.5) * (PITCH_WIDTH + 6);
          fz = -PITCH_LENGTH / 2 - 11 - ((i * 7) % 6) * 1.6;
        } else {
          fx = ((i / crowdCount) - 0.5) * (PITCH_WIDTH + 6);
          fz = PITCH_LENGTH / 2 + 11 + ((i * 7) % 6) * 1.6;
        }

        _dummy.position.set(fx, fy, fz);
        const s = 0.85 + (i % 5) * 0.07;
        _dummy.scale.set(s, s, s);
        _dummy.updateMatrix();
        this.crowdMesh.setMatrixAt(i, _dummy.matrix);
        this.crowdBaseMatrices.push(_dummy.matrix.clone());

        if (i % 3 === 0) fanColor.copy(cPrimary);
        else if (i % 3 === 1) fanColor.copy(cSecondary);
        else fanColor.copy(cNeutral);
        this.crowdMesh.setColorAt(i, fanColor);
      }
      this.crowdMesh.instanceMatrix.needsUpdate = true;
      if (this.crowdMesh.instanceColor) this.crowdMesh.instanceColor.needsUpdate = true;
      this.crowdMesh.computeBoundingSphere();
      this.environmentGroup.add(this.crowdMesh);
    }

    // Rain Particles if Rainy Derby
    if (theme === 'rainy_derby') {
      const count = 900;
      const positions = new Float32Array(count * 3);
      for (let i = 0; i < count; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 110;
        positions[i * 3 + 1] = Math.random() * 28;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 140;
      }
      const rainGeo = new THREE.BufferGeometry();
      rainGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const rainMat = new THREE.PointsMaterial({
        color: 0xbae6fd,
        size: 0.22,
        transparent: true,
        opacity: 0.55,
      });
      this.rainPoints = new THREE.Points(rainGeo, rainMat);
      this.environmentGroup.add(this.rainPoints);
    }
  }

  private rebuildActors() {
    this.clearGroup(this.actorsGroup);
    this.actors = [];

    const home = this.config.homeClub;
    const away = this.config.awayClub;
    const isTraining = this.config.mode === 'training_roam';

    const slots = FORMATIONS[this.config.tactics.formation];
    const halfW = PITCH_WIDTH * 0.46;
    const halfL = PITCH_LENGTH * 0.47;

    if (isTraining) {
      // Spawn Created Star Player + 5 training teammates in Club Training Kits!
      const star = this.config.createdPlayer;
      const starRig = createFootballerRig(
        home.trainingKit,
        star.skinTone,
        star.hairColor,
        star.number,
        this.shadowTex,
        star.heightScale,
        {
          faceStyle: star.faceStyle,
          hairStyle: star.hairStyle,
          bodyType: star.bodyType,
          bootColor: star.bootColor,
        }
      );
      starRig.ring.visible = true;
      this.actorsGroup.add(starRig.group);
      this.actors.push({
        id: 'created_star',
        player: {
          id: 'created_star',
          name: star.name,
          nationality: star.nationality,
          position: star.position,
          secondaryPosition: star.secondaryPosition,
          number: star.number,
          age: star.age,
          ovr: star.ovr,
          pace: star.pace,
          shooting: star.shooting,
          passing: star.passing,
          dribbling: star.dribbling,
          defending: star.defending,
          physical: star.physical,
          stamina: 100,
          morale: 95,
          form: 90,
          marketValue: 50_000_000,
          weeklyWage: 90_000,
          goals: 0,
          assists: 0,
          skinTone: star.skinTone,
          hairColor: star.hairColor,
          faceStyle: star.faceStyle,
          hairStyle: star.hairStyle,
          bodyType: star.bodyType,
          bootColor: star.bootColor,
          preferredFoot: star.preferredFoot,
          playstyle: star.playstyle,
          traits: star.traits,
          isCreatedStar: true,
        },
        team: 'home',
        slotIndex: 0,
        rig: starRig,
        pos: new THREE.Vector3(0, 0, 12),
        vel: new THREE.Vector3(),
        facing: Math.PI,
        stamina: 100,
        kickAnim: 0,
        kickFoot: star.preferredFoot === 'Left' ? 'left' : 'right',
        gaitPhase: 0,
        isGK: false,
      });
      this.controlledActorIndex = 0;

      // Training Goalkeeper & 4 training partners (prefer fit players)
      const fitPartners = home.roster.filter((p) => !p.injury);
      const partners = (fitPartners.length >= 5 ? fitPartners : home.roster).slice(0, 5);
      partners.forEach((p, idx) => {
        const rig = createFootballerRig(
          idx === 0 ? home.awayKit : home.trainingKit,
          p.skinTone,
          p.hairColor,
          p.number,
          this.shadowTex
        );
        this.actorsGroup.add(rig.group);
        const px = idx === 0 ? 0 : -14 + idx * 7;
        const pz = idx === 0 ? -PITCH_LENGTH / 2 + 2.2 : -14;
        this.actors.push({
          id: p.id,
          player: p,
          team: idx === 0 ? 'away' : 'home',
          slotIndex: idx,
          rig,
          pos: new THREE.Vector3(px, 0, pz),
          vel: new THREE.Vector3(),
          facing: 0,
          stamina: 96,
          kickAnim: 0,
          kickFoot: p.preferredFoot === 'Left' ? 'left' : 'right',
          gaitPhase: idx,
          isGK: idx === 0,
        });
      });
      return;
    }

    // Full 11v11 Match Actors (respecting startingXIIds and prioritizing healthy players)
    const xiOrdered =
      this.config.startingXIIds && this.config.startingXIIds.length >= 11
        ? (this.config.startingXIIds
            .map((id) => home.roster.find((p) => p.id === id))
            .filter(Boolean) as Player[])
        : home.roster;
    const fitHome = xiOrdered.filter((p) => !p.injury);
    const fitBenchExtras = home.roster.filter((p) => !p.injury && !fitHome.some((h) => h.id === p.id));
    const homePool = [...fitHome, ...fitBenchExtras, ...home.roster.filter((p) => Boolean(p.injury))];
    const homeXI = homePool.slice(0, 11);
    const awayXI = away.roster.slice(0, 11);

    homeXI.forEach((player, idx) => {
      const slot = slots[idx % slots.length];
      const useCreated =
        player.isCreatedStar || (this.config.playerLockToStar && idx === 9);
      const activePlayer: Player = useCreated
        ? {
            ...player,
            name: this.config.createdPlayer.name,
            nationality: this.config.createdPlayer.nationality,
            position: this.config.createdPlayer.position,
            secondaryPosition: this.config.createdPlayer.secondaryPosition,
            number: this.config.createdPlayer.number,
            age: this.config.createdPlayer.age,
            ovr: this.config.createdPlayer.ovr,
            pace: this.config.createdPlayer.pace,
            shooting: this.config.createdPlayer.shooting,
            passing: this.config.createdPlayer.passing,
            dribbling: this.config.createdPlayer.dribbling,
            defending: this.config.createdPlayer.defending,
            physical: this.config.createdPlayer.physical,
            skinTone: this.config.createdPlayer.skinTone,
            hairColor: this.config.createdPlayer.hairColor,
            faceStyle: this.config.createdPlayer.faceStyle,
            hairStyle: this.config.createdPlayer.hairStyle,
            bodyType: this.config.createdPlayer.bodyType,
            bootColor: this.config.createdPlayer.bootColor,
            preferredFoot: this.config.createdPlayer.preferredFoot,
            playstyle: this.config.createdPlayer.playstyle,
            traits: this.config.createdPlayer.traits,
            isCreatedStar: true,
          }
        : player;

      const kit = idx === 0 ? { ...home.awayKit, primary: '#FACC15', secondary: '#0F172A' } : home.homeKit;
      const rig = createFootballerRig(
        kit,
        activePlayer.skinTone,
        activePlayer.hairColor,
        activePlayer.number,
        this.shadowTex,
        useCreated ? this.config.createdPlayer.heightScale : 1.0,
        {
          faceStyle: activePlayer.faceStyle,
          hairStyle: activePlayer.hairStyle,
          bodyType: activePlayer.bodyType,
          bootColor: activePlayer.bootColor,
        }
      );
      this.actorsGroup.add(rig.group);
      this.actors.push({
        id: activePlayer.id,
        player: activePlayer,
        team: 'home',
        slotIndex: idx,
        rig,
        pos: new THREE.Vector3(slot.nx * halfW, 0, slot.nz * halfL),
        vel: new THREE.Vector3(),
        facing: 0,
        stamina: activePlayer.stamina,
        kickAnim: 0,
        kickFoot: activePlayer.preferredFoot === 'Left' ? 'left' : 'right',
        gaitPhase: idx * 0.7,
        isGK: idx === 0,
      });
    });

    const awaySlots = FORMATIONS['4-3-3'];
    awayXI.forEach((player, idx) => {
      const slot = awaySlots[idx % awaySlots.length];
      const kit = idx === 0 ? { ...away.homeKit, primary: '#22C55E', secondary: '#0F172A' } : away.awayKit;
      const rig = createFootballerRig(
        kit,
        player.skinTone,
        player.hairColor,
        player.number,
        this.shadowTex
      );
      this.actorsGroup.add(rig.group);
      this.actors.push({
        id: `away_${player.id}`,
        player,
        team: 'away',
        slotIndex: idx,
        rig,
        pos: new THREE.Vector3(-slot.nx * halfW, 0, -slot.nz * halfL),
        vel: new THREE.Vector3(),
        facing: Math.PI,
        stamina: player.stamina,
        kickAnim: 0,
        kickFoot: player.preferredFoot === 'Left' ? 'left' : 'right',
        gaitPhase: idx * 0.9,
        isGK: idx === 0,
      });
    });

    this.controlledActorIndex = 9;
    if (this.actors[this.controlledActorIndex]) {
      this.actors[this.controlledActorIndex].rig.ring.visible = true;
    }
  }

  private bindEvents() {
    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    this.renderer.domElement.addEventListener('webglcontextlost', this.onContextLost);
  }

  private onContextLost = (e: Event) => {
    e.preventDefault();
  };

  private onWindowBlur = () => {
    this.heldKeys.clear();
    this.chargingShot = false;
    this.shotPower = 0;
  };

  private onResize = () => {
    if (!this.container || this.disposed) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private onKeyDown = (e: KeyboardEvent) => {
    const target = e.target as HTMLElement | null;
    if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
      return;
    }
    const code = e.code;
    this.heldKeys.add(code);

    if (this.config.mode === 'title_showcase' || this.paused || this.replayActive) return;

    if (code === 'Space') {
      e.preventDefault();
      if (!this.chargingShot) {
        this.chargingShot = true;
        this.shotPower = 0.25;
      }
    } else if (code === 'KeyE') {
      this.performKick(0.72, 0.38, false);
    } else if (code === 'KeyQ') {
      this.switchControlledPlayer();
    } else if (code === 'KeyF') {
      this.performSlidePress();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.heldKeys.delete(e.code);
    if (e.code === 'Space' && this.chargingShot) {
      this.chargingShot = false;
      this.performKick(this.shotPower, this.shotPower * 0.28, this.shotPower > 0.55);
      this.shotPower = 0;
    }
  };

  private switchControlledPlayer() {
    if (this.config.playerLockToStar || this.config.mode === 'training_roam') return;
    let bestIdx = this.controlledActorIndex;
    let bestDist = Infinity;
    for (let i = 1; i < this.actors.length; i++) {
      const a = this.actors[i];
      if (a.team !== 'home' || i === this.controlledActorIndex) continue;
      const d = a.pos.distanceToSquared(this.ballPos);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    if (this.actors[this.controlledActorIndex]) {
      this.actors[this.controlledActorIndex].rig.ring.visible = false;
    }
    this.controlledActorIndex = bestIdx;
    if (this.actors[this.controlledActorIndex]) {
      this.actors[this.controlledActorIndex].rig.ring.visible = true;
    }
  }

  private performSlidePress() {
    const actor = this.actors[this.controlledActorIndex];
    if (!actor || this.kickCooldown > 0) return;
    const traits = actor.player.traits || [];
    const hasBrickWall = traits.includes('brick_wall');
    _v1.set(Math.sin(actor.facing), 0, Math.cos(actor.facing));
    actor.vel.addScaledVector(_v1, hasBrickWall ? 15.6 : 12.5);
    actor.kickAnim = 0.35;
    this.kickCooldown = 0.38;

    if (actor.pos.distanceTo(this.ballPos) < (hasBrickWall ? 2.75 : 2.2)) {
      this.ballVel.copy(_v1).multiplyScalar(hasBrickWall ? 12.5 : 11);
      this.ballVel.y = 1.6;
      this.lastTouchActor = actor;
      this.lastShotSpeedMps = this.ballVel.length();
      soundEngine.playKick(0.5);
    }

    // Check heavy lunge strain/collision injury risk on slide tackle
    if (this.config.mode === 'match' && this.injuryCooldown <= 0 && this.matchInjuryCount < 2) {
      const prevPct = this.config.injuryPreventionPct ?? 8;
      const nearbyOpp = this.actors.some(
        (other) => other.team !== actor.team && other.pos.distanceTo(actor.pos) < 1.85
      );
      if (nearbyOpp && Math.random() < (actor.stamina < 40 ? 0.16 : 0.065) * (1 - prevPct / 100)) {
        this.triggerActorInjury(actor, 'Match');
      }
    }
  }

  private triggerActorInjury(
    actor: PitchActor,
    source: 'Match' | 'Training',
    severityHint?: InjurySeverity
  ) {
    if (this.injuredThisMatch.has(actor.player.id)) return;
    if (actor.team !== 'home' || actor.isGK) return;

    const injuredPlayerId = actor.player.id;
    const injuredPlayerName = actor.player.name;
    const injuredPlayerNumber = actor.player.number;
    const injury = createPlayerInjury(source, this.config.currentWeek || 1, severityHint);
    this.injuredThisMatch.add(injuredPlayerId);
    this.matchInjuryCount += 1;
    this.injuryCooldown = 18;
    this.cameraShake = 0.25;
    soundEngine.playWhistle('kickoff');

    // Attempt automatic forced medical substitution on pitch during a live match
    const onPitchIds = new Set(this.actors.filter((a) => a.team === 'home').map((a) => a.player.id));
    const healthySub =
      source === 'Match'
        ? this.config.homeClub.roster.find(
            (p) =>
              !p.injury &&
              !this.injuredThisMatch.has(p.id) &&
              !onPitchIds.has(p.id) &&
              p.position !== 'GK'
          )
        : undefined;

    if (healthySub) {
      this.injuryBanner = `INJURY: #${injuredPlayerNumber} ${injuredPlayerName} (${injury.type} · ${injury.weeksRemaining}w) — Subbed for #${healthySub.number} ${healthySub.name}`;
      actor.id = healthySub.id;
      actor.player = healthySub;
      actor.stamina = Math.max(85, healthySub.stamina);
      actor.vel.set(0, 0, 0);
    } else {
      this.injuryBanner = `MEDICAL ALERT: #${injuredPlayerNumber} ${injuredPlayerName} · ${injury.type} (${injury.weeksRemaining} wks)`;
      actor.stamina = Math.min(actor.stamina, 24);
    }
    this.injuryBannerTimer = 4.2;

    this.config.onPlayerInjury?.(injuredPlayerId, injury);
  }

  private performPressAction() {
    const actor = this.actors[this.controlledActorIndex];
    if (!actor || this.kickCooldown > 0) return;
    _v1.subVectors(this.ballPos, actor.pos);
    _v1.y = 0;
    const dist = _v1.length();
    if (dist > 0.1) {
      _v1.normalize();
      actor.facing = Math.atan2(_v1.x, _v1.z);
      actor.vel.addScaledVector(_v1, 10.5);
    }
    if (dist < 2.35) {
      this.performSlidePress();
    }
  }

  private performClearAction() {
    const actor = this.actors[this.controlledActorIndex];
    if (!actor || this.kickCooldown > 0) return;
    const dist = actor.pos.distanceTo(this.ballPos);
    if (dist > 2.8) {
      this.performSlidePress();
      return;
    }
    actor.kickFoot = actor.player.preferredFoot === 'Left' ? 'left' : 'right';
    actor.kickAnim = 0.28;
    this.kickCooldown = 0.26;
    const dirX = Math.sin(actor.facing) * 0.45;
    const dirZ = -1;
    this.ballPos.set(
      actor.pos.x + Math.sin(actor.facing) * 0.42,
      Math.max(this.ballRadius, this.ballPos.y),
      actor.pos.z + Math.cos(actor.facing) * 0.42
    );
    this.ballVel.set(dirX * 18, 9.5, dirZ * 24);
    this.lastTouchActor = actor;
    this.lastShotSpeedMps = this.ballVel.length();
    soundEngine.playKick(0.9);
  }

  private performKick(power: number, loft: number, isShot: boolean, leadThroughPass = false) {
    const actor = this.actors[this.controlledActorIndex];
    if (!actor || this.kickCooldown > 0) return;

    const dist = actor.pos.distanceTo(this.ballPos);
    if (dist > 2.65) {
      // If far from ball on pass button, auto-switch to closest player
      if (!isShot) this.switchControlledPlayer();
      return;
    }

    const traits = actor.player.traits || [];
    const hasFinesse = traits.includes('finesse_shot');
    const hasPlaymaker = traits.includes('playmaker');
    const hasClinical = traits.includes('clinical_finisher');
    const hasDeadBall = traits.includes('set_piece_specialist');

    actor.kickFoot = actor.player.preferredFoot === 'Left' ? 'left' : 'right';
    actor.kickAnim = 0.3;
    this.kickCooldown = 0.22;

    // Determine kick direction: toward aim input or toward opponent goal (-Z)
    let dirX = Math.sin(actor.facing);
    let dirZ = Math.cos(actor.facing);

    if (!isShot) {
      // Smart pass assist toward best open teammate in facing cone (or ahead of run for Through Ball)
      let bestTeammate: PitchActor | null = null;
      let bestScore = -Infinity;
      const minDot = hasPlaymaker || leadThroughPass ? 0.1 : 0.35;
      for (const mate of this.actors) {
        if (mate.team !== 'home' || mate.id === actor.id) continue;
        _v2.subVectors(mate.pos, actor.pos);
        const d = _v2.length();
        if (d < 3 || d > (hasPlaymaker ? 56 : 48)) continue;
        _v2.normalize();
        const dot = _v2.x * dirX + _v2.z * dirZ;
        const forwardBias = leadThroughPass ? -mate.pos.z * 0.03 : 0;
        const score = dot * 2.2 - d * 0.02 + forwardBias;
        if (dot > minDot && score > bestScore) {
          bestScore = score;
          bestTeammate = mate;
        }
      }
      if (bestTeammate) {
        _v3.copy(bestTeammate.pos);
        if (leadThroughPass) {
          // Lead pass into open space ahead of teammate's run toward opponent goal (-Z)
          _v3.addScaledVector(bestTeammate.vel, 0.55);
          _v3.z -= 4.2;
        }
        _v2.subVectors(_v3, this.ballPos).normalize();
        dirX = _v2.x;
        dirZ = _v2.z;
      }
    } else {
      // Slight goal-frame assist when attacking -Z goal
      if (this.ballPos.z < 10) {
        const goalTargetX = THREE.MathUtils.clamp(dirX * 14, -GOAL_WIDTH * 0.44, GOAL_WIDTH * 0.44);
        _v2.set(goalTargetX - this.ballPos.x, 0, -PITCH_LENGTH / 2 - this.ballPos.z).normalize();
        const assistWeight = hasClinical ? 0.72 : 0.55;
        dirX = THREE.MathUtils.lerp(dirX, _v2.x, assistWeight);
        dirZ = THREE.MathUtils.lerp(dirZ, _v2.z, assistWeight);
      }
    }

    // Snap foot-to-ball strike contact point right at the kicking cleat toe
    actor.facing = Math.atan2(dirX, dirZ);
    const footSide = actor.kickFoot === 'left' ? -0.11 : 0.11;
    const rx = Math.cos(actor.facing);
    const rz = -Math.sin(actor.facing);
    this.ballPos.set(
      actor.pos.x + dirX * 0.45 + rx * footSide,
      Math.max(this.ballRadius, this.ballPos.y),
      actor.pos.z + dirZ * 0.45 + rz * footSide
    );

    const baseShotSpeed = (18 + power * 20) * (0.9 + (actor.player.shooting / 100) * 0.18);
    const speed = isShot
      ? baseShotSpeed * (hasFinesse ? 1.1 : 1.0)
      : (13 + power * 13) * (hasPlaymaker ? 1.12 : 1.0);
    const loftBoost = hasDeadBall && !isShot ? loft * 1.25 : loft;
    this.ballVel.set(dirX * speed, 2.2 + loftBoost * 14, dirZ * speed);

    // Add realistic Magnus sidespin based on lateral movement & Finesse Curler trait
    const spinMul = hasFinesse ? 1.35 : 1.0;
    this.ballSpin.set(0, (dirX * 12 - actor.vel.x * 1.4) * spinMul, 0);
    this.lastTouchActor = actor;
    this.lastShotSpeedMps = this.ballVel.length();
    soundEngine.playKick(power);
  }

  private updateBallPhysics(dt: number) {
    // Sub-step twice for crisp collision stability
    const subDt = dt * 0.5;
    for (let s = 0; s < 2; s++) {
      // Gravity
      this.ballVel.y -= 18.5 * subDt;

      // Air drag
      const speedSq = this.ballVel.lengthSq();
      if (speedSq > 0.01) {
        this.ballVel.multiplyScalar(Math.max(0, 1 - 0.16 * subDt));
      }

      // Magnus Spin Curve Force: F_m = k * (spin x velocity)
      _magnus.crossVectors(this.ballSpin, this.ballVel).multiplyScalar(0.032 * subDt);
      this.ballVel.add(_magnus);
      this.ballSpin.multiplyScalar(Math.max(0, 1 - 0.45 * subDt));

      // Integrate position
      this.ballPos.addScaledVector(this.ballVel, subDt);

      // Turf floor bounce & rolling friction
      if (this.ballPos.y <= this.ballRadius) {
        this.ballPos.y = this.ballRadius;
        if (this.ballVel.y < -0.9) {
          this.ballVel.y = -this.ballVel.y * 0.66;
        } else {
          this.ballVel.y = 0;
        }
        // Grass rolling resistance
        this.ballVel.x *= Math.max(0, 1 - 1.35 * subDt);
        this.ballVel.z *= Math.max(0, 1 - 1.35 * subDt);
      }

      // Goalposts & Goal Detection
      const halfGoalW = GOAL_WIDTH / 2;
      const halfPitchW = PITCH_WIDTH / 2;
      const halfPitchL = PITCH_LENGTH / 2;

      const checkGoalEnd = (goalZ: number, sign: number) => {
        const pastLine = sign < 0 ? this.ballPos.z < goalZ : this.ballPos.z > goalZ;
        if (!pastLine) return false;

        // Post collisions
        for (const px of [-halfGoalW, halfGoalW]) {
          const dx = this.ballPos.x - px;
          const dz = this.ballPos.z - goalZ;
          const dist = Math.hypot(dx, dz);
          if (dist < this.ballRadius + 0.09 && this.ballPos.y < GOAL_HEIGHT + 0.1) {
            const nx = dx / (dist || 1);
            const nz = dz / (dist || 1);
            const dot = this.ballVel.x * nx + this.ballVel.z * nz;
            if (dot < 0) {
              const speedBefore = this.ballVel.length();
              this.ballVel.x -= 1.8 * dot * nx;
              this.ballVel.z -= 1.8 * dot * nz;
              soundEngine.playPostHit();
              this.cameraShake = 0.25;
              if (this.config.mode === 'match' && speedBefore > 8 && this.highlightCooldownPost <= 0) {
                this.highlightCooldownPost = 3.0;
                const shooter = this.lastTouchActor;
                const attackingTeam = sign < 0 ? 'home' : 'away';
                const clubName =
                  attackingTeam === 'home' ? this.config.homeClub.shortName : this.config.awayClub.shortName;
                this.captureHighlight({
                  type: 'woodwork',
                  title: `Off the Woodwork!`,
                  subtitle: `${shooter?.player.name || clubName} rattles the frame`,
                  team: attackingTeam,
                  playerName: shooter?.player.name || clubName,
                  playerNumber: shooter?.player.number || 9,
                  targetGoalZ: goalZ,
                  shotSpeedKmh: Math.round(Math.max(speedBefore, this.lastShotSpeedMps) * 3.6),
                });
              }
            }
          }
        }

        // Inside Goal Box!
        if (Math.abs(this.ballPos.x) < halfGoalW - 0.15 && this.ballPos.y < GOAL_HEIGHT) {
          // Damp inside net
          const maxBackZ = goalZ + sign * (GOAL_DEPTH - 0.25);
          if ((sign < 0 && this.ballPos.z < maxBackZ) || (sign > 0 && this.ballPos.z > maxBackZ)) {
            this.ballPos.z = maxBackZ;
            this.ballVel.multiplyScalar(0.25);
          }
          if (sign < 0) this.netRippleAway = 1.0;
          else this.netRippleHome = 1.0;

          if (this.config.mode === 'match' && this.goalCelebrationTimer <= 0) {
            const scoringTeam: 'home' | 'away' = sign < 0 ? 'home' : 'away';
            const shooter =
              this.lastTouchActor && this.lastTouchActor.team === scoringTeam
                ? this.lastTouchActor
                : this.actors.find((a) => a.team === scoringTeam && !a.isGK) || null;
            if (scoringTeam === 'home') {
              this.homeScore += 1;
              this.goalBanner = `GOAL! ${shooter?.player.name || this.config.homeClub.name} (${this.getCurrentMatchMinute()}')`;
            } else {
              this.awayScore += 1;
              this.goalBanner = `GOAL! ${shooter?.player.name || this.config.awayClub.name} (${this.getCurrentMatchMinute()}')`;
            }
            const clubName =
              scoringTeam === 'home' ? this.config.homeClub.name : this.config.awayClub.name;
            this.captureHighlight({
              type: 'goal',
              title: `GOAL! ${shooter?.player.name || clubName}`,
              subtitle: `${clubName} strike into the net`,
              team: scoringTeam,
              playerName: shooter?.player.name || clubName,
              playerNumber: shooter?.player.number || 9,
              targetGoalZ: goalZ,
              shotSpeedKmh: Math.round(Math.max(this.ballVel.length(), this.lastShotSpeedMps) * 3.6),
            });
            const styles: ('arms_wide' | 'siuu_leap' | 'knee_slide')[] = [
              'arms_wide',
              'siuu_leap',
              'knee_slide',
            ];
            this.celebratingScorerIndex = shooter ? this.actors.indexOf(shooter) : -1;
            this.celebratingTeam = scoringTeam;
            this.celebrationStyle = styles[(this.homeScore + this.awayScore) % styles.length];
            this.celebrationElapsed = 0;
            const sideSign = shooter && shooter.pos.x >= 0 ? 1 : -1;
            this.celebrationTarget.set(
              sideSign * (PITCH_WIDTH * 0.42),
              0,
              goalZ + (goalZ < 0 ? 6.5 : -6.5)
            );
            this.goalCelebrationTimer = 4.0;
            this.cameraShake = 0.45;
            soundEngine.playCrowdGoalRoar();
            soundEngine.playWhistle('kickoff');
          } else if (this.config.mode === 'training_roam' && this.goalCelebrationTimer <= 0) {
            this.goalBanner = 'TOP BIN FINISH!';
            this.celebratingScorerIndex = this.controlledActorIndex;
            this.celebratingTeam = 'home';
            this.celebrationStyle = 'siuu_leap';
            this.celebrationElapsed = 0;
            this.celebrationTarget.set(0, 0, goalZ + 10);
            this.goalCelebrationTimer = 2.2;
            soundEngine.playCrowdGoalRoar();
          }
          return true;
        }

        // Fast close miss just past goal line without scoring -> capture 'chance'
        if (
          this.config.mode === 'match' &&
          this.goalCelebrationTimer <= 0 &&
          this.highlightCooldownChance <= 0 &&
          Math.abs(this.ballPos.x) < GOAL_WIDTH * 1.15 &&
          this.ballVel.length() > 13.5
        ) {
          this.highlightCooldownChance = 4.5;
          const attackingTeam: 'home' | 'away' = sign < 0 ? 'home' : 'away';
          const shooter = this.lastTouchActor;
          this.captureHighlight({
            type: 'chance',
            title: `Close Effort!`,
            subtitle: `${shooter?.player.name || 'Forward'} flashes a strike just wide`,
            team: attackingTeam,
            playerName: shooter?.player.name || 'Striker',
            playerNumber: shooter?.player.number || 9,
            targetGoalZ: goalZ,
            shotSpeedKmh: Math.round(Math.max(this.ballVel.length(), this.lastShotSpeedMps) * 3.6),
          });
        }
        return false;
      };

      const inAwayGoal = checkGoalEnd(-halfPitchL, -1);
      const inHomeGoal = checkGoalEnd(halfPitchL, 1);

      // Keep ball inside playable stadium perimeter if not inside net
      if (!inAwayGoal && !inHomeGoal) {
        if (Math.abs(this.ballPos.x) > halfPitchW + 2.5) {
          this.ballPos.x = Math.sign(this.ballPos.x) * (halfPitchW + 2.5);
          this.ballVel.x *= -0.72;
        }
        if (Math.abs(this.ballPos.z) > halfPitchL + 2.5) {
          this.ballPos.z = Math.sign(this.ballPos.z) * (halfPitchL + 2.5);
          this.ballVel.z *= -0.72;
        }
      }
    }

    // Visual ball spin rotation
    this.ballMesh.position.copy(this.ballPos);
    this.ballMesh.rotation.x += this.ballVel.z * dt * 2.2;
    this.ballMesh.rotation.z -= this.ballVel.x * dt * 2.2;

    this.ballShadow.position.set(this.ballPos.x, 0.014, this.ballPos.z);
    const heightScale = Math.max(0.4, 1 - this.ballPos.y * 0.1);
    this.ballShadow.scale.setScalar(heightScale);
  }

  private updateCelebrationActors(dt: number) {
    this.celebrationElapsed += dt;
    const scorer =
      this.celebratingScorerIndex >= 0 ? this.actors[this.celebratingScorerIndex] : null;

    for (let i = 0; i < this.actors.length; i++) {
      const actor = this.actors[i];
      if (i === this.celebratingScorerIndex && scorer) {
        if (this.celebrationElapsed < 1.35) {
          // Phase 1: Sprint away toward corner flag / touchline with airplane arms
          _v1.subVectors(this.celebrationTarget, actor.pos);
          _v1.y = 0;
          const dist = _v1.length();
          if (dist > 0.5) {
            _v1.normalize();
            actor.vel.x = THREE.MathUtils.damp(actor.vel.x, _v1.x * 8.6, 10, dt);
            actor.vel.z = THREE.MathUtils.damp(actor.vel.z, _v1.z * 8.6, 10, dt);
            actor.facing = Math.atan2(actor.vel.x, actor.vel.z);
          }
          actor.pos.addScaledVector(actor.vel, dt);
          actor.gaitPhase += dt * 13;
          actor.rig.group.position.set(actor.pos.x, 0, actor.pos.z);
          actor.rig.group.rotation.y = actor.facing;
          actor.rig.torso.rotation.x = -0.12;
          actor.rig.leftLeg.rotation.x = Math.sin(actor.gaitPhase) * 0.72;
          actor.rig.rightLeg.rotation.x = -Math.sin(actor.gaitPhase) * 0.72;
          actor.rig.leftArm.rotation.set(-0.45, 0, -1.25);
          actor.rig.rightArm.rotation.set(-0.45, 0, 1.25);
        } else {
          // Phase 2: Signature Celebration Pose (Knee Slide, Siuuu Leap, or Fist Pump)
          const phase = this.celebrationElapsed - 1.35;
          if (this.celebrationStyle === 'knee_slide') {
            actor.vel.multiplyScalar(Math.max(0, 1 - 1.7 * dt));
            actor.pos.addScaledVector(actor.vel, dt);
            actor.rig.group.position.set(actor.pos.x, -0.22, actor.pos.z);
            actor.rig.group.rotation.y = actor.facing;
            actor.rig.torso.rotation.x = -0.24;
            actor.rig.leftLeg.rotation.set(1.15, 0, 0);
            actor.rig.rightLeg.rotation.set(1.15, 0, 0);
            actor.rig.leftArm.rotation.set(-2.15 + Math.sin(phase * 12) * 0.25, 0, -0.35);
            actor.rig.rightArm.rotation.set(-2.15 - Math.sin(phase * 12) * 0.25, 0, 0.35);
          } else if (this.celebrationStyle === 'siuu_leap') {
            actor.vel.multiplyScalar(Math.max(0, 1 - 6 * dt));
            const jumpT = Math.min(1, phase / 0.8);
            const jumpY = jumpT < 1 ? Math.sin(jumpT * Math.PI) * 1.15 : 0;
            const spinYaw = jumpT < 1 ? jumpT * Math.PI : Math.PI;
            actor.rig.group.position.set(actor.pos.x, jumpY, actor.pos.z);
            actor.rig.group.rotation.y = actor.facing + spinYaw;
            actor.rig.torso.rotation.x = -0.15;
            actor.rig.leftLeg.rotation.set(0, 0, jumpT >= 0.85 ? -0.18 : 0.25);
            actor.rig.rightLeg.rotation.set(0, 0, jumpT >= 0.85 ? 0.18 : -0.25);
            actor.rig.leftArm.rotation.set(0.42, 0, -1.08);
            actor.rig.rightArm.rotation.set(0.42, 0, 1.08);
          } else {
            actor.vel.multiplyScalar(Math.max(0, 1 - 5 * dt));
            const bounce = Math.abs(Math.sin(phase * 7.2)) * 0.42;
            actor.rig.group.position.set(actor.pos.x, bounce, actor.pos.z);
            actor.rig.group.rotation.y = actor.facing;
            actor.rig.torso.rotation.x = -0.14;
            actor.rig.leftLeg.rotation.set(bounce * 0.5, 0, 0);
            actor.rig.rightLeg.rotation.set(-bounce * 0.5, 0, 0);
            actor.rig.leftArm.rotation.set(-2.35, 0, -0.5);
            actor.rig.rightArm.rotation.set(-2.35, 0, 0.5);
          }
        }
      } else if (actor.team === this.celebratingTeam && !actor.isGK && scorer) {
        // Teammates rush over to mob & celebrate with the scorer
        _v1.subVectors(scorer.pos, actor.pos);
        _v1.y = 0;
        const d = _v1.length();
        if (d > 2.4 && d < 36) {
          _v1.normalize();
          actor.vel.x = THREE.MathUtils.damp(actor.vel.x, _v1.x * 7.4, 8, dt);
          actor.vel.z = THREE.MathUtils.damp(actor.vel.z, _v1.z * 7.4, 8, dt);
          actor.facing = Math.atan2(actor.vel.x, actor.vel.z);
          actor.pos.addScaledVector(actor.vel, dt);
          actor.gaitPhase += dt * 11;
          actor.rig.leftLeg.rotation.x = Math.sin(actor.gaitPhase) * 0.65;
          actor.rig.rightLeg.rotation.x = -Math.sin(actor.gaitPhase) * 0.65;
        } else {
          actor.vel.multiplyScalar(Math.max(0, 1 - 6 * dt));
          actor.facing = Math.atan2(scorer.pos.x - actor.pos.x, scorer.pos.z - actor.pos.z);
          actor.rig.leftLeg.rotation.x = 0;
          actor.rig.rightLeg.rotation.x = 0;
        }
        const hop = d <= 4.5 ? Math.abs(Math.sin(this.celebrationElapsed * 6.5 + i)) * 0.26 : 0;
        actor.rig.group.position.set(actor.pos.x, hop, actor.pos.z);
        actor.rig.group.rotation.y = actor.facing;
        actor.rig.leftArm.rotation.set(-1.95, 0, -0.3);
        actor.rig.rightArm.rotation.set(-1.95, 0, 0.3);
      } else {
        // Conceding team & keepers settle back calmly
        actor.vel.multiplyScalar(Math.max(0, 1 - 5 * dt));
        actor.rig.group.position.set(actor.pos.x, 0, actor.pos.z);
        actor.rig.torso.rotation.x = 0.08;
        actor.rig.leftArm.rotation.set(0, 0, 0);
        actor.rig.rightArm.rotation.set(0, 0, 0);
        actor.rig.leftLeg.rotation.set(0, 0, 0);
        actor.rig.rightLeg.rotation.set(0, 0, 0);
      }
    }
  }

  private updateActors(dt: number) {
    if (this.goalCelebrationTimer > 0 && this.celebratingTeam !== null) {
      this.updateCelebrationActors(dt);
      return;
    }

    const isTraining = this.config.mode === 'training_roam';
    const isShowcase = this.config.mode === 'title_showcase';
    const slots = FORMATIONS[this.config.tactics.formation];
    const halfW = PITCH_WIDTH * 0.46;
    const halfL = PITCH_LENGTH * 0.47;

    // Tactics modifiers
    let linePush = 0;
    if (this.config.tactics.mentality === 'All-Out Attack') linePush = 11;
    else if (this.config.tactics.mentality === 'Attacking') linePush = 6;
    else if (this.config.tactics.mentality === 'Defensive') linePush = -6;
    else if (this.config.tactics.mentality === 'Ultra Defensive') linePush = -11;

    const pressRadius =
      this.config.tactics.pressing === 'Gegenpress'
        ? 22
        : this.config.tactics.pressing === 'Mid Press'
          ? 14
          : 8;

    // Nearest AI chasers
    let closestHomeChaser = -1;
    let closestHomeDist = Infinity;
    let closestAwayChaser = -1;
    let closestAwayDist = Infinity;

    for (let i = 0; i < this.actors.length; i++) {
      const a = this.actors[i];
      if (a.isGK) continue;
      const d = a.pos.distanceToSquared(this.ballPos);
      if (a.team === 'home' && i !== this.controlledActorIndex && d < closestHomeDist) {
        closestHomeDist = d;
        closestHomeChaser = i;
      }
      if (a.team === 'away' && d < closestAwayDist) {
        closestAwayDist = d;
        closestAwayChaser = i;
      }
    }

    for (let i = 0; i < this.actors.length; i++) {
      const actor = this.actors[i];
      const isControlled = !isShowcase && i === this.controlledActorIndex;

      let moveX = 0;
      let moveZ = 0;
      let sprinting = false;

      if (isControlled) {
        if (this.heldKeys.has('KeyW') || this.heldKeys.has('ArrowUp')) moveZ -= 1;
        if (this.heldKeys.has('KeyS') || this.heldKeys.has('ArrowDown')) moveZ += 1;
        if (this.heldKeys.has('KeyA') || this.heldKeys.has('ArrowLeft')) moveX -= 1;
        if (this.heldKeys.has('KeyD') || this.heldKeys.has('ArrowRight')) moveX += 1;

        moveX += this.touchMove.x;
        moveZ += this.touchMove.y;
        const stickMag = Math.hypot(this.touchMove.x, this.touchMove.y);
        sprinting =
          this.touchSprint ||
          stickMag > 0.85 ||
          this.heldKeys.has('ShiftLeft') ||
          this.heldKeys.has('ShiftRight');

        if (this.chargingShot) {
          this.shotPower = Math.min(1.0, this.shotPower + dt * 1.15);
        }
      } else if (isTraining) {
        // Training partners or GK
        if (actor.isGK) {
          const targetX = THREE.MathUtils.clamp(this.ballPos.x * 0.55, -GOAL_WIDTH * 0.42, GOAL_WIDTH * 0.42);
          moveX = targetX - actor.pos.x;
          moveZ = (-PITCH_LENGTH / 2 + 1.8) - actor.pos.z;
        } else {
          // Gentle support run
          const angle = this.matchSeconds * 0.5 + actor.slotIndex;
          const tx = Math.cos(angle) * 14;
          const tz = Math.sin(angle) * 14;
          moveX = tx - actor.pos.x;
          moveZ = tz - actor.pos.z;
        }
      } else {
        // AI Positioning & Pressing
        const slot = slots[actor.slotIndex % slots.length] || slots[5];
        const sideSign = actor.team === 'home' ? 1 : -1;

        if (actor.isGK) {
          const gkZ = sideSign * (PITCH_LENGTH / 2 - 2.2);
          const gkX = THREE.MathUtils.clamp(this.ballPos.x * 0.45, -GOAL_WIDTH * 0.42, GOAL_WIDTH * 0.42);
          moveX = gkX - actor.pos.x;
          moveZ = gkZ - actor.pos.z;
        } else {
          const isChaser =
            (actor.team === 'home' && i === closestHomeChaser && (isShowcase || Math.sqrt(closestHomeDist) < pressRadius)) ||
            (actor.team === 'away' && i === closestAwayChaser);

          if (isChaser) {
            moveX = this.ballPos.x - actor.pos.x;
            moveZ = this.ballPos.z - actor.pos.z;
            sprinting = true;
          } else {
            const ballFollowZ = this.ballPos.z * 0.35;
            const push = actor.team === 'home' ? -linePush : 0;
            const tx = slot.nx * halfW * sideSign + this.ballPos.x * 0.22;
            const tz = THREE.MathUtils.clamp(
              slot.nz * halfL * sideSign + ballFollowZ + push,
              -halfL,
              halfL
            );
            moveX = tx - actor.pos.x;
            moveZ = tz - actor.pos.z;
          }
        }
      }

      // Compute velocity with player traits
      const len = Math.hypot(moveX, moveZ);
      const actorTraits = actor.player.traits || [];
      const hasSpeedster = actorTraits.includes('speedster');
      const hasBoxToBox = actorTraits.includes('box_to_box');
      const baseSpeed = 5.4 + (actor.player.pace / 99) * 3.4;
      const sprintBonus = hasSpeedster ? 1.44 : 1.32;
      const maxSpeed = sprinting && actor.stamina > 12 ? baseSpeed * sprintBonus : baseSpeed;

      if (len > 0.15) {
        const nx = moveX / len;
        const nz = moveZ / len;
        const desiredSpeed = isControlled ? maxSpeed : Math.min(maxSpeed * 0.88, len * 3.0);
        actor.vel.x = THREE.MathUtils.damp(actor.vel.x, nx * desiredSpeed, 10, dt);
        actor.vel.z = THREE.MathUtils.damp(actor.vel.z, nz * desiredSpeed, 10, dt);
        actor.facing = Math.atan2(actor.vel.x, actor.vel.z);

        if (sprinting && isControlled) {
          const drainRate = hasSpeedster ? 4.6 : 6.5;
          actor.stamina = Math.max(5, actor.stamina - dt * drainRate);

          // Exhausted sprint strain check in match or training (outside gym recovery zone)
          if (
            !isShowcase &&
            actor.stamina < 24 &&
            this.injuryCooldown <= 0 &&
            this.matchInjuryCount < 2 &&
            !(isTraining && this.inGymZone)
          ) {
            const prevPct = this.config.injuryPreventionPct ?? 8;
            const strainChance = dt * (isTraining ? 0.08 : 0.055) * (1 - prevPct / 100);
            if (Math.random() < strainChance) {
              this.triggerActorInjury(
                actor,
                isTraining ? 'Training' : 'Match',
                isTraining ? 'Minor' : undefined
              );
            }
          }
        }
      } else {
        actor.vel.x = THREE.MathUtils.damp(actor.vel.x, 0, 12, dt);
        actor.vel.z = THREE.MathUtils.damp(actor.vel.z, 0, 12, dt);
        actor.stamina = Math.min(100, actor.stamina + dt * (hasBoxToBox ? 6.2 : 4.5));
      }

      actor.pos.addScaledVector(actor.vel, dt);

      // Movement bounds: allow Training & Gym free roam everywhere into the Gym Pavilion (-55 to +38)!
      const minX = isTraining ? -53 : -PITCH_WIDTH / 2 - 2;
      const maxX = PITCH_WIDTH / 2 + 2;
      const minZ = -PITCH_LENGTH / 2 - 2;
      const maxZ = PITCH_LENGTH / 2 + 2;

      actor.pos.x = THREE.MathUtils.clamp(actor.pos.x, minX, maxX);
      actor.pos.z = THREE.MathUtils.clamp(actor.pos.z, minZ, maxZ);

      // Check if created player walked into the Club Gym Pavilion
      if (isTraining && isControlled) {
        const nowInGym = actor.pos.x < -38 && Math.abs(actor.pos.z + 6) < 12;
        if (nowInGym !== this.inGymZone) {
          this.inGymZone = nowInGym;
          this.config.onGymZoneEnter?.(nowInGym);
        }
        if (nowInGym) {
          actor.stamina = Math.min(100, actor.stamina + dt * 18);
        }
      }

      // FC Mobile Style Ball-to-Leg / Cleat Contact Physics
      const distToBall = actor.pos.distanceTo(this.ballPos);
      if (distToBall < (actor.isGK ? 1.5 : 1.32) && this.ballPos.y < (actor.isGK ? 2.1 : 1.35) && this.kickCooldown <= 0) {
        if (actor.team === 'home') this.homeTouches++;
        else this.awayTouches++;

        if (isControlled) {
          // Keep the ball right in front of the player's dribbling foot/cleat with responsive close control
          const fx = Math.sin(actor.facing);
          const fz = Math.cos(actor.facing);
          const rx = Math.cos(actor.facing);
          const rz = -Math.sin(actor.facing);
          const actorSpeed = Math.hypot(actor.vel.x, actor.vel.z);
          const sinGait = Math.sin(actor.gaitPhase);
          const footSide = sinGait >= 0 ? 0.11 : -0.11;
          const contactAhead =
            actorSpeed > 0.35 ? 0.43 + Math.min(0.22, actorSpeed * 0.022) : 0.41;

          const targetBallX = actor.pos.x + fx * contactAhead + rx * footSide;
          const targetBallZ = actor.pos.z + fz * contactAhead + rz * footSide;
          const dribSkill = 0.68 + (actor.player.dribbling / 99) * 0.32;
          const snap = 1 - Math.exp(-(16 * dribSkill) * dt);

          this.ballPos.x = THREE.MathUtils.lerp(this.ballPos.x, targetBallX, snap);
          this.ballPos.z = THREE.MathUtils.lerp(this.ballPos.z, targetBallZ, snap);
          this.ballPos.y = Math.max(
            this.ballRadius,
            THREE.MathUtils.damp(this.ballPos.y, this.ballRadius, 14, dt)
          );

          // Micro-tap impulse synced with leg stride touching the ball
          if (Math.abs(sinGait) > 0.82 && actorSpeed > 1.2 && this.dribbleTouchCooldown <= 0) {
            const tapSpeed = Math.max(3.8, actorSpeed * (sprinting ? 1.15 : 1.04));
            this.ballVel.x = fx * tapSpeed;
            this.ballVel.z = fz * tapSpeed;
            this.ballVel.y = Math.max(0, this.ballVel.y * 0.25);
            this.dribbleTouchCooldown = 0.17;
          } else {
            this.ballVel.x = THREE.MathUtils.lerp(this.ballVel.x, actor.vel.x * 1.02, 0.72);
            this.ballVel.z = THREE.MathUtils.lerp(this.ballVel.z, actor.vel.z * 1.02, 0.72);
          }
          this.lastTouchActor = actor;
        } else if (actor.isGK) {
          // Check if incoming ball was a shot on goal -> record Key Save highlight!
          const incomingSpeed = this.ballVel.length();
          const towardGoal =
            (actor.team === 'away' && this.ballVel.z < -7.0) ||
            (actor.team === 'home' && this.ballVel.z > 7.0);
          if (
            this.config.mode === 'match' &&
            towardGoal &&
            incomingSpeed > 9.0 &&
            this.highlightCooldownSave <= 0
          ) {
            this.highlightCooldownSave = 3.2;
            const gkGoalZ = actor.team === 'away' ? -PITCH_LENGTH / 2 : PITCH_LENGTH / 2;
            const clubName =
              actor.team === 'home' ? this.config.homeClub.shortName : this.config.awayClub.shortName;
            this.captureHighlight({
              type: 'save',
              title: `Key Save! ${actor.player.name}`,
              subtitle: `${clubName} keeper denies a dangerous effort`,
              team: actor.team,
              playerName: actor.player.name,
              playerNumber: actor.player.number,
              targetGoalZ: gkGoalZ,
              shotSpeedKmh: Math.round(incomingSpeed * 3.6),
            });
          }

          // Goalkeeper clears ball forward off boot
          const clearDirZ = actor.team === 'home' ? -1 : 1;
          this.ballVel.set((Math.random() - 0.5) * 10, 7.5, clearDirZ * 20);
          actor.kickFoot = actor.player.preferredFoot === 'Left' ? 'left' : 'right';
          actor.kickAnim = 0.25;
          this.lastTouchActor = actor;
          soundEngine.playKick(0.75);
        } else {
          // AI pass, shoot, or close-control dribble on cleat
          const attackingGoalZ = actor.team === 'home' ? -PITCH_LENGTH / 2 : PITCH_LENGTH / 2;
          const distToGoal = Math.abs(actor.pos.z - attackingGoalZ);

          if (distToGoal < 24 && Math.random() < 0.08) {
            // AI shoots on target
            const targetX = (Math.random() - 0.5) * (GOAL_WIDTH * 0.85);
            _v1.set(targetX - this.ballPos.x, 0, attackingGoalZ - this.ballPos.z).normalize();
            this.ballVel.set(_v1.x * 23, 3.2 + Math.random() * 3.5, _v1.z * 23);
            this.ballSpin.set(0, (Math.random() - 0.5) * 8, 0);
            actor.kickFoot = actor.player.preferredFoot === 'Left' ? 'left' : 'right';
            actor.kickAnim = 0.26;
            this.lastTouchActor = actor;
            this.lastShotSpeedMps = this.ballVel.length();
            soundEngine.playKick(0.8);
          } else if (Math.random() < 0.045) {
            // AI passes to teammate
            const mates = this.actors.filter((m) => m.team === actor.team && m.id !== actor.id);
            const mate = mates[Math.floor(Math.random() * mates.length)];
            if (mate) {
              _v1.subVectors(mate.pos, this.ballPos).normalize();
              this.ballVel.set(_v1.x * 16, 1.5, _v1.z * 16);
              actor.kickFoot = actor.player.preferredFoot === 'Left' ? 'left' : 'right';
              actor.kickAnim = 0.22;
              this.lastTouchActor = actor;
              soundEngine.playKick(0.5);
            }
          } else {
            // AI dribbles close to cleat toward attacking goal
            const fx = Math.sin(actor.facing);
            const fz = Math.cos(actor.facing);
            const targetX = actor.pos.x + fx * 0.46;
            const targetZ = actor.pos.z + fz * 0.46;
            const snap = 1 - Math.exp(-10 * dt);
            this.ballPos.x = THREE.MathUtils.lerp(this.ballPos.x, targetX, snap);
            this.ballPos.z = THREE.MathUtils.lerp(this.ballPos.z, targetZ, snap);
            _v1.set(
              (Math.random() - 0.5) * 0.4,
              0,
              actor.team === 'home' ? -1 : 1
            ).normalize();
            this.ballVel.x = _v1.x * 7.6;
            this.ballVel.z = _v1.z * 7.6;
            this.lastTouchActor = actor;
          }
        }
      }

      // Procedural Limb Gait, Torso Sprint Lean & Preferred-Foot Kick Animation
      const speed = Math.hypot(actor.vel.x, actor.vel.z);
      actor.gaitPhase += dt * (2.5 + speed * 1.45);
      const swing = Math.min(0.85, speed * 0.095);
      actor.rig.torso.rotation.x = THREE.MathUtils.damp(
        actor.rig.torso.rotation.x,
        Math.min(0.24, speed * 0.022),
        10,
        dt
      );

      if (actor.kickAnim > 0) {
        actor.kickAnim = Math.max(0, actor.kickAnim - dt);
        const kickSwing = -1.25 * Math.sin((actor.kickAnim / 0.3) * Math.PI);
        if (actor.kickFoot === 'left') {
          actor.rig.leftLeg.rotation.x = kickSwing;
          actor.rig.rightLeg.rotation.x = 0.32;
        } else {
          actor.rig.rightLeg.rotation.x = kickSwing;
          actor.rig.leftLeg.rotation.x = 0.32;
        }
      } else if (speed > 0.3) {
        actor.rig.leftLeg.rotation.x = Math.sin(actor.gaitPhase) * swing;
        actor.rig.rightLeg.rotation.x = -Math.sin(actor.gaitPhase) * swing;
        actor.rig.leftArm.rotation.x = -Math.sin(actor.gaitPhase) * swing * 0.7;
        actor.rig.rightArm.rotation.x = Math.sin(actor.gaitPhase) * swing * 0.7;
      } else {
        actor.rig.leftLeg.rotation.x = THREE.MathUtils.damp(actor.rig.leftLeg.rotation.x, 0, 10, dt);
        actor.rig.rightLeg.rotation.x = THREE.MathUtils.damp(actor.rig.rightLeg.rotation.x, 0, 10, dt);
        actor.rig.leftArm.rotation.x = THREE.MathUtils.damp(actor.rig.leftArm.rotation.x, 0, 10, dt);
        actor.rig.rightArm.rotation.x = THREE.MathUtils.damp(actor.rig.rightArm.rotation.x, 0, 10, dt);
      }

      actor.rig.group.position.x = actor.pos.x;
      actor.rig.group.position.z = actor.pos.z;
      actor.rig.group.position.y = THREE.MathUtils.damp(actor.rig.group.position.y, 0, 14, dt);
      actor.rig.group.rotation.y = actor.facing;
    }

    // High-speed opposing player collision injury check during match
    if (
      this.config.mode === 'match' &&
      this.injuryCooldown <= 0 &&
      this.matchInjuryCount < 2
    ) {
      const prevPct = this.config.injuryPreventionPct ?? 8;
      for (const hActor of this.actors) {
        if (hActor.team !== 'home' || hActor.isGK) continue;
        const hSpeed = Math.hypot(hActor.vel.x, hActor.vel.z);
        if (hSpeed < 5.5) continue;
        for (const aActor of this.actors) {
          if (aActor.team !== 'away' || aActor.isGK) continue;
          if (hActor.pos.distanceToSquared(aActor.pos) < 1.35) {
            const relSpeed = Math.hypot(
              hActor.vel.x - aActor.vel.x,
              hActor.vel.z - aActor.vel.z
            );
            if (relSpeed > 9.5) {
              const fatigueBonus = hActor.stamina < 45 ? 1.8 : 1.0;
              const physShield = Math.max(0.55, 1.35 - hActor.player.physical / 140);
              const prob = dt * 0.65 * fatigueBonus * physShield * (1 - prevPct / 100);
              if (Math.random() < prob) {
                this.triggerActorInjury(hActor, 'Match');
                break;
              }
            }
          }
        }
        if (this.injuryCooldown > 0) break;
      }
    }
  }

  private updateCamera(dt: number) {
    if (this.config.mode === 'title_showcase') {
      const t = performance.now() * 0.00018;
      _camPos.set(Math.cos(t) * 52, 24 + Math.sin(t * 2) * 3, Math.sin(t) * 56);
      this.camera.position.lerp(_camPos, 1 - Math.exp(-3 * dt));
      this.camera.lookAt(0, 1.5, 0);
      return;
    }

    if (
      this.goalCelebrationTimer > 0 &&
      this.celebratingScorerIndex >= 0 &&
      this.actors[this.celebratingScorerIndex]
    ) {
      const scorer = this.actors[this.celebratingScorerIndex];
      const orbitAngle = scorer.facing + 0.55 + this.celebrationElapsed * 0.32;
      _camPos.set(
        scorer.pos.x + Math.sin(orbitAngle) * 6.8,
        2.35,
        scorer.pos.z + Math.cos(orbitAngle) * 6.8
      );
      _camTarget.set(
        scorer.pos.x,
        1.3 + Math.max(0, scorer.rig.group.position.y) * 0.65,
        scorer.pos.z
      );
      const lambda = 1 - Math.exp(-6.5 * dt);
      this.camera.position.lerp(_camPos, lambda);
      this.camera.lookAt(_camTarget);
      return;
    }

    const active = this.actors[this.controlledActorIndex];
    const mode = this.config.cameraMode;

    if (mode === 'pro_player' && active) {
      _camPos.set(active.pos.x, 5.2, active.pos.z + 12.5);
      _camTarget.set(
        THREE.MathUtils.lerp(active.pos.x, this.ballPos.x, 0.35),
        1.2,
        THREE.MathUtils.lerp(active.pos.z - 6, this.ballPos.z, 0.35)
      );
    } else if (mode === 'follow') {
      const focusX = active ? THREE.MathUtils.lerp(active.pos.x, this.ballPos.x, 0.55) : this.ballPos.x;
      const focusZ = active ? THREE.MathUtils.lerp(active.pos.z, this.ballPos.z, 0.55) : this.ballPos.z;
      _camPos.set(focusX * 0.72, 16, focusZ + 26);
      _camTarget.set(focusX, 0.8, focusZ);
    } else if (mode === 'tactical') {
      _camPos.set(this.ballPos.x * 0.35, 58, this.ballPos.z * 0.35 + 14);
      _camTarget.set(this.ballPos.x * 0.35, 0, this.ballPos.z * 0.35);
    } else {
      // Broadcast TV Cam (East touchline elevated view)
      _camPos.set(
        42 + this.ballPos.x * 0.25,
        24,
        this.ballPos.z * 0.75 + 10
      );
      _camTarget.set(this.ballPos.x * 0.5, 0.8, this.ballPos.z * 0.82);
    }

    if (this.cameraShake > 0) {
      this.cameraShake = Math.max(0, this.cameraShake - dt * 1.4);
      _camPos.x += (Math.random() - 0.5) * this.cameraShake * 1.6;
      _camPos.y += (Math.random() - 0.5) * this.cameraShake * 1.6;
    }

    const lambda = 1 - Math.exp(-5.5 * dt);
    this.camera.position.lerp(_camPos, lambda);
    this.camera.lookAt(_camTarget);
  }

  private updateEffects(dt: number, elapsed: number) {
    // Rain streaks
    if (this.rainPoints) {
      const posAttr = this.rainPoints.geometry.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < posAttr.count; i++) {
        let y = posAttr.getY(i) - dt * 26;
        if (y < 0) y = 28;
        posAttr.setY(i, y);
      }
      posAttr.needsUpdate = true;
    }

    // Crowd subtle jump animation on goals
    if (this.crowdMesh && this.crowdBaseMatrices.length > 0) {
      const excitement = this.goalCelebrationTimer > 0 ? 0.65 : 0.08;
      for (let i = 0; i < this.crowdBaseMatrices.length; i++) {
        _v1.setFromMatrixPosition(this.crowdBaseMatrices[i]);
        const bounce = Math.abs(Math.sin(elapsed * 5 + i)) * excitement;
        _dummy.position.set(_v1.x, _v1.y + bounce, _v1.z);
        _dummy.scale.setScalar(0.95);
        _dummy.updateMatrix();
        this.crowdMesh.setMatrixAt(i, _dummy.matrix);
      }
      this.crowdMesh.instanceMatrix.needsUpdate = true;
    }

    // Net ripple
    if (this.netRippleAway > 0 && this.awayGoalNet) {
      this.netRippleAway = Math.max(0, this.netRippleAway - dt * 1.2);
      this.awayGoalNet.scale.z = 1 + Math.sin(elapsed * 28) * 0.14 * this.netRippleAway;
    }
    if (this.netRippleHome > 0 && this.homeGoalNet) {
      this.netRippleHome = Math.max(0, this.netRippleHome - dt * 1.2);
      this.homeGoalNet.scale.z = 1 + Math.sin(elapsed * 28) * 0.14 * this.netRippleHome;
    }
  }

  private emitHUD() {
    const active = this.actors[this.controlledActorIndex];
    const totalTouches = this.homeTouches + this.awayTouches;
    const matchMinute = Math.min(
      90,
      Math.floor((this.matchSeconds / this.matchHalfDuration) * 45) + (this.half === 2 ? 45 : 0)
    );

    const radarDots: MatchHUDState['radarDots'] = this.actors.map((a, idx) => ({
      x: a.pos.x / (PITCH_WIDTH / 2),
      z: a.pos.z / (PITCH_LENGTH / 2),
      team: idx === this.controlledActorIndex ? 'controlled' : a.team,
    }));
    radarDots.push({
      x: this.ballPos.x / (PITCH_WIDTH / 2),
      z: this.ballPos.z / (PITCH_LENGTH / 2),
      team: 'ball',
    });

    let closestHomeSq = Infinity;
    let closestAwaySq = Infinity;
    for (const a of this.actors) {
      const d = a.pos.distanceToSquared(this.ballPos);
      if (a.team === 'home' && d < closestHomeSq) closestHomeSq = d;
      if (a.team === 'away' && d < closestAwaySq) closestAwaySq = d;
    }
    const teamHasPossession: 'home' | 'away' | 'loose' =
      this.config.mode === 'training_roam'
        ? 'home'
        : closestAwaySq < 7.5 && closestAwaySq < closestHomeSq * 0.78
          ? 'away'
          : closestHomeSq < 12 || this.lastTouchActor?.team !== 'away'
            ? 'home'
            : 'away';

    const injuredPlayerCount = this.config.homeClub.roster.filter((p) => Boolean(p.injury)).length;

    this.config.onHUDUpdate({
      homeName: this.config.homeClub.shortName,
      awayName: this.config.awayClub.shortName,
      homeColor: this.config.homeClub.homeKit.primary,
      awayColor: this.config.awayClub.awayKit.primary,
      homeScore: this.homeScore,
      awayScore: this.awayScore,
      matchMinute,
      half: this.half,
      shotPower: this.shotPower,
      activePlayerName: active?.player.name || this.config.createdPlayer.name,
      activePlayerNumber: active?.player.number || this.config.createdPlayer.number,
      activePlayerStamina: Math.round(active?.stamina || 95),
      possessionHome: Math.round((this.homeTouches / totalTouches) * 100),
      teamHasPossession,
      goalBanner: this.goalBanner,
      injuryBanner: this.injuryBanner,
      injuredPlayerCount,
      mode: this.config.mode === 'training_roam' ? 'training_roam' : 'match',
      radarDots,
    });
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private snapshotReplayFrame(): ReplayFrame {
    const ball = new Float32Array(6);
    ball[0] = this.ballPos.x;
    ball[1] = this.ballPos.y;
    ball[2] = this.ballPos.z;
    ball[3] = this.ballMesh.rotation.x;
    ball[4] = this.ballMesh.rotation.y;
    ball[5] = this.ballMesh.rotation.z;

    const actors = new Float32Array(this.actors.length * 7);
    for (let i = 0; i < this.actors.length; i++) {
      const a = this.actors[i];
      const base = i * 7;
      actors[base] = a.pos.x;
      actors[base + 1] = a.pos.z;
      actors[base + 2] = a.facing;
      actors[base + 3] = a.rig.leftLeg.rotation.x;
      actors[base + 4] = a.rig.rightLeg.rotation.x;
      actors[base + 5] = a.rig.leftArm.rotation.x;
      actors[base + 6] = a.rig.rightArm.rotation.x;
    }
    return { ball, actors };
  }

  private getCurrentMatchMinute(): number {
    return Math.min(
      90,
      Math.max(
        1,
        Math.floor((this.matchSeconds / this.matchHalfDuration) * 45) + (this.half === 2 ? 45 : 0)
      )
    );
  }

  private captureHighlight(meta: {
    type: HighlightType;
    title: string;
    subtitle: string;
    team: 'home' | 'away';
    playerName: string;
    playerNumber: number;
    targetGoalZ: number;
    shotSpeedKmh: number;
  }) {
    if (this.config.mode !== 'match' || this.replayActive) return;
    const preFrames = this.replayPreBuffer.slice();
    if (preFrames.length === 0) {
      preFrames.push(this.snapshotReplayFrame());
    }
    this.pendingHighlights.push({
      ...meta,
      minute: this.getCurrentMatchMinute(),
      scoreText: `${this.config.homeClub.shortName} ${this.homeScore} - ${this.awayScore} ${this.config.awayClub.shortName}`,
      peakIndex: preFrames.length - 1,
      postRemaining: REPLAY_POST_FRAMES,
      frames: preFrames,
    });
  }

  private recordHighlightSample(dt: number) {
    if (this.config.mode !== 'match' || this.matchEnded) return;
    this.replaySampleAccum += dt;
    const interval = 1 / REPLAY_FPS;
    if (this.replaySampleAccum < interval) return;
    this.replaySampleAccum %= interval;

    const frame = this.snapshotReplayFrame();
    this.replayPreBuffer.push(frame);
    if (this.replayPreBuffer.length > REPLAY_PRE_FRAMES) {
      this.replayPreBuffer.shift();
    }

    if (this.pendingHighlights.length > 0) {
      const stillPending: PendingHighlight[] = [];
      for (const pending of this.pendingHighlights) {
        pending.frames.push(frame);
        pending.postRemaining -= 1;
        if (pending.postRemaining <= 0) {
          this.finalizeHighlight(pending);
        } else {
          stillPending.push(pending);
        }
      }
      this.pendingHighlights = stillPending;
    }
  }

  private flushPendingHighlights() {
    if (this.pendingHighlights.length === 0) return;
    const items = this.pendingHighlights.splice(0, this.pendingHighlights.length);
    for (const pending of items) {
      if (pending.frames.length < 4) {
        pending.frames.push(this.snapshotReplayFrame());
      }
      this.finalizeHighlight(pending);
    }
  }

  private finalizeHighlight(pending: PendingHighlight) {
    if (pending.frames.length < 2) return;
    const durationSec = Math.max(0.5, (pending.frames.length - 1) / REPLAY_FPS);
    const peakSec = THREE.MathUtils.clamp(pending.peakIndex / REPLAY_FPS, 0, durationSec);
    const clip: RecordedHighlight = {
      summary: {
        id: `hl_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        type: pending.type,
        title: pending.title,
        subtitle: pending.subtitle,
        minute: pending.minute,
        team: pending.team,
        playerName: pending.playerName,
        playerNumber: pending.playerNumber,
        scoreText: pending.scoreText,
        durationSec,
        peakSec,
        shotSpeedKmh: pending.shotSpeedKmh,
      },
      targetGoalZ: pending.targetGoalZ,
      frames: pending.frames,
    };

    this.recordedHighlights.push(clip);
    if (this.recordedHighlights.length > MAX_HIGHLIGHTS) {
      // Keep goals first, drop oldest non-goal chance if over capacity
      const nonGoalIdx = this.recordedHighlights.findIndex(
        (h) => h.summary.type === 'chance'
      );
      if (nonGoalIdx >= 0) {
        this.recordedHighlights.splice(nonGoalIdx, 1);
      } else {
        const nonGoalAny = this.recordedHighlights.findIndex((h) => h.summary.type !== 'goal');
        this.recordedHighlights.splice(nonGoalAny >= 0 ? nonGoalAny : 0, 1);
      }
    }
    this.config.onHighlightsChange?.(this.getMatchHighlights());
  }

  private applyReplayFrame(clip: RecordedHighlight, timeSec: number) {
    const frames = clip.frames;
    if (frames.length === 0) return;

    const exactIdx = THREE.MathUtils.clamp(timeSec * REPLAY_FPS, 0, frames.length - 1);
    const i0 = Math.floor(exactIdx);
    const i1 = Math.min(frames.length - 1, i0 + 1);
    const alpha = exactIdx - i0;
    const f0 = frames[i0];
    const f1 = frames[i1];

    const bx = THREE.MathUtils.lerp(f0.ball[0], f1.ball[0], alpha);
    const by = THREE.MathUtils.lerp(f0.ball[1], f1.ball[1], alpha);
    const bz = THREE.MathUtils.lerp(f0.ball[2], f1.ball[2], alpha);
    this.ballPos.set(bx, by, bz);
    this.ballMesh.position.set(bx, by, bz);
    this.ballMesh.rotation.set(
      THREE.MathUtils.lerp(f0.ball[3], f1.ball[3], alpha),
      THREE.MathUtils.lerp(f0.ball[4], f1.ball[4], alpha),
      THREE.MathUtils.lerp(f0.ball[5], f1.ball[5], alpha)
    );
    this.ballShadow.position.set(bx, 0.014, bz);
    this.ballShadow.scale.setScalar(Math.max(0.4, 1 - by * 0.1));

    const actorCount = Math.min(this.actors.length, Math.floor(f0.actors.length / 7));
    for (let i = 0; i < actorCount; i++) {
      const a = this.actors[i];
      const b = i * 7;
      const ax = THREE.MathUtils.lerp(f0.actors[b], f1.actors[b], alpha);
      const az = THREE.MathUtils.lerp(f0.actors[b + 1], f1.actors[b + 1], alpha);
      const facing = lerpAngle(f0.actors[b + 2], f1.actors[b + 2], alpha);

      a.pos.set(ax, 0, az);
      a.facing = facing;
      a.rig.group.position.set(ax, 0, az);
      a.rig.group.rotation.y = facing;
      a.rig.leftLeg.rotation.x = THREE.MathUtils.lerp(f0.actors[b + 3], f1.actors[b + 3], alpha);
      a.rig.rightLeg.rotation.x = THREE.MathUtils.lerp(f0.actors[b + 4], f1.actors[b + 4], alpha);
      a.rig.leftArm.rotation.x = THREE.MathUtils.lerp(f0.actors[b + 5], f1.actors[b + 5], alpha);
      a.rig.rightArm.rotation.x = THREE.MathUtils.lerp(f0.actors[b + 6], f1.actors[b + 6], alpha);
    }
  }

  private updateReplayCamera(dt: number, clip: RecordedHighlight) {
    const bx = this.ballPos.x;
    const by = this.ballPos.y;
    const bz = this.ballPos.z;
    const zSign = clip.targetGoalZ < 0 ? -1 : 1;

    if (this.replayCamera === 'goal_cam') {
      _camPos.set(
        THREE.MathUtils.clamp(bx * 0.35, -5.2, 5.2),
        2.3,
        clip.targetGoalZ + zSign * 4.4
      );
      _camTarget.set(bx * 0.72, Math.max(0.85, by * 0.8), bz * 0.9);
    } else if (this.replayCamera === 'action_follow') {
      _camPos.set(bx * 0.85 + 7.5, 4.8, bz - zSign * 11.2);
      _camTarget.set(bx, Math.max(0.8, by * 0.85), bz);
    } else {
      // 'tv_broadcast'
      _camPos.set(34 + bx * 0.25, 18.5, bz * 0.78 + 8);
      _camTarget.set(bx * 0.65, 0.9, bz * 0.88);
    }

    if (this.cameraShake > 0) {
      this.cameraShake = Math.max(0, this.cameraShake - dt * 1.4);
      _camPos.x += (Math.random() - 0.5) * this.cameraShake * 1.3;
      _camPos.y += (Math.random() - 0.5) * this.cameraShake * 1.3;
    }

    const lambda = 1 - Math.exp(-7.5 * dt);
    this.camera.position.lerp(_camPos, lambda);
    this.camera.lookAt(_camTarget);
  }

  private emitReplayState() {
    const clip = this.recordedHighlights[this.replayClipIndex];
    this.config.onReplayUpdate?.({
      active: this.replayActive,
      highlightId: clip?.summary.id || null,
      paused: this.replayPaused,
      speed: this.replaySpeed,
      camera: this.replayCamera,
      currentTime: this.replayTime,
      duration: clip?.summary.durationSec || 0,
      autoPlay: this.replayAutoPlay,
    });
  }

  private tickReplay(dt: number, elapsed: number) {
    const clip = this.recordedHighlights[this.replayClipIndex];
    if (!clip) {
      this.stopHighlightReplay();
      return;
    }

    if (!this.replayPaused) {
      this.replayPrevTime = this.replayTime;
      this.replayTime += dt * this.replaySpeed;

      // Peak moment visual punch (net ripple & sound) when crossing peakSec
      if (
        clip.summary.type === 'goal' &&
        this.replayPrevTime < clip.summary.peakSec &&
        this.replayTime >= clip.summary.peakSec
      ) {
        if (clip.targetGoalZ < 0) this.netRippleAway = 1.0;
        else this.netRippleHome = 1.0;
        this.cameraShake = 0.28;
        soundEngine.playCrowdGoalRoar();
      } else if (
        clip.summary.type === 'woodwork' &&
        this.replayPrevTime < clip.summary.peakSec &&
        this.replayTime >= clip.summary.peakSec
      ) {
        this.cameraShake = 0.2;
        soundEngine.playPostHit();
      }

      if (this.replayTime >= clip.summary.durationSec) {
        if (this.replayAutoPlay && this.replayClipIndex < this.recordedHighlights.length - 1) {
          this.replayClipIndex += 1;
          this.replayTime = 0;
          this.replayPrevTime = 0;
          this.netRippleAway = 0;
          this.netRippleHome = 0;
        } else {
          this.replayTime = clip.summary.durationSec;
          this.replayPaused = true;
          this.emitReplayState();
        }
      }
    }

    const activeClip = this.recordedHighlights[this.replayClipIndex] || clip;
    this.applyReplayFrame(activeClip, this.replayTime);
    this.updateEffects(dt, elapsed);
    this.updateReplayCamera(dt, activeClip);

    this.replayEmitTimer += dt;
    if (this.replayEmitTimer >= 0.05) {
      this.replayEmitTimer = 0;
      this.emitReplayState();
    }
  }

  private tick = () => {
    if (this.disposed) return;
    const now = performance.now();
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (this.replayActive) {
      this.tickReplay(dt, now * 0.001);
    } else if (!this.paused) {
      if (this.kickCooldown > 0) this.kickCooldown -= dt;
      if (this.dribbleTouchCooldown > 0) this.dribbleTouchCooldown -= dt;
      if (this.injuryCooldown > 0) this.injuryCooldown -= dt;
      if (this.injuryBannerTimer > 0) {
        this.injuryBannerTimer -= dt;
        if (this.injuryBannerTimer <= 0) {
          this.injuryBanner = null;
        }
      }
      if (this.highlightCooldownSave > 0) this.highlightCooldownSave -= dt;
      if (this.highlightCooldownPost > 0) this.highlightCooldownPost -= dt;
      if (this.highlightCooldownChance > 0) this.highlightCooldownChance -= dt;

      if (this.goalCelebrationTimer > 0) {
        this.goalCelebrationTimer -= dt;
        if (this.goalCelebrationTimer <= 0) {
          this.goalBanner = null;
          if (this.config.mode === 'match') {
            this.resetKickoff();
          } else {
            this.ballPos.set(0, this.ballRadius, 6);
            this.ballVel.set(0, 0, 0);
          }
        }
      }

      if (this.config.mode === 'match' && !this.matchEnded && this.goalCelebrationTimer <= 0) {
        this.matchSeconds += dt;
        if (this.matchSeconds >= this.matchHalfDuration) {
          if (this.half === 1) {
            this.half = 2;
            this.matchSeconds = 0;
            this.goalBanner = 'SECOND HALF KICKOFF';
            this.goalCelebrationTimer = 1.6;
            soundEngine.playWhistle('kickoff');
          } else {
            this.matchEnded = true;
            this.flushPendingHighlights();
            soundEngine.playWhistle('fulltime');
            this.config.onMatchEnd?.(this.homeScore, this.awayScore);
          }
        }
      }

      this.updateActors(dt);
      this.updateBallPhysics(dt);
      this.recordHighlightSample(dt);
      this.updateEffects(dt, now * 0.001);
      this.updateCamera(dt);

      this.hudEmitTimer += dt;
      if (this.hudEmitTimer >= 0.08 && this.config.mode !== 'title_showcase') {
        this.hudEmitTimer = 0;
        this.emitHUD();
      }
    }

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    this.renderer.domElement.removeEventListener('webglcontextlost', this.onContextLost);

    this.replayPreBuffer = [];
    this.pendingHighlights = [];
    this.recordedHighlights = [];
    this.clearGroup(this.environmentGroup);
    this.clearGroup(this.actorsGroup);
    this.ballMesh.geometry.dispose();
    (this.ballMesh.material as THREE.Material).dispose();
    this.ballShadow.geometry.dispose();
    (this.ballShadow.material as THREE.Material).dispose();
    this.shadowTex.dispose();

    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
