import * as THREE from 'three';
import { BodyType, Club, FaceStyle, HairStyle, KitColors, StadiumTheme } from '../types/game';
import { BODY_TYPES } from '../data/playerCustomization';

export const PITCH_WIDTH = 68;
export const PITCH_LENGTH = 104;
export const GOAL_WIDTH = 7.32;
export const GOAL_HEIGHT = 2.44;
export const GOAL_DEPTH = 2.4;

export function createPitchTexture(theme: StadiumTheme, maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1536;
  canvas.height = 2048;
  const ctx = canvas.getContext('2d')!;

  const isRainy = theme === 'rainy_derby';
  const isTraining = theme === 'training_gym';
  const isGolden = theme === 'golden_hour';

  // Alternating mowed grass stripes with subtle vertical & horizontal mow sheen
  const stripeCount = 18;
  const stripeH = canvas.height / stripeCount;
  for (let i = 0; i < stripeCount; i++) {
    const even = i % 2 === 0;
    ctx.fillStyle = even
      ? isRainy
        ? '#124924'
        : isTraining
          ? '#166b31'
          : isGolden
            ? '#1a6c2e'
            : '#166a31'
      : isRainy
        ? '#17582c'
        : isTraining
          ? '#1b7f3b'
          : isGolden
            ? '#217e36'
            : '#1d7f3c';
    ctx.fillRect(0, i * stripeH, canvas.width, stripeH + 1);
  }

  // Subtle cross-cut stadium mower bands
  for (let x = 0; x < canvas.width; x += canvas.width / 12) {
    ctx.fillStyle = (Math.floor(x / (canvas.width / 12)) % 2 === 0)
      ? 'rgba(255,255,255,0.018)'
      : 'rgba(0,0,0,0.022)';
    ctx.fillRect(x, 0, canvas.width / 12, canvas.height);
  }

  // Organic grass blade & soil grain
  for (let i = 0; i < 16000; i++) {
    const gx = Math.random() * canvas.width;
    const gy = Math.random() * canvas.height;
    ctx.fillStyle = i % 3 === 0 ? 'rgba(187, 247, 208, 0.035)' : 'rgba(6, 40, 18, 0.045)';
    ctx.fillRect(gx, gy, 2, 4);
  }

  const padX = 84;
  const padY = 84;
  const w = canvas.width - padX * 2;
  const h = canvas.height - padY * 2;
  const midX = canvas.width / 2;
  const midY = canvas.height / 2;

  // Natural turf wear in the 6-yard goalmouths and center spot
  const drawWearSpot = (wx: number, wy: number, rx: number, ry: number) => {
    const grad = ctx.createRadialGradient(wx, wy, rx * 0.15, wx, wy, rx);
    grad.addColorStop(0, 'rgba(101, 78, 42, 0.22)');
    grad.addColorStop(0.6, 'rgba(68, 86, 36, 0.12)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.save();
    ctx.translate(wx, wy);
    ctx.scale(1, ry / rx);
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(0, 0, rx, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };
  drawWearSpot(midX, padY + 38, 120, 62);
  drawWearSpot(midX, padY + h - 38, 120, 62);
  drawWearSpot(midX, midY, 64, 64);

  // Crisp FIFA chalk pitch markings
  ctx.strokeStyle = 'rgba(248, 250, 252, 0.94)';
  ctx.lineWidth = 7;

  // Outer touchlines & goal lines
  ctx.strokeRect(padX, padY, w, h);

  // Halfway line & center circle
  ctx.beginPath();
  ctx.moveTo(padX, midY);
  ctx.lineTo(padX + w, midY);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(midX, midY, 165, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = '#F8FAFC';
  ctx.beginPath();
  ctx.arc(midX, midY, 9, 0, Math.PI * 2);
  ctx.fill();

  // Penalty areas (top and bottom)
  const boxW = w * 0.56;
  const boxH = h * 0.16;
  const sixW = w * 0.26;
  const sixH = h * 0.055;

  // Top Penalty Box
  ctx.strokeRect(midX - boxW / 2, padY, boxW, boxH);
  ctx.strokeRect(midX - sixW / 2, padY, sixW, sixH);
  ctx.beginPath();
  ctx.arc(midX, padY + h * 0.105, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(midX, padY + h * 0.105, 146, 0.21 * Math.PI, 0.79 * Math.PI);
  ctx.stroke();

  // Bottom Penalty Box
  ctx.strokeRect(midX - boxW / 2, padY + h - boxH, boxW, boxH);
  ctx.strokeRect(midX - sixW / 2, padY + h - sixH, sixW, sixH);
  ctx.beginPath();
  ctx.arc(midX, padY + h - h * 0.105, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(midX, padY + h - h * 0.105, 146, 1.21 * Math.PI, 1.79 * Math.PI);
  ctx.stroke();

  // Corner arcs
  const cr = 30;
  ctx.beginPath();
  ctx.arc(padX, padY, cr, 0, Math.PI * 0.5);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(padX + w, padY, cr, Math.PI * 0.5, Math.PI);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(padX + w, padY + h, cr, Math.PI, Math.PI * 1.5);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(padX, padY + h, cr, Math.PI * 1.5, Math.PI * 2);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

export function createPitchRoughnessTexture(theme: StadiumTheme): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const isRainy = theme === 'rainy_derby';

  const stripeCount = 18;
  const stripeH = canvas.height / stripeCount;
  for (let i = 0; i < stripeCount; i++) {
    const val = i % 2 === 0 ? (isRainy ? 105 : 210) : (isRainy ? 140 : 235);
    ctx.fillStyle = `rgb(${val}, ${val}, ${val})`;
    ctx.fillRect(0, i * stripeH, canvas.width, stripeH + 1);
  }

  for (let i = 0; i < 4000; i++) {
    const v = isRainy ? 80 + Math.random() * 90 : 170 + Math.random() * 75;
    ctx.fillStyle = `rgb(${v}, ${v}, ${v})`;
    ctx.fillRect(Math.random() * 512, Math.random() * 512, 2, 3);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.NoColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createSoccerBallTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Matte off-white pro leather panels
  const bgGrad = ctx.createLinearGradient(0, 0, 0, 512);
  bgGrad.addColorStop(0, '#F8FAFC');
  bgGrad.addColorStop(0.5, '#EEF2F6');
  bgGrad.addColorStop(1, '#E2E8F0');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 1024, 512);

  // Subtle stitched seam grid
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.22)';
  ctx.lineWidth = 3;
  for (let x = 0; x <= 1024; x += 128) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + 64, 512);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x + 64, 0);
    ctx.lineTo(x, 512);
    ctx.stroke();
  }

  // Modern tournament pentagon accents
  const centers = [
    [128, 128],
    [384, 128],
    [640, 128],
    [896, 128],
    [256, 384],
    [512, 384],
    [768, 384],
  ];
  for (const [cx, cy] of centers) {
    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 - Math.PI / 2;
      const px = cx + Math.cos(a) * 52;
      const py = cy + Math.sin(a) * 52;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();

    // Inner gold/emerald trim accent
    ctx.strokeStyle = '#10B981';
    ctx.lineWidth = 5;
    ctx.stroke();
  }

  // Equator graphic stripe
  ctx.strokeStyle = '#0284C7';
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(0, 256);
  ctx.lineTo(1024, 256);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createKitTexture(kit: KitColors, number: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = kit.primary;
  ctx.fillRect(0, 0, 256, 256);

  if (kit.pattern === 'stripes') {
    ctx.fillStyle = kit.secondary;
    for (let x = 0; x < 256; x += 36) {
      ctx.fillRect(x, 0, 18, 256);
    }
  } else if (kit.pattern === 'hoops') {
    ctx.fillStyle = kit.secondary;
    for (let y = 0; y < 256; y += 36) {
      ctx.fillRect(0, y, 256, 16);
    }
  } else if (kit.pattern === 'sash') {
    ctx.fillStyle = kit.secondary;
    ctx.beginPath();
    ctx.moveTo(0, 220);
    ctx.lineTo(256, 20);
    ctx.lineTo(256, 70);
    ctx.lineTo(0, 256);
    ctx.closePath();
    ctx.fill();
  } else if (kit.pattern === 'halved') {
    ctx.fillStyle = kit.secondary;
    ctx.fillRect(128, 0, 128, 256);
  }

  // Subtle breathable mesh fabric micro-grain
  ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
  for (let y = 0; y < 256; y += 4) {
    ctx.fillRect(0, y, 256, 1);
  }

  // Collar trim & side seam highlight
  ctx.fillStyle = kit.secondary;
  ctx.fillRect(0, 0, 256, 16);

  // Dorsal squad number
  ctx.fillStyle = 'rgba(15, 23, 42, 0.28)';
  ctx.fillRect(88, 72, 80, 92);

  ctx.fillStyle =
    kit.primary === '#FFFFFF' ||
    kit.primary === '#F8FAFC' ||
    kit.primary === '#FDE047' ||
    kit.primary === '#FDE100'
      ? '#0F172A'
      : '#FFFFFF';
  ctx.font = 'bold 64px Barlow Condensed, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(number), 128, 120);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createFaceTexture(
  skinTone: string,
  hairColor: string,
  faceStyle: FaceStyle = 'athletic'
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = skinTone;
  ctx.fillRect(0, 0, 256, 128);

  const cx = 128;
  const cy = 64;

  // Natural ambient facial shading (forehead & under-jaw)
  const jawShade = ctx.createLinearGradient(0, cy + 12, 0, 128);
  jawShade.addColorStop(0, 'rgba(0,0,0,0)');
  jawShade.addColorStop(1, 'rgba(0,0,0,0.18)');
  ctx.fillStyle = jawShade;
  ctx.fillRect(0, cy + 12, 256, 64);

  // Cheekbone warmth / angular contour
  ctx.fillStyle =
    faceStyle === 'sharp' ? 'rgba(0,0,0,0.12)' : 'rgba(180, 75, 65, 0.14)';
  ctx.beginPath();
  ctx.ellipse(cx - 22, cy + 10, 9, 5, 0, 0, Math.PI * 2);
  ctx.ellipse(cx + 22, cy + 10, 9, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Beard / Stubble styles
  if (faceStyle === 'sharp') {
    ctx.fillStyle = hairColor;
    ctx.globalAlpha = 0.65;
    ctx.beginPath();
    ctx.ellipse(cx, cy + 28, 12, 9, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  } else if (faceStyle === 'sculpted') {
    ctx.fillStyle = hairColor;
    ctx.globalAlpha = 0.72;
    ctx.beginPath();
    ctx.ellipse(cx, cy + 24, 24, 15, 0, 0, Math.PI);
    ctx.fill();
    ctx.globalAlpha = 1;
  } else if (faceStyle === 'veteran') {
    ctx.fillStyle = hairColor;
    ctx.globalAlpha = 0.88;
    ctx.beginPath();
    ctx.ellipse(cx, cy + 22, 29, 20, 0, 0, Math.PI);
    ctx.fill();
    ctx.fillRect(cx - 14, cy + 14, 28, 5);
    ctx.globalAlpha = 1;
  }

  // Eyes (whites + dark irises + highlight)
  ctx.fillStyle = '#F8FAFC';
  ctx.beginPath();
  ctx.ellipse(cx - 14, cy - 4, 5.5, 3.2, 0, 0, Math.PI * 2);
  ctx.ellipse(cx + 14, cy - 4, 5.5, 3.2, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#0F172A';
  ctx.beginPath();
  ctx.arc(cx - 14, cy - 4, 2.5, 0, Math.PI * 2);
  ctx.arc(cx + 14, cy - 4, 2.5, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(cx - 15, cy - 5, 0.9, 0, Math.PI * 2);
  ctx.arc(cx + 13, cy - 5, 0.9, 0, Math.PI * 2);
  ctx.fill();

  // Eyebrows
  ctx.strokeStyle = hairColor;
  ctx.lineWidth = faceStyle === 'veteran' ? 4 : faceStyle === 'youthful' ? 2.4 : 3.2;
  ctx.lineCap = 'round';
  ctx.beginPath();
  if (faceStyle === 'sharp' || faceStyle === 'veteran') {
    ctx.moveTo(cx - 21, cy - 12);
    ctx.lineTo(cx - 8, cy - 9.5);
    ctx.moveTo(cx + 8, cy - 9.5);
    ctx.lineTo(cx + 21, cy - 12);
  } else {
    ctx.moveTo(cx - 20, cy - 10.5);
    ctx.lineTo(cx - 8, cy - 11);
    ctx.moveTo(cx + 8, cy - 11);
    ctx.lineTo(cx + 20, cy - 10.5);
  }
  ctx.stroke();

  // Nose bridge shadow
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.18)';
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.moveTo(cx, cy - 2);
  ctx.lineTo(cx - 2, cy + 9);
  ctx.lineTo(cx + 2, cy + 9);
  ctx.stroke();

  // Mouth
  ctx.strokeStyle = faceStyle === 'youthful' ? '#9F4A44' : '#7C3A36';
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.moveTo(cx - 8, cy + 17);
  ctx.quadraticCurveTo(cx, cy + 20, cx + 8, cy + 17);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 8, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.58)');
  grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.26)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

export interface FootballerAppearance {
  faceStyle?: FaceStyle;
  hairStyle?: HairStyle;
  bodyType?: BodyType;
  bootColor?: string;
}

export interface FootballerRig {
  group: THREE.Group;
  torso: THREE.Mesh;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  ring: THREE.Mesh;
  updateKit: (kit: KitColors, number: number) => void;
}

export function createFootballerRig(
  kit: KitColors,
  skinTone: string,
  hairColor: string,
  number: number,
  shadowTex: THREE.CanvasTexture,
  heightScale = 1.0,
  appearance: FootballerAppearance = {}
): FootballerRig {
  const group = new THREE.Group();

  const faceStyle = appearance.faceStyle ?? 'athletic';
  const hairStyle = appearance.hairStyle ?? 'short_crop';
  const bodyType = appearance.bodyType ?? 'athletic';
  const bootColor = appearance.bootColor ?? '#0F172A';

  const bodyPreset = BODY_TYPES.find((b) => b.id === bodyType) || BODY_TYPES[1];
  const wScale = bodyPreset.widthScale;
  const lScale = bodyPreset.limbScale;

  // 1. Contact shadow disc grounded at y=0.015
  const shadowGeo = new THREE.PlaneGeometry(1.22 * wScale, 1.22 * wScale);
  const shadowMat = new THREE.MeshBasicMaterial({
    map: shadowTex,
    transparent: true,
    depthWrite: false,
    opacity: 0.74,
  });
  const shadow = new THREE.Mesh(shadowGeo, shadowMat);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  group.add(shadow);

  // 2. Selection ring (eFootball style emerald ring)
  const ringGeo = new THREE.RingGeometry(0.56, 0.72, 32);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0x10b981,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.92,
  });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.025;
  ring.visible = false;
  group.add(ring);

  const bodyRoot = new THREE.Group();
  bodyRoot.scale.setScalar(heightScale);
  group.add(bodyRoot);

  const faceTex = createFaceTexture(skinTone, hairColor, faceStyle);
  const headMat = new THREE.MeshStandardMaterial({
    map: faceTex,
    roughness: 0.52,
    metalness: 0.02,
  });
  const skinMat = new THREE.MeshStandardMaterial({ color: skinTone, roughness: 0.54, metalness: 0.02 });
  const hairMat = new THREE.MeshStandardMaterial({ color: hairColor, roughness: 0.86, metalness: 0.02 });
  const shortsMat = new THREE.MeshStandardMaterial({ color: kit.shorts, roughness: 0.56, metalness: 0.08 });
  const socksMat = new THREE.MeshStandardMaterial({ color: kit.socks, roughness: 0.78, metalness: 0.02 });
  const sockBandMat = new THREE.MeshStandardMaterial({ color: kit.secondary, roughness: 0.65, metalness: 0.05 });
  const cleatMat = new THREE.MeshPhysicalMaterial({
    color: bootColor,
    roughness: 0.24,
    metalness: 0.32,
    clearcoat: 0.65,
    clearcoatRoughness: 0.2,
  });
  const soleMat = new THREE.MeshStandardMaterial({ color: '#E2E8F0', roughness: 0.22, metalness: 0.78 });

  let kitTex = createKitTexture(kit, number);
  const jerseyMat = new THREE.MeshStandardMaterial({
    map: kitTex,
    roughness: 0.82,
    metalness: 0.03,
  });
  const sleeveMat = new THREE.MeshStandardMaterial({
    color: kit.primary,
    roughness: 0.82,
    metalness: 0.03,
  });
  const collarMat = new THREE.MeshStandardMaterial({
    color: kit.secondary,
    roughness: 0.7,
    metalness: 0.05,
  });

  // 3. Sculpted Tapered Athletic Torso & Shoulders
  const torso = new THREE.Mesh(
    new THREE.CylinderGeometry(0.245 * wScale, 0.195 * wScale, 0.56, 16),
    jerseyMat
  );
  torso.scale.set(1.0, 1.0, 0.64);
  torso.position.y = 1.15;
  torso.rotation.y = Math.PI; // Dorsal squad number cleanly on back (-Z)
  torso.castShadow = true;
  bodyRoot.add(torso);

  // Athletic rounded shoulder deltoid cap & collar trim
  const shoulderGeo = new THREE.SphereGeometry(0.082 * wScale, 12, 10);
  const leftShoulder = new THREE.Mesh(shoulderGeo, sleeveMat);
  leftShoulder.position.set(-0.245 * wScale, 1.38, 0);
  const rightShoulder = new THREE.Mesh(shoulderGeo, sleeveMat);
  rightShoulder.position.set(0.245 * wScale, 1.38, 0);
  const collarRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.085, 0.02, 8, 16),
    collarMat
  );
  collarRing.rotation.x = Math.PI / 2;
  collarRing.position.y = 1.435;
  bodyRoot.add(leftShoulder, rightShoulder, collarRing);

  // 4. Sculpted Shorts Pelvis
  const pelvis = new THREE.Mesh(
    new THREE.CylinderGeometry(0.195 * wScale, 0.215 * wScale, 0.23, 14),
    shortsMat
  );
  pelvis.scale.set(1.0, 1.0, 0.68);
  pelvis.position.y = 0.78;
  pelvis.castShadow = true;
  bodyRoot.add(pelvis);

  // Neck
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.054, 0.066, 0.12, 12), skinMat);
  neck.position.y = 1.48;
  bodyRoot.add(neck);

  // 5. Head, Ears & Distinct Procedural 3D Hairstyles
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.148, 22, 20), headMat);
  head.scale.set(0.95, 1.08, 1.02);
  head.position.y = 1.64;
  head.rotation.y = -Math.PI / 2;
  head.castShadow = true;
  bodyRoot.add(head);

  const earGeo = new THREE.SphereGeometry(0.028, 8, 8);
  const leftEar = new THREE.Mesh(earGeo, skinMat);
  leftEar.scale.set(0.45, 0.9, 0.7);
  leftEar.position.set(-0.14, 1.63, 0);
  const rightEar = new THREE.Mesh(earGeo, skinMat);
  rightEar.scale.set(0.45, 0.9, 0.7);
  rightEar.position.set(0.14, 1.63, 0);
  bodyRoot.add(leftEar, rightEar);

  const hairGroup = new THREE.Group();
  hairGroup.position.y = 1.65;
  if (hairStyle === 'buzz') {
    const cap = new THREE.Mesh(
      new THREE.SphereGeometry(0.151, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.52),
      hairMat
    );
    hairGroup.add(cap);
  } else if (hairStyle === 'fade') {
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.15, 0.1, 14), hairMat);
    crown.position.y = 0.1;
    const topCap = new THREE.Mesh(
      new THREE.SphereGeometry(0.144, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.5),
      hairMat
    );
    topCap.position.y = 0.06;
    hairGroup.add(crown, topCap);
  } else if (hairStyle === 'afro') {
    const crown = new THREE.Mesh(new THREE.SphereGeometry(0.195, 16, 14), hairMat);
    crown.position.set(0, 0.06, -0.02);
    crown.castShadow = true;
    hairGroup.add(crown);
  } else if (hairStyle === 'mohawk') {
    const sideBand = new THREE.Mesh(
      new THREE.SphereGeometry(0.15, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.35),
      hairMat
    );
    const crest = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.11, 0.28), hairMat);
    crest.position.set(0, 0.15, -0.01);
    crest.castShadow = true;
    hairGroup.add(sideBand, crest);
  } else if (hairStyle === 'swept') {
    const cap = new THREE.Mesh(
      new THREE.SphereGeometry(0.156, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.58),
      hairMat
    );
    const sweepBack = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.1, 0.22), hairMat);
    sweepBack.position.set(0, 0.1, -0.06);
    sweepBack.rotation.x = -0.25;
    hairGroup.add(cap, sweepBack);
  } else {
    const cap = new THREE.Mesh(
      new THREE.SphereGeometry(0.155, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.58),
      hairMat
    );
    const fringe = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.045, 0.1), hairMat);
    fringe.position.set(0, 0.09, 0.09);
    hairGroup.add(cap, fringe);
  }
  bodyRoot.add(hairGroup);

  // 6 & 7. Sculpted Articulated Legs + Knee + Socks + Football Boots
  const buildLeg = (xOffset: number) => {
    const legPivot = new THREE.Group();
    legPivot.position.set(xOffset * wScale, 0.72, 0);

    // Shorts leg cuff
    const shortsLeg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.098 * lScale, 0.088 * lScale, 0.22, 12),
      shortsMat
    );
    shortsLeg.position.y = -0.08;
    shortsLeg.castShadow = true;
    legPivot.add(shortsLeg);

    // Bare thigh / knee skin
    const thigh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.076 * lScale, 0.064 * lScale, 0.2, 12),
      skinMat
    );
    thigh.position.y = -0.24;
    thigh.castShadow = true;
    legPivot.add(thigh);

    // Sculpted calf sock + fold band
    const sockTop = new THREE.Mesh(
      new THREE.CylinderGeometry(0.068 * lScale, 0.068 * lScale, 0.045, 12),
      sockBandMat
    );
    sockTop.position.y = -0.35;
    legPivot.add(sockTop);

    const shin = new THREE.Mesh(
      new THREE.CylinderGeometry(0.068 * lScale, 0.048 * lScale, 0.3, 12),
      socksMat
    );
    shin.position.y = -0.5;
    shin.castShadow = true;
    legPivot.add(shin);

    // Multi-part football cleat (upper + rounded toe + stud soleplate)
    const cleat = new THREE.Mesh(new THREE.BoxGeometry(0.108 * lScale, 0.07, 0.18), cleatMat);
    cleat.position.set(0, -0.675, 0.025);
    cleat.castShadow = true;
    legPivot.add(cleat);

    const toeCap = new THREE.Mesh(
      new THREE.SphereGeometry(0.054 * lScale, 10, 8),
      cleatMat
    );
    toeCap.scale.set(1.0, 0.68, 1.35);
    toeCap.position.set(0, -0.68, 0.11);
    legPivot.add(toeCap);

    const sole = new THREE.Mesh(new THREE.BoxGeometry(0.11 * lScale, 0.016, 0.23), soleMat);
    sole.position.set(0, -0.715, 0.04);
    legPivot.add(sole);

    bodyRoot.add(legPivot);
    return legPivot;
  };

  const leftLeg = buildLeg(-0.115);
  const rightLeg = buildLeg(0.115);

  // 8 & 9. Sculpted Articulated Arms + Hands
  const buildArm = (xOffset: number) => {
    const armPivot = new THREE.Group();
    armPivot.position.set(xOffset * wScale, 1.38, 0);

    const sleeve = new THREE.Mesh(
      new THREE.CylinderGeometry(0.066 * lScale, 0.062 * lScale, 0.2, 12),
      sleeveMat
    );
    sleeve.position.y = -0.1;
    sleeve.castShadow = true;
    armPivot.add(sleeve);

    const forearm = new THREE.Mesh(
      new THREE.CylinderGeometry(0.052 * lScale, 0.04 * lScale, 0.27, 10),
      skinMat
    );
    forearm.position.y = -0.31;
    forearm.castShadow = true;
    armPivot.add(forearm);

    const hand = new THREE.Mesh(
      new THREE.SphereGeometry(0.042 * lScale, 8, 8),
      skinMat
    );
    hand.scale.set(0.85, 1.25, 0.65);
    hand.position.y = -0.46;
    armPivot.add(hand);

    bodyRoot.add(armPivot);
    return armPivot;
  };

  const leftArm = buildArm(-0.285);
  const rightArm = buildArm(0.285);

  const updateKit = (nextKit: KitColors, nextNum: number) => {
    kitTex.dispose();
    kitTex = createKitTexture(nextKit, nextNum);
    jerseyMat.map = kitTex;
    jerseyMat.needsUpdate = true;
    sleeveMat.color.set(nextKit.primary);
    collarMat.color.set(nextKit.secondary);
    shortsMat.color.set(nextKit.shorts);
    socksMat.color.set(nextKit.socks);
    sockBandMat.color.set(nextKit.secondary);
  };

  return {
    group,
    torso,
    leftLeg,
    rightLeg,
    leftArm,
    rightArm,
    ring,
    updateKit,
  };
}

export function createAdBoardTexture(club: Club): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#070B12';
  ctx.fillRect(0, 0, 1024, 128);

  ctx.fillStyle = club.homeKit.primary;
  ctx.fillRect(0, 0, 1024, 12);
  ctx.fillRect(0, 116, 1024, 12);

  ctx.fillStyle = '#10B981';
  ctx.font = 'bold 50px Barlow Condensed, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(
    `ATADWE MOBILE  ·  ${club.stadiumName.toUpperCase()}  ·  ${club.name.toUpperCase()}`,
    512,
    64
  );

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.needsUpdate = true;
  return tex;
}

export function buildTwilightSkyDome(theme: StadiumTheme): THREE.Mesh {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, 0, 256);
  if (theme === 'golden_hour') {
    grad.addColorStop(0, '#0F172A');
    grad.addColorStop(0.45, '#334155');
    grad.addColorStop(0.76, '#EA580C');
    grad.addColorStop(1, '#FDBA74');
  } else if (theme === 'rainy_derby') {
    grad.addColorStop(0, '#040812');
    grad.addColorStop(0.6, '#0F172A');
    grad.addColorStop(1, '#1E293B');
  } else if (theme === 'training_gym') {
    grad.addColorStop(0, '#0B1325');
    grad.addColorStop(0.55, '#1E3A5F');
    grad.addColorStop(1, '#334155');
  } else {
    grad.addColorStop(0, '#03060E');
    grad.addColorStop(0.5, '#0B162C');
    grad.addColorStop(0.85, '#172554');
    grad.addColorStop(1, '#1E293B');
  }

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 256);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;

  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(210, 24, 16),
    new THREE.MeshBasicMaterial({
      map: tex,
      side: THREE.BackSide,
      fog: false,
      depthWrite: false,
    })
  );
  return sky;
}

export function buildTechnicalDugouts(homeClub: Club, awayClub: Club): THREE.Group {
  const group = new THREE.Group();
  const frameMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.35, metalness: 0.78 });
  const glassMat = new THREE.MeshStandardMaterial({
    color: '#BAE6FD',
    roughness: 0.15,
    metalness: 0.2,
    transparent: true,
    opacity: 0.36,
  });

  const makeBench = (zPos: number, seatColor: string) => {
    const bench = new THREE.Group();
    bench.position.set(-PITCH_WIDTH / 2 - 6.8, 0, zPos);

    const base = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.14, 10.5), frameMat);
    base.position.y = 0.07;
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.12, 10.6), glassMat);
    canopy.position.set(0.1, 2.35, 0);
    const backGlass = new THREE.Mesh(new THREE.BoxGeometry(0.08, 2.25, 10.4), glassMat);
    backGlass.position.set(-1.2, 1.2, 0);

    bench.add(base, canopy, backGlass);

    const seatMat = new THREE.MeshStandardMaterial({ color: seatColor, roughness: 0.55, metalness: 0.1 });
    for (let i = 0; i < 6; i++) {
      const seat = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.85, 0.7), seatMat);
      seat.position.set(-0.35, 0.65, -3.8 + i * 1.52);
      bench.add(seat);
    }
    return bench;
  };

  group.add(makeBench(14, homeClub.homeKit.primary));
  group.add(makeBench(-14, awayClub.awayKit.primary));
  return group;
}

export function buildGoalStructure(zPos: number, facingSign: number): {
  group: THREE.Group;
  netMesh: THREE.Mesh;
} {
  const group = new THREE.Group();
  const postMat = new THREE.MeshStandardMaterial({
    color: 0xf8fafc,
    roughness: 0.2,
    metalness: 0.85,
  });

  const halfW = GOAL_WIDTH / 2;
  const h = GOAL_HEIGHT;
  const d = GOAL_DEPTH * facingSign;

  // Left & Right Posts
  const postGeo = new THREE.CylinderGeometry(0.075, 0.075, h, 16);
  const leftPost = new THREE.Mesh(postGeo, postMat);
  leftPost.position.set(-halfW, h / 2, zPos);
  leftPost.castShadow = true;
  group.add(leftPost);

  const rightPost = new THREE.Mesh(postGeo, postMat);
  rightPost.position.set(halfW, h / 2, zPos);
  rightPost.castShadow = true;
  group.add(rightPost);

  // Crossbar
  const barGeo = new THREE.CylinderGeometry(0.075, 0.075, GOAL_WIDTH + 0.15, 16);
  const crossbar = new THREE.Mesh(barGeo, postMat);
  crossbar.rotation.z = Math.PI / 2;
  crossbar.position.set(0, h, zPos);
  crossbar.castShadow = true;
  group.add(crossbar);

  // Back support stanchions & ground frame
  const backBarGeo = new THREE.CylinderGeometry(0.045, 0.045, Math.abs(d), 10);
  const topLeftSupport = new THREE.Mesh(backBarGeo, postMat);
  topLeftSupport.rotation.x = Math.PI / 2;
  topLeftSupport.position.set(-halfW, h, zPos + d / 2);
  group.add(topLeftSupport);

  const topRightSupport = new THREE.Mesh(backBarGeo, postMat);
  topRightSupport.rotation.x = Math.PI / 2;
  topRightSupport.position.set(halfW, h, zPos + d / 2);
  group.add(topRightSupport);

  const baseBar = new THREE.Mesh(
    new THREE.CylinderGeometry(0.04, 0.04, GOAL_WIDTH + 0.1, 10),
    postMat
  );
  baseBar.rotation.z = Math.PI / 2;
  baseBar.position.set(0, 0.04, zPos + d);
  group.add(baseBar);

  // Net Box
  const netGeo = new THREE.BoxGeometry(GOAL_WIDTH, h, Math.abs(d), 10, 5, 5);
  const netMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    wireframe: true,
    transparent: true,
    opacity: 0.44,
  });
  const netMesh = new THREE.Mesh(netGeo, netMat);
  netMesh.position.set(0, h / 2, zPos + d / 2);
  group.add(netMesh);

  return { group, netMesh };
}

export function buildClubGymPavilion(club: Club): THREE.Group {
  const gymGroup = new THREE.Group();
  gymGroup.position.set(-46, 0, -6);

  const floorMat = new THREE.MeshStandardMaterial({ color: '#1E293B', roughness: 0.85, metalness: 0.1 });
  const floor = new THREE.Mesh(new THREE.BoxGeometry(16, 0.14, 24), floorMat);
  floor.position.y = 0.07;
  floor.receiveShadow = true;
  gymGroup.add(floor);

  const trackMat = new THREE.MeshStandardMaterial({
    color: club.trainingKit.secondary,
    roughness: 0.78,
    metalness: 0.08,
  });
  const track = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.16, 21), trackMat);
  track.position.set(4.5, 0.08, 0);
  track.receiveShadow = true;
  gymGroup.add(track);

  const steelMat = new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.3, metalness: 0.82 });
  const pillarGeo = new THREE.BoxGeometry(0.45, 5.5, 0.45);
  for (const x of [-7.5, 7.5]) {
    for (const z of [-11.5, 0, 11.5]) {
      const pillar = new THREE.Mesh(pillarGeo, steelMat);
      pillar.position.set(x, 2.75, z);
      pillar.castShadow = true;
      gymGroup.add(pillar);
    }
  }

  const roofMat = new THREE.MeshStandardMaterial({
    color: club.homeKit.primary,
    roughness: 0.45,
    metalness: 0.35,
  });
  const roof = new THREE.Mesh(new THREE.BoxGeometry(16.4, 0.35, 24.6), roofMat);
  roof.position.y = 5.65;
  roof.castShadow = true;
  gymGroup.add(roof);

  const glassMat = new THREE.MeshStandardMaterial({
    color: '#93C5FD',
    roughness: 0.15,
    metalness: 0.25,
    transparent: true,
    opacity: 0.35,
  });
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(0.15, 5.3, 23.6), glassMat);
  backWall.position.set(-7.6, 2.65, 0);
  gymGroup.add(backWall);

  const chromeMat = new THREE.MeshStandardMaterial({ color: '#E2E8F0', roughness: 0.2, metalness: 0.92 });
  const plateMat = new THREE.MeshStandardMaterial({ color: club.trainingKit.secondary, roughness: 0.5, metalness: 0.3 });

  for (let i = 0; i < 3; i++) {
    const rz = -7 + i * 7;
    const rack = new THREE.Group();
    rack.position.set(-4.2, 0.14, rz);

    const uprightGeo = new THREE.BoxGeometry(0.12, 2.4, 0.12);
    const u1 = new THREE.Mesh(uprightGeo, steelMat);
    u1.position.set(0, 1.2, -0.75);
    const u2 = new THREE.Mesh(uprightGeo, steelMat);
    u2.position.set(0, 1.2, 0.75);
    rack.add(u1, u2);

    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.2, 10), chromeMat);
    bar.rotation.x = Math.PI / 2;
    bar.position.set(0.1, 1.45, 0);
    rack.add(bar);

    for (const pz of [-0.95, 0.95]) {
      const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.08, 16), plateMat);
      plate.rotation.x = Math.PI / 2;
      plate.position.set(0.1, 1.45, pz);
      rack.add(plate);
    }

    gymGroup.add(rack);
  }

  for (let i = 0; i < 3; i++) {
    const tm = new THREE.Group();
    tm.position.set(-0.5, 0.14, -7 + i * 3.5);
    const belt = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.18, 0.9), steelMat);
    belt.position.y = 0.09;
    const consolePost = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.15, 0.78), steelMat);
    consolePost.position.set(-0.8, 0.65, 0);
    tm.add(belt, consolePost);
    gymGroup.add(tm);
  }

  return gymGroup;
}
