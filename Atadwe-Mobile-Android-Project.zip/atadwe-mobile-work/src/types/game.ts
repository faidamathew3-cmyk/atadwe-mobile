export type Platform = 'PC' | 'Console' | 'Mobile';

export type StadiumTheme =
  | 'night_floodlights'
  | 'golden_hour'
  | 'training_gym'
  | 'rainy_derby';

export type CameraMode = 'broadcast' | 'follow' | 'pro_player' | 'tactical';

export type Position = 'GK' | 'DEF' | 'MID' | 'FWD';

export type KitPattern = 'solid' | 'stripes' | 'hoops' | 'sash' | 'halved';

export type FormationId = '4-3-3' | '4-4-2' | '4-2-3-1' | '3-5-2' | '5-3-2';

export type Mentality =
  | 'Ultra Defensive'
  | 'Defensive'
  | 'Balanced'
  | 'Attacking'
  | 'All-Out Attack';

export type PressingIntensity = 'Low Block' | 'Mid Press' | 'Gegenpress';

export type PassingStyle = 'Direct' | 'Balanced' | 'Tiki-Taka';

export type DefensiveLine = 'Deep' | 'Normal' | 'High';

export type TrainingFocus =
  | 'Finishing Drills'
  | 'Tactical Rondo'
  | 'Gym Conditioning'
  | 'Sprint & Agility'
  | 'Defensive Shape'
  | 'Recovery Session';

export type FaceStyle = 'athletic' | 'sharp' | 'sculpted' | 'veteran' | 'youthful';

export type HairStyle = 'short_crop' | 'fade' | 'afro' | 'mohawk' | 'buzz' | 'swept';

export type BodyType = 'lean' | 'athletic' | 'stocky' | 'towering';

export type PreferredFoot = 'Right' | 'Left' | 'Both';

export type PlayerTraitId =
  | 'speedster'
  | 'finesse_shot'
  | 'playmaker'
  | 'box_to_box'
  | 'aerial_threat'
  | 'brick_wall'
  | 'set_piece_specialist'
  | 'clinical_finisher';

export type PlaystyleId =
  | 'Target Striker'
  | 'Inside Forward'
  | 'Deep-Lying Playmaker'
  | 'Box-to-Box Engine'
  | 'Ball-Playing Defender'
  | 'Sweeper Keeper';

export type InjurySeverity = 'Minor' | 'Moderate' | 'Severe';

export type InjuryType =
  | 'Hamstring Strain'
  | 'Ankle Sprain'
  | 'Groin Tightness'
  | 'Knee Ligament'
  | 'Calf Tear'
  | 'Shoulder Contusion';

export type TreatmentProtocol =
  | 'Standard Care'
  | 'Cryo & Hydrotherapy'
  | 'Intensive Rehab';

export type MedicalStaffRole =
  | 'Head Team Doctor'
  | 'Sports Physiotherapist'
  | 'Rehab Specialist'
  | 'Cryo & Nutrition Lead';

export interface MedicalStaffMember {
  id: string;
  name: string;
  role: MedicalStaffRole;
  specialty: string;
  starRating: number;
  recoveryBoostPct: number;
  preventionPct: number;
  weeklySalary: number;
  hireCost: number;
  hired: boolean;
}

export interface PlayerInjury {
  type: InjuryType;
  severity: InjurySeverity;
  weeksRemaining: number;
  initialWeeks: number;
  recoveryProgress: number;
  source: 'Match' | 'Training';
  occurredWeek: number;
}

export interface InjuryEventEntry {
  id: string;
  week: number;
  playerId: string;
  playerName: string;
  injuryType: InjuryType;
  severity: InjurySeverity;
  source: 'Match' | 'Training';
  event: 'Injured' | 'Recovered';
  weeksOut?: number;
}

export interface Player {
  id: string;
  name: string;
  nationality: string;
  position: Position;
  secondaryPosition?: Position | null;
  number: number;
  age: number;
  ovr: number;
  pace: number;
  shooting: number;
  passing: number;
  dribbling: number;
  defending: number;
  physical: number;
  stamina: number;
  morale: number;
  form: number;
  marketValue: number;
  weeklyWage: number;
  goals: number;
  assists: number;
  skinTone: string;
  hairColor: string;
  faceStyle?: FaceStyle;
  hairStyle?: HairStyle;
  bodyType?: BodyType;
  bootColor?: string;
  preferredFoot?: PreferredFoot;
  playstyle?: PlaystyleId;
  traits?: PlayerTraitId[];
  isCreatedStar?: boolean;
  trainingFocus?: TrainingFocus;
  injury?: PlayerInjury | null;
}

export interface CreatedPlayerProfile {
  name: string;
  nationality: string;
  position: Position;
  secondaryPosition: Position | null;
  number: number;
  age: number;
  preferredFoot: PreferredFoot;
  ovr: number;
  pace: number;
  shooting: number;
  passing: number;
  dribbling: number;
  defending: number;
  physical: number;
  skinTone: string;
  hairColor: string;
  faceStyle: FaceStyle;
  hairStyle: HairStyle;
  bodyType: BodyType;
  bootColor: string;
  heightScale: number;
  playstyle: PlaystyleId;
  traits: PlayerTraitId[];
}

export interface KitColors {
  primary: string;
  secondary: string;
  shorts: string;
  socks: string;
  pattern: KitPattern;
}

export interface Club {
  id: string;
  name: string;
  shortName: string;
  leagueId: string;
  country: string;
  city: string;
  mapX: number;
  mapY: number;
  stadiumName: string;
  stadiumCapacity: number;
  gymName: string;
  gymTier: number;
  stadiumTier: number;
  medicalTier: number;
  transferBudget: number;
  wageBudget: number;
  homeKit: KitColors;
  awayKit: KitColors;
  trainingKit: KitColors;
  roster: Player[];
}

export interface League {
  id: string;
  name: string;
  country: string;
  licenseCode: string;
  accentColor: string;
  clubIds: string[];
}

export interface TacticalSetup {
  formation: FormationId;
  mentality: Mentality;
  pressing: PressingIntensity;
  passingStyle: PassingStyle;
  defensiveLine: DefensiveLine;
}

export interface StandingRow {
  clubId: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gf: number;
  ga: number;
  points: number;
  form: ('W' | 'D' | 'L')[];
}

export interface Fixture {
  id: string;
  week: number;
  leagueId: string;
  homeClubId: string;
  awayClubId: string;
  played: boolean;
  homeGoals?: number;
  awayGoals?: number;
  scorers?: { playerName: string; minute: number; clubId: string }[];
  attendance?: number;
  gateRevenue?: number;
}

export interface CupTie {
  id: string;
  round: 'Quarter-Final' | 'Semi-Final' | 'Final';
  week: number;
  homeClubId: string;
  awayClubId: string;
  played: boolean;
  homeGoals?: number;
  awayGoals?: number;
  winnerId?: string;
}

export interface FinanceLedgerEntry {
  id: string;
  week: number;
  category: 'Matchday' | 'Wages' | 'Transfer' | 'Sponsor' | 'Facility' | 'Medical';
  description: string;
  amount: number;
}

export interface CareerStats {
  matchesPlayed: number;
  wins: number;
  draws: number;
  losses: number;
  goalsFor: number;
  goalsAgainst: number;
}

export interface ManagerState {
  clubId: string;
  managerName: string;
  seasonNumber: number;
  currentWeek: number;
  tactics: TacticalSetup;
  teamTrainingFocus: TrainingFocus;
  startingXIIds: string[];
  benchIds: string[];
  standingsByLeague: Record<string, StandingRow[]>;
  fixtures: Fixture[];
  cupTies: CupTie[];
  trophies: string[];
  ledger: FinanceLedgerEntry[];
  careerStats: CareerStats;
  medicalStaff: MedicalStaffMember[];
  medicalProtocol: TreatmentProtocol;
  injuryReportLog: InjuryEventEntry[];
  lastMatchSummary?: string;
}

export interface MultiplayerPeer {
  id: string;
  name: string;
  clubId: string;
  clubName: string;
  platform: Platform;
  role: 'home' | 'away' | 'spectator';
  voiceEnabled: boolean;
}

export interface MultiplayerRoom {
  id: string;
  name: string;
  stadiumTheme: string;
  hostId: string;
  status: 'waiting' | 'playing';
  scoreHome: number;
  scoreAway: number;
  peers: MultiplayerPeer[];
}

export interface ChatMessage {
  id: string;
  channel: string;
  senderId: string;
  senderName: string;
  clubName: string;
  platform: Platform;
  text: string;
  timestamp: number;
}

export interface LeaderboardEntry {
  id: string;
  managerName: string;
  clubName: string;
  clubColor: string;
  platform: Platform;
  eloRating: number;
  wins: number;
  draws: number;
  losses: number;
  goalsScored: number;
  trophiesWon: number;
}

export interface AICoachAnalysis {
  headline: string;
  tacticalSummary: string;
  recommendedFormation: FormationId;
  recommendedMentality: Mentality;
  recommendedPressing: PressingIntensity;
  recommendedPassing: PassingStyle;
  recommendedTrainingFocus: TrainingFocus;
  keyInstructions: string[];
  scoutingNote: string;
}

export type ControllerMode = 'efootball_touch' | 'classic_pc';

export interface MatchHUDState {
  homeName: string;
  awayName: string;
  homeColor: string;
  awayColor: string;
  homeScore: number;
  awayScore: number;
  matchMinute: number;
  half: 1 | 2;
  shotPower: number;
  activePlayerName: string;
  activePlayerNumber: number;
  activePlayerStamina: number;
  possessionHome: number;
  teamHasPossession: 'home' | 'away' | 'loose';
  goalBanner: string | null;
  injuryBanner: string | null;
  injuredPlayerCount: number;
  mode: 'match' | 'training_roam';
  radarDots: {
    x: number;
    z: number;
    team: 'home' | 'away' | 'ball' | 'controlled';
  }[];
}

export type HighlightType = 'goal' | 'save' | 'woodwork' | 'chance';

export type ReplayCameraAngle = 'tv_broadcast' | 'goal_cam' | 'action_follow';

export type ReplaySpeed = 0.5 | 1 | 1.5;

export interface MatchHighlightSummary {
  id: string;
  type: HighlightType;
  title: string;
  subtitle: string;
  minute: number;
  team: 'home' | 'away';
  playerName: string;
  playerNumber: number;
  scoreText: string;
  durationSec: number;
  peakSec: number;
  shotSpeedKmh: number;
}

export interface ReplayHUDState {
  active: boolean;
  highlightId: string | null;
  paused: boolean;
  speed: ReplaySpeed;
  camera: ReplayCameraAngle;
  currentTime: number;
  duration: number;
  autoPlay: boolean;
}

