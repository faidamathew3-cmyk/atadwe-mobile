import {
  Club,
  CreatedPlayerProfile,
  CupTie,
  Fixture,
  FormationId,
  InjuryEventEntry,
  InjurySeverity,
  InjuryType,
  League,
  ManagerState,
  MedicalStaffMember,
  Player,
  PlayerInjury,
  Position,
  StandingRow,
  TacticalSetup,
  TrainingFocus,
  TreatmentProtocol,
} from '../types/game';
import { LEAGUES, getClubAvgOvr } from '../data/leagues';

export const TREATMENT_PROTOCOLS: Record<
  TreatmentProtocol,
  { speedBonus: number; preventionBonus: number; weeklyCost: number; summary: string }
> = {
  'Standard Care': {
    speedBonus: 0,
    preventionBonus: 0,
    weeklyCost: 0,
    summary: 'Baseline club physiotherapy and rest schedule.',
  },
  'Cryo & Hydrotherapy': {
    speedBonus: 0.35,
    preventionBonus: 8,
    weeklyCost: 120_000,
    summary: '+35% recovery speed and -8% muscle strain risk.',
  },
  'Intensive Rehab': {
    speedBonus: 0.75,
    preventionBonus: 14,
    weeklyCost: 260_000,
    summary: '+75% accelerated healing with daily biomechanics monitoring.',
  },
};

export function createDefaultMedicalStaff(): MedicalStaffMember[] {
  return [
    {
      id: 'med_mensah',
      name: 'Dr. Samuel Mensah',
      role: 'Head Team Doctor',
      specialty: 'Acute Trauma & Matchday Triage',
      starRating: 3,
      recoveryBoostPct: 15,
      preventionPct: 8,
      weeklySalary: 45_000,
      hireCost: 900_000,
      hired: true,
    },
    {
      id: 'med_keller',
      name: 'Dr. Elena Rostova',
      role: 'Sports Physiotherapist',
      specialty: 'Hamstring & Calf Muscle Repair',
      starRating: 4,
      recoveryBoostPct: 24,
      preventionPct: 12,
      weeklySalary: 78_000,
      hireCost: 2_200_000,
      hired: false,
    },
    {
      id: 'med_tanaka',
      name: 'Kenji Takahashi',
      role: 'Rehab Specialist',
      specialty: 'Ligament Stability & Tendon Reloading',
      starRating: 5,
      recoveryBoostPct: 36,
      preventionPct: 15,
      weeklySalary: 115_000,
      hireCost: 4_100_000,
      hired: false,
    },
    {
      id: 'med_okonkwo',
      name: 'Amara Okonkwo',
      role: 'Cryo & Nutrition Lead',
      specialty: 'Metabolic Recovery & Fatigue Shielding',
      starRating: 4,
      recoveryBoostPct: 22,
      preventionPct: 16,
      weeklySalary: 68_000,
      hireCost: 1_850_000,
      hired: false,
    },
    {
      id: 'med_moretti',
      name: 'Prof. Luca Moretti',
      role: 'Head Team Doctor',
      specialty: 'Regenerative PRP & Fast-Track Return',
      starRating: 5,
      recoveryBoostPct: 42,
      preventionPct: 18,
      weeklySalary: 145_000,
      hireCost: 5_400_000,
      hired: false,
    },
  ];
}

export function getMedicalMetrics(
  club: Club,
  manager: Pick<ManagerState, 'medicalStaff' | 'medicalProtocol'>
): {
  hiredStaff: MedicalStaffMember[];
  recoverySpeedMultiplier: number;
  injuryPreventionPct: number;
  weeklyMedicalCost: number;
} {
  const staff = manager.medicalStaff || [];
  const hiredStaff = staff.filter((s) => s.hired);
  const protocol = TREATMENT_PROTOCOLS[manager.medicalProtocol || 'Standard Care'];
  const medicalTier = club.medicalTier || 1;

  const staffRecoveryBoost = hiredStaff.reduce((sum, s) => sum + s.recoveryBoostPct, 0) / 100;
  const staffPrevention = hiredStaff.reduce((sum, s) => sum + s.preventionPct, 0);
  const staffWages = hiredStaff.reduce((sum, s) => sum + s.weeklySalary, 0);

  const recoverySpeedMultiplier = Number(
    (1.0 + (medicalTier - 1) * 0.25 + staffRecoveryBoost + protocol.speedBonus).toFixed(2)
  );
  const injuryPreventionPct = Math.min(
    72,
    (medicalTier - 1) * 6 + staffPrevention + protocol.preventionBonus
  );
  const weeklyMedicalCost = staffWages + protocol.weeklyCost;

  return {
    hiredStaff,
    recoverySpeedMultiplier,
    injuryPreventionPct,
    weeklyMedicalCost,
  };
}

const INJURY_CATALOG: { type: InjuryType; severity: InjurySeverity; weeks: [number, number] }[] = [
  { type: 'Groin Tightness', severity: 'Minor', weeks: [1, 1] },
  { type: 'Shoulder Contusion', severity: 'Minor', weeks: [1, 2] },
  { type: 'Ankle Sprain', severity: 'Moderate', weeks: [2, 3] },
  { type: 'Hamstring Strain', severity: 'Moderate', weeks: [2, 4] },
  { type: 'Calf Tear', severity: 'Moderate', weeks: [3, 4] },
  { type: 'Knee Ligament', severity: 'Severe', weeks: [4, 6] },
];

export function createPlayerInjury(
  source: 'Match' | 'Training',
  week: number,
  severityFilter?: InjurySeverity
): PlayerInjury {
  const pool = severityFilter
    ? INJURY_CATALOG.filter((i) => i.severity === severityFilter)
    : INJURY_CATALOG;
  const roll = Math.random();
  const pick = severityFilter
    ? pool[Math.floor(Math.random() * pool.length)]
    : roll < 0.45
      ? INJURY_CATALOG[Math.floor(Math.random() * 2)]
      : roll < 0.86
        ? INJURY_CATALOG[2 + Math.floor(Math.random() * 3)]
        : INJURY_CATALOG[5];

  const weeks =
    pick.weeks[0] + Math.floor(Math.random() * (pick.weeks[1] - pick.weeks[0] + 1));

  return {
    type: pick.type,
    severity: pick.severity,
    weeksRemaining: weeks,
    initialWeeks: weeks,
    recoveryProgress: 0,
    source,
    occurredWeek: week,
  };
}

export function reconcileFitLineup(
  roster: Player[],
  startingXIIds: string[],
  benchIds: string[]
): { startingXIIds: string[]; benchIds: string[] } {
  const byId = new Map(roster.map((p) => [p.id, p]));
  const healthyBench = benchIds
    .map((id) => byId.get(id))
    .filter((p): p is Player => Boolean(p && !p.injury))
    .sort((a, b) => b.ovr - a.ovr);

  const nextXI: string[] = [];
  const usedSubs = new Set<string>();

  for (const id of startingXIIds) {
    const p = byId.get(id);
    if (p && !p.injury) {
      nextXI.push(id);
    } else {
      const replacement = healthyBench.find((sub) => !usedSubs.has(sub.id));
      if (replacement) {
        nextXI.push(replacement.id);
        usedSubs.add(replacement.id);
      } else if (p) {
        nextXI.push(p.id);
      }
    }
  }

  const nextBench = roster.filter((p) => !nextXI.includes(p.id)).map((p) => p.id);
  return { startingXIIds: nextXI, benchIds: nextBench };
}

export interface FormationSlot {
  role: Position;
  label: string;
  // Normalized pitch coords: x in [-1, 1] (left to right), z in [-1, 1] (own goal to opp goal)
  nx: number;
  nz: number;
}

export const FORMATIONS: Record<FormationId, FormationSlot[]> = {
  '4-3-3': [
    { role: 'GK', label: 'GK', nx: 0, nz: -0.9 },
    { role: 'DEF', label: 'LB', nx: -0.68, nz: -0.58 },
    { role: 'DEF', label: 'LCB', nx: -0.24, nz: -0.64 },
    { role: 'DEF', label: 'RCB', nx: 0.24, nz: -0.64 },
    { role: 'DEF', label: 'RB', nx: 0.68, nz: -0.58 },
    { role: 'MID', label: 'LCM', nx: -0.4, nz: -0.2 },
    { role: 'MID', label: 'CDM', nx: 0, nz: -0.32 },
    { role: 'MID', label: 'RCM', nx: 0.4, nz: -0.2 },
    { role: 'FWD', label: 'LW', nx: -0.6, nz: 0.35 },
    { role: 'FWD', label: 'ST', nx: 0, nz: 0.52 },
    { role: 'FWD', label: 'RW', nx: 0.6, nz: 0.35 },
  ],
  '4-4-2': [
    { role: 'GK', label: 'GK', nx: 0, nz: -0.9 },
    { role: 'DEF', label: 'LB', nx: -0.68, nz: -0.58 },
    { role: 'DEF', label: 'LCB', nx: -0.24, nz: -0.64 },
    { role: 'DEF', label: 'RCB', nx: 0.24, nz: -0.64 },
    { role: 'DEF', label: 'RB', nx: 0.68, nz: -0.58 },
    { role: 'MID', label: 'LM', nx: -0.66, nz: -0.1 },
    { role: 'MID', label: 'LCM', nx: -0.22, nz: -0.2 },
    { role: 'MID', label: 'RCM', nx: 0.22, nz: -0.2 },
    { role: 'MID', label: 'RM', nx: 0.66, nz: -0.1 },
    { role: 'FWD', label: 'LST', nx: -0.25, nz: 0.48 },
    { role: 'FWD', label: 'RST', nx: 0.25, nz: 0.48 },
  ],
  '4-2-3-1': [
    { role: 'GK', label: 'GK', nx: 0, nz: -0.9 },
    { role: 'DEF', label: 'LB', nx: -0.68, nz: -0.58 },
    { role: 'DEF', label: 'LCB', nx: -0.24, nz: -0.64 },
    { role: 'DEF', label: 'RCB', nx: 0.24, nz: -0.64 },
    { role: 'DEF', label: 'RB', nx: 0.68, nz: -0.58 },
    { role: 'MID', label: 'LDM', nx: -0.26, nz: -0.34 },
    { role: 'MID', label: 'RDM', nx: 0.26, nz: -0.34 },
    { role: 'MID', label: 'LAM', nx: -0.56, nz: 0.14 },
    { role: 'MID', label: 'CAM', nx: 0, nz: 0.12 },
    { role: 'MID', label: 'RAM', nx: 0.56, nz: 0.14 },
    { role: 'FWD', label: 'ST', nx: 0, nz: 0.54 },
  ],
  '3-5-2': [
    { role: 'GK', label: 'GK', nx: 0, nz: -0.9 },
    { role: 'DEF', label: 'LCB', nx: -0.45, nz: -0.62 },
    { role: 'DEF', label: 'CCB', nx: 0, nz: -0.66 },
    { role: 'DEF', label: 'RCB', nx: 0.45, nz: -0.62 },
    { role: 'MID', label: 'LWB', nx: -0.74, nz: -0.12 },
    { role: 'MID', label: 'LCM', nx: -0.3, nz: -0.24 },
    { role: 'MID', label: 'CAM', nx: 0, nz: 0.04 },
    { role: 'MID', label: 'RCM', nx: 0.3, nz: -0.24 },
    { role: 'MID', label: 'RWB', nx: 0.74, nz: -0.12 },
    { role: 'FWD', label: 'LST', nx: -0.24, nz: 0.5 },
    { role: 'FWD', label: 'RST', nx: 0.24, nz: 0.5 },
  ],
  '5-3-2': [
    { role: 'GK', label: 'GK', nx: 0, nz: -0.9 },
    { role: 'DEF', label: 'LWB', nx: -0.76, nz: -0.44 },
    { role: 'DEF', label: 'LCB', nx: -0.38, nz: -0.64 },
    { role: 'DEF', label: 'CCB', nx: 0, nz: -0.68 },
    { role: 'DEF', label: 'RCB', nx: 0.38, nz: -0.64 },
    { role: 'DEF', label: 'RWB', nx: 0.76, nz: -0.44 },
    { role: 'MID', label: 'LCM', nx: -0.36, nz: -0.16 },
    { role: 'MID', label: 'CDM', nx: 0, nz: -0.26 },
    { role: 'MID', label: 'RCM', nx: 0.36, nz: -0.16 },
    { role: 'FWD', label: 'LST', nx: -0.24, nz: 0.48 },
    { role: 'FWD', label: 'RST', nx: 0.24, nz: 0.48 },
  ],
};

export function pickBestLineup(
  roster: Player[],
  formation: FormationId
): { startingXIIds: string[]; benchIds: string[] } {
  const slots = FORMATIONS[formation];
  const healthy = roster.filter((p) => !p.injury).sort((a, b) => b.ovr - a.ovr);
  const injured = roster.filter((p) => Boolean(p.injury)).sort((a, b) => b.ovr - a.ovr);
  const remaining = [...healthy, ...injured];
  const xi: string[] = [];

  for (const slot of slots) {
    let idx = remaining.findIndex((p) => !p.injury && p.position === slot.role);
    if (idx === -1) {
      idx = remaining.findIndex((p) => !p.injury && p.secondaryPosition === slot.role);
    }
    if (idx === -1) {
      idx = remaining.findIndex((p) => !p.injury);
    }
    if (idx === -1) idx = 0;
    if (remaining[idx]) {
      xi.push(remaining[idx].id);
      remaining.splice(idx, 1);
    }
  }

  return {
    startingXIIds: xi,
    benchIds: remaining.map((p) => p.id),
  };
}

export function generateLeagueFixtures(league: League): Fixture[] {
  const ids = [...league.clubIds];
  const n = ids.length; // 6 clubs => 5 rounds * 2 legs = 10 weeks
  const fixtures: Fixture[] = [];
  const rotated = [...ids];

  // First half (Weeks 1..5)
  for (let round = 0; round < n - 1; round++) {
    const week = round + 1;
    for (let i = 0; i < n / 2; i++) {
      const home = rotated[i];
      const away = rotated[n - 1 - i];
      fixtures.push({
        id: `${league.id}_w${week}_${home}_${away}`,
        week,
        leagueId: league.id,
        homeClubId: round % 2 === 0 ? home : away,
        awayClubId: round % 2 === 0 ? away : home,
        played: false,
      });
    }
    const last = rotated.pop()!;
    rotated.splice(1, 0, last);
  }

  // Second half reverse fixtures (Weeks 6..10)
  const firstHalfCount = fixtures.length;
  for (let i = 0; i < firstHalfCount; i++) {
    const f = fixtures[i];
    const week = f.week + (n - 1);
    fixtures.push({
      id: `${league.id}_w${week}_${f.awayClubId}_${f.homeClubId}`,
      week,
      leagueId: league.id,
      homeClubId: f.awayClubId,
      awayClubId: f.homeClubId,
      played: false,
    });
  }

  return fixtures;
}

export function generateContinentalCup(clubs: Record<string, Club>, userClubId: string): CupTie[] {
  // Top 8 clubs across Europe + user's club guaranteed in Quarter-Finals
  const sorted = Object.values(clubs)
    .filter((c) => c.id !== userClubId)
    .sort((a, b) => getClubAvgOvr(b) - getClubAvgOvr(a))
    .slice(0, 7)
    .map((c) => c.id);

  const entrants = [userClubId, ...sorted];
  const ties: CupTie[] = [];
  for (let i = 0; i < 4; i++) {
    ties.push({
      id: `cup_qf_${i + 1}`,
      round: 'Quarter-Final',
      week: 4,
      homeClubId: entrants[i * 2],
      awayClubId: entrants[i * 2 + 1],
      played: false,
    });
  }
  return ties;
}

export function createInitialManagerState(
  clubId: string,
  clubs: Record<string, Club>,
  managerName = 'Alex Mercer'
): ManagerState {
  const club = clubs[clubId] ?? Object.values(clubs)[0];
  const tactics: TacticalSetup = {
    formation: '4-3-3',
    mentality: 'Balanced',
    pressing: 'Mid Press',
    passingStyle: 'Balanced',
    defensiveLine: 'Normal',
  };

  const { startingXIIds, benchIds } = pickBestLineup(club.roster, tactics.formation);

  const standingsByLeague: Record<string, StandingRow[]> = {};
  const allFixtures: Fixture[] = [];

  for (const league of LEAGUES) {
    standingsByLeague[league.id] = league.clubIds.map((id) => ({
      clubId: id,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      gf: 0,
      ga: 0,
      points: 0,
      form: [],
    }));
    allFixtures.push(...generateLeagueFixtures(league));
  }

  return {
    clubId: club.id,
    managerName,
    seasonNumber: 1,
    currentWeek: 1,
    tactics,
    teamTrainingFocus: 'Tactical Rondo',
    startingXIIds,
    benchIds,
    standingsByLeague,
    fixtures: allFixtures,
    cupTies: generateContinentalCup(clubs, club.id),
    trophies: [],
    ledger: [
      {
        id: 'init_sponsor',
        week: 1,
        category: 'Sponsor',
        description: 'Season Kit & Broadcast Rights Advance',
        amount: 18_500_000,
      },
    ],
    careerStats: {
      matchesPlayed: 0,
      wins: 0,
      draws: 0,
      losses: 0,
      goalsFor: 0,
      goalsAgainst: 0,
    },
    medicalStaff: createDefaultMedicalStaff(),
    medicalProtocol: 'Standard Care',
    injuryReportLog: [],
  };
}

export function insertCreatedPlayerIntoClub(
  club: Club,
  profile: CreatedPlayerProfile,
  manager: ManagerState
): { club: Club; manager: ManagerState } {
  const existingIdx = club.roster.findIndex((p) => p.isCreatedStar);
  const starId = existingIdx >= 0 ? club.roster[existingIdx].id : `created_star_${club.id}`;
  const starPlayer: Player = {
    id: starId,
    name: profile.name,
    nationality: profile.nationality,
    position: profile.position,
    secondaryPosition: profile.secondaryPosition,
    number: profile.number,
    age: profile.age,
    ovr: profile.ovr,
    pace: profile.pace,
    shooting: profile.shooting,
    passing: profile.passing,
    dribbling: profile.dribbling,
    defending: profile.defending,
    physical: profile.physical,
    stamina: 99,
    morale: 95,
    form: 90,
    marketValue: Math.round(Math.pow(Math.max(1, profile.ovr - 60), 2.15) * 200000),
    weeklyWage: 95000,
    goals: existingIdx >= 0 ? club.roster[existingIdx].goals : 0,
    assists: existingIdx >= 0 ? club.roster[existingIdx].assists : 0,
    skinTone: profile.skinTone,
    hairColor: profile.hairColor,
    faceStyle: profile.faceStyle,
    hairStyle: profile.hairStyle,
    bodyType: profile.bodyType,
    bootColor: profile.bootColor,
    preferredFoot: profile.preferredFoot,
    playstyle: profile.playstyle,
    traits: profile.traits,
    isCreatedStar: true,
  };

  const nextRoster =
    existingIdx >= 0
      ? club.roster.map((p, idx) => (idx === existingIdx ? starPlayer : p))
      : [starPlayer, ...club.roster];

  const nextStarting = manager.startingXIIds.includes(starId)
    ? manager.startingXIIds
    : [starId, ...manager.startingXIIds.slice(0, 10)];

  const nextBench = nextRoster
    .filter((p) => !nextStarting.includes(p.id))
    .map((p) => p.id);

  return {
    club: { ...club, roster: nextRoster },
    manager: { ...manager, startingXIIds: nextStarting, benchIds: nextBench },
  };
}

export function sortStandings(rows: StandingRow[]): StandingRow[] {
  return [...rows].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    const gdA = a.gf - a.ga;
    const gdB = b.gf - b.ga;
    if (gdB !== gdA) return gdB - gdA;
    if (b.gf !== a.gf) return b.gf - a.gf;
    return a.clubId.localeCompare(b.clubId);
  });
}

function sampleGoals(expectedGoals: number): number {
  const lambda = Math.max(0.25, Math.min(4.2, expectedGoals));
  let L = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k++;
    p *= Math.random();
  } while (p > L && k < 8);
  return k - 1;
}

export function simulateClubMatch(
  home: Club,
  away: Club,
  homeTactics?: TacticalSetup
): {
  homeGoals: number;
  awayGoals: number;
  scorers: { playerName: string; minute: number; clubId: string }[];
  attendance: number;
  gateRevenue: number;
} {
  const homeOvr = getClubAvgOvr(home) + 2.2; // Home advantage
  const awayOvr = getClubAvgOvr(away);

  let attackMod = 1.0;
  let defenseMod = 1.0;
  if (homeTactics) {
    if (homeTactics.mentality === 'All-Out Attack') {
      attackMod += 0.28;
      defenseMod += 0.2;
    } else if (homeTactics.mentality === 'Attacking') {
      attackMod += 0.14;
      defenseMod += 0.08;
    } else if (homeTactics.mentality === 'Defensive') {
      attackMod -= 0.12;
      defenseMod -= 0.18;
    } else if (homeTactics.mentality === 'Ultra Defensive') {
      attackMod -= 0.24;
      defenseMod -= 0.3;
    }
    if (homeTactics.pressing === 'Gegenpress') {
      attackMod += 0.1;
    }
  }

  const diff = (homeOvr - awayOvr) / 14;
  const xGHome = Math.max(0.4, (1.45 + diff * 0.65) * attackMod);
  const xGAway = Math.max(0.35, (1.15 - diff * 0.55) * defenseMod);

  const homeGoals = sampleGoals(xGHome);
  const awayGoals = sampleGoals(xGAway);

  const pickScorer = (club: Club): string => {
    const attackers = club.roster.filter((p) => p.position === 'FWD' || p.position === 'MID');
    const pool = attackers.length > 0 ? attackers : club.roster;
    const chosen = pool[Math.floor(Math.random() * Math.min(5, pool.length))];
    return chosen ? chosen.name : club.shortName;
  };

  const scorers: { playerName: string; minute: number; clubId: string }[] = [];
  for (let i = 0; i < homeGoals; i++) {
    scorers.push({
      playerName: pickScorer(home),
      minute: Math.floor(Math.random() * 88) + 2,
      clubId: home.id,
    });
  }
  for (let i = 0; i < awayGoals; i++) {
    scorers.push({
      playerName: pickScorer(away),
      minute: Math.floor(Math.random() * 88) + 2,
      clubId: away.id,
    });
  }
  scorers.sort((a, b) => a.minute - b.minute);

  const capacityFactor = 0.78 + Math.random() * 0.21;
  const attendance = Math.round(home.stadiumCapacity * capacityFactor);
  const gateRevenue = attendance * (42 + home.stadiumTier * 8);

  return { homeGoals, awayGoals, scorers, attendance, gateRevenue };
}

export function applyFastTrackRehab(
  club: Club,
  playerId: string,
  week: number
): { club: Club; recovered: boolean; playerName: string } {
  let recovered = false;
  let playerName = '';
  const updatedRoster = club.roster.map((p) => {
    if (p.id !== playerId || !p.injury) return p;
    playerName = p.name;
    const totalProgress = p.injury.recoveryProgress + 68;
    const weeksShaved = Math.floor(totalProgress / 100);
    const nextProgress = totalProgress % 100;
    const nextWeeks = p.injury.weeksRemaining - weeksShaved;
    if (nextWeeks <= 0) {
      recovered = true;
      return {
        ...p,
        injury: null,
        stamina: Math.max(p.stamina, 86),
        morale: Math.min(99, p.morale + 5),
      };
    }
    return {
      ...p,
      injury: {
        ...p.injury,
        weeksRemaining: nextWeeks,
        recoveryProgress: nextProgress,
      },
    };
  });

  return {
    club: { ...club, roster: updatedRoster },
    recovered,
    playerName: playerName || `Player (${week})`,
  };
}

export function applyTrainingToClub(
  club: Club,
  teamFocus: TrainingFocus,
  manager?: Pick<ManagerState, 'medicalStaff' | 'medicalProtocol'>,
  currentWeek = 1
): { club: Club; events: InjuryEventEntry[] } {
  const gymMultiplier = 1 + (club.gymTier - 1) * 0.25;
  const medical = manager
    ? getMedicalMetrics(club, manager)
    : {
        hiredStaff: [],
        recoverySpeedMultiplier: 1 + ((club.medicalTier || 1) - 1) * 0.25,
        injuryPreventionPct: ((club.medicalTier || 1) - 1) * 6,
        weeklyMedicalCost: 0,
      };
  const events: InjuryEventEntry[] = [];
  let newTrainingInjuriesThisBatch = 0;

  const updatedRoster = club.roster.map((player) => {
    // 1. Heal currently injured players using Medical Staff & Wing multiplier
    if (player.injury) {
      const gainedProgress = Math.round(100 * medical.recoverySpeedMultiplier);
      const totalProgress = player.injury.recoveryProgress + gainedProgress;
      const weeksHealed = Math.floor(totalProgress / 100);
      const nextWeeks = player.injury.weeksRemaining - weeksHealed;

      if (nextWeeks <= 0) {
        events.push({
          id: `rec_${player.id}_${currentWeek}_${Math.random().toString(36).slice(2, 6)}`,
          week: currentWeek,
          playerId: player.id,
          playerName: player.name,
          injuryType: player.injury.type,
          severity: player.injury.severity,
          source: player.injury.source,
          event: 'Recovered',
        });
        return {
          ...player,
          injury: null,
          stamina: Math.min(100, Math.max(82, player.stamina + 18)),
          morale: Math.min(99, player.morale + 6),
        };
      }

      return {
        ...player,
        stamina: Math.min(95, player.stamina + 8),
        injury: {
          ...player.injury,
          weeksRemaining: nextWeeks,
          recoveryProgress: totalProgress % 100,
        },
      };
    }

    // 2. Normal training progression for fit players
    const focus = player.trainingFocus || teamFocus;
    let { pace, shooting, passing, dribbling, defending, physical, stamina, morale } = player;

    const gain = Math.random() < 0.48 * gymMultiplier ? 1 : 0;

    if (focus === 'Finishing Drills') {
      shooting = Math.min(98, shooting + gain);
      stamina = Math.max(54, stamina - 5);
    } else if (focus === 'Tactical Rondo') {
      passing = Math.min(98, passing + gain);
      dribbling = Math.min(98, dribbling + (Math.random() < 0.3 * gymMultiplier ? 1 : 0));
      stamina = Math.max(58, stamina - 3);
    } else if (focus === 'Gym Conditioning') {
      physical = Math.min(98, physical + gain);
      stamina = Math.min(100, stamina + 4);
    } else if (focus === 'Sprint & Agility') {
      pace = Math.min(98, pace + gain);
      dribbling = Math.min(98, dribbling + (Math.random() < 0.3 * gymMultiplier ? 1 : 0));
      stamina = Math.max(50, stamina - 7);
    } else if (focus === 'Defensive Shape') {
      defending = Math.min(98, defending + gain);
      physical = Math.min(98, physical + (Math.random() < 0.3 * gymMultiplier ? 1 : 0));
      stamina = Math.max(56, stamina - 4);
    } else if (focus === 'Recovery Session') {
      stamina = Math.min(100, stamina + 18 + club.gymTier * 2);
      morale = Math.min(99, morale + 5);
    }

    // 3. Training injury check (high-intensity drills on fatigued players, mitigated by medical staff)
    let nextInjury: PlayerInjury | null = null;
    const isHighLoad =
      focus === 'Sprint & Agility' ||
      focus === 'Finishing Drills' ||
      focus === 'Defensive Shape' ||
      focus === 'Gym Conditioning';

    if (isHighLoad && newTrainingInjuriesThisBatch < 1) {
      const fatigueFactor = stamina < 68 ? 0.055 : stamina < 82 ? 0.02 : 0.008;
      const drillFactor = focus === 'Sprint & Agility' ? 1.45 : 1.0;
      const preventionFactor = 1 - medical.injuryPreventionPct / 100;
      const prob = fatigueFactor * drillFactor * preventionFactor;
      if (Math.random() < prob) {
        nextInjury = createPlayerInjury('Training', currentWeek);
        newTrainingInjuriesThisBatch += 1;
        events.push({
          id: `inj_tr_${player.id}_${currentWeek}_${Math.random().toString(36).slice(2, 6)}`,
          week: currentWeek,
          playerId: player.id,
          playerName: player.name,
          injuryType: nextInjury.type,
          severity: nextInjury.severity,
          source: 'Training',
          event: 'Injured',
          weeksOut: nextInjury.weeksRemaining,
        });
      }
    }

    const nextOvr = Math.min(
      98,
      Math.max(
        player.ovr,
        Math.round(
          (pace + shooting + passing + dribbling + defending + physical) / 6 +
            (player.position === 'GK' ? 12 : 4)
        )
      )
    );

    return {
      ...player,
      pace,
      shooting,
      passing,
      dribbling,
      defending,
      physical,
      stamina,
      morale,
      ovr: nextOvr,
      injury: nextInjury,
    };
  });

  return { club: { ...club, roster: updatedRoster }, events };
}

export function advanceManagerWeek(
  clubs: Record<string, Club>,
  manager: ManagerState,
  userMatchOverride?: { homeGoals: number; awayGoals: number }
): { clubs: Record<string, Club>; manager: ManagerState } {
  const week = manager.currentWeek;
  let nextClubs = { ...clubs };
  const nextStandings: Record<string, StandingRow[]> = {};

  for (const [leagueId, rows] of Object.entries(manager.standingsByLeague)) {
    nextStandings[leagueId] = rows.map((r) => ({ ...r, form: [...r.form] }));
  }

  let nextCareer = { ...manager.careerStats };
  const nextLedger = [...manager.ledger];
  const nextTrophies = [...manager.trophies];
  let summaryText = `Matchweek ${week} completed.`;

  // 1. Simulate/record league fixtures for this week
  const nextFixtures = manager.fixtures.map((fixture) => {
    if (fixture.week !== week || fixture.played) return fixture;
    const home = nextClubs[fixture.homeClubId];
    const away = nextClubs[fixture.awayClubId];
    if (!home || !away) return fixture;

    const isUserMatch =
      fixture.homeClubId === manager.clubId || fixture.awayClubId === manager.clubId;

    const sim = simulateClubMatch(
      home,
      away,
      isUserMatch ? manager.tactics : undefined
    );

    const homeGoals =
      isUserMatch && userMatchOverride ? userMatchOverride.homeGoals : sim.homeGoals;
    const awayGoals =
      isUserMatch && userMatchOverride ? userMatchOverride.awayGoals : sim.awayGoals;

    // Update league standings
    const table = nextStandings[fixture.leagueId];
    const homeRow = table?.find((r) => r.clubId === home.id);
    const awayRow = table?.find((r) => r.clubId === away.id);
    if (homeRow && awayRow) {
      homeRow.played += 1;
      awayRow.played += 1;
      homeRow.gf += homeGoals;
      homeRow.ga += awayGoals;
      awayRow.gf += awayGoals;
      awayRow.ga += homeGoals;

      if (homeGoals > awayGoals) {
        homeRow.won += 1;
        homeRow.points += 3;
        homeRow.form = [...homeRow.form.slice(-4), 'W'];
        awayRow.lost += 1;
        awayRow.form = [...awayRow.form.slice(-4), 'L'];
      } else if (homeGoals < awayGoals) {
        awayRow.won += 1;
        awayRow.points += 3;
        awayRow.form = [...awayRow.form.slice(-4), 'W'];
        homeRow.lost += 1;
        homeRow.form = [...homeRow.form.slice(-4), 'L'];
      } else {
        homeRow.drawn += 1;
        homeRow.points += 1;
        homeRow.form = [...homeRow.form.slice(-4), 'D'];
        awayRow.drawn += 1;
        awayRow.points += 1;
        awayRow.form = [...awayRow.form.slice(-4), 'D'];
      }
    }

    // Update user career stats & finances
    if (isUserMatch) {
      const userIsHome = fixture.homeClubId === manager.clubId;
      const gf = userIsHome ? homeGoals : awayGoals;
      const ga = userIsHome ? awayGoals : homeGoals;
      nextCareer.matchesPlayed += 1;
      nextCareer.goalsFor += gf;
      nextCareer.goalsAgainst += ga;
      if (gf > ga) nextCareer.wins += 1;
      else if (gf < ga) nextCareer.losses += 1;
      else nextCareer.draws += 1;

      summaryText = `${home.shortName} ${homeGoals} - ${awayGoals} ${away.shortName}`;

      if (userIsHome) {
        nextClubs[home.id] = {
          ...nextClubs[home.id],
          transferBudget: nextClubs[home.id].transferBudget + sim.gateRevenue,
        };
        nextLedger.unshift({
          id: `gate_${week}`,
          week,
          category: 'Matchday',
          description: `Home Gate (${sim.attendance.toLocaleString()} fans vs ${away.shortName})`,
          amount: sim.gateRevenue,
        });
      }
    }

    return {
      ...fixture,
      played: true,
      homeGoals,
      awayGoals,
      scorers: sim.scorers,
      attendance: sim.attendance,
      gateRevenue: sim.gateRevenue,
    };
  });

  // 2. Continental Cup Progression at Weeks 4, 7, 10
  let nextCupTies = manager.cupTies.map((tie) => {
    if (tie.week !== week || tie.played) return tie;
    const home = nextClubs[tie.homeClubId];
    const away = nextClubs[tie.awayClubId];
    if (!home || !away) return tie;
    const sim = simulateClubMatch(home, away);
    let hg = sim.homeGoals;
    let ag = sim.awayGoals;
    if (hg === ag) hg += 1; // Extra time / penalties winner
    const winnerId = hg > ag ? home.id : away.id;
    if (tie.round === 'Final' && winnerId === manager.clubId) {
      nextTrophies.push(`Continental Champions Cup (S${manager.seasonNumber})`);
    }
    return {
      ...tie,
      played: true,
      homeGoals: hg,
      awayGoals: ag,
      winnerId,
    };
  });

  // Spawn Semi-Finals after QF week 4
  if (week === 4) {
    const qfWinners = nextCupTies
      .filter((t) => t.round === 'Quarter-Final' && t.winnerId)
      .map((t) => t.winnerId!);
    if (qfWinners.length === 4) {
      nextCupTies = [
        ...nextCupTies,
        {
          id: 'cup_sf_1',
          round: 'Semi-Final',
          week: 7,
          homeClubId: qfWinners[0],
          awayClubId: qfWinners[1],
          played: false,
        },
        {
          id: 'cup_sf_2',
          round: 'Semi-Final',
          week: 7,
          homeClubId: qfWinners[2],
          awayClubId: qfWinners[3],
          played: false,
        },
      ];
    }
  }

  // Spawn Final after SF week 7
  if (week === 7) {
    const sfWinners = nextCupTies
      .filter((t) => t.round === 'Semi-Final' && t.winnerId)
      .map((t) => t.winnerId!);
    if (sfWinners.length === 2) {
      nextCupTies = [
        ...nextCupTies,
        {
          id: 'cup_final',
          round: 'Final',
          week: 10,
          homeClubId: sfWinners[0],
          awayClubId: sfWinners[1],
          played: false,
        },
      ];
    }
  }

  // 3. Apply weekly training, medical recovery, match sim injury roll & payroll for user's club
  let nextStartingXIIds = manager.startingXIIds;
  let nextBenchIds = manager.benchIds;
  let nextInjuryLog = [...(manager.injuryReportLog || [])];
  let userClub = nextClubs[manager.clubId];

  if (userClub) {
    const medical = getMedicalMetrics(userClub, manager);

    // Simulated match injury chance when simulating week (not live 3D match which handles injuries directly)
    if (!userMatchOverride) {
      const pressRisk = manager.tactics.pressing === 'Gegenpress' ? 1.35 : 1.0;
      const simInjuryChance = 0.24 * pressRisk * (1 - medical.injuryPreventionPct / 100);
      if (Math.random() < simInjuryChance) {
        const fitStarters = userClub.roster.filter(
          (p) => nextStartingXIIds.includes(p.id) && !p.injury
        );
        if (fitStarters.length > 0) {
          const victim = fitStarters[Math.floor(Math.random() * fitStarters.length)];
          const inj = createPlayerInjury('Match', week);
          userClub = {
            ...userClub,
            roster: userClub.roster.map((p) => (p.id === victim.id ? { ...p, injury: inj } : p)),
          };
          nextInjuryLog.unshift({
            id: `inj_match_${victim.id}_${week}_${Math.random().toString(36).slice(2, 6)}`,
            week,
            playerId: victim.id,
            playerName: victim.name,
            injuryType: inj.type,
            severity: inj.severity,
            source: 'Match',
            event: 'Injured',
            weeksOut: inj.weeksRemaining,
          });
        }
      }
    }

    const weeklyWages = userClub.roster.reduce((sum, p) => sum + p.weeklyWage, 0);
    const totalMedicalSpend = medical.weeklyMedicalCost;
    const { club: trainedClub, events } = applyTrainingToClub(
      userClub,
      manager.teamTrainingFocus,
      manager,
      week
    );
    if (events.length > 0) {
      nextInjuryLog = [...events, ...nextInjuryLog];
    }

    nextClubs[manager.clubId] = {
      ...trainedClub,
      transferBudget: Math.max(0, trainedClub.transferBudget - weeklyWages - totalMedicalSpend),
    };

    nextLedger.unshift({
      id: `wages_${week}`,
      week,
      category: 'Wages',
      description: `Squad Weekly Payroll (${trainedClub.roster.length} players)`,
      amount: -weeklyWages,
    });
    if (totalMedicalSpend > 0) {
      nextLedger.unshift({
        id: `med_cost_${week}`,
        week,
        category: 'Medical',
        description: `Medical Dept (${medical.hiredStaff.length} staff · ${manager.medicalProtocol})`,
        amount: -totalMedicalSpend,
      });
    }

    const reconciled = reconcileFitLineup(
      trainedClub.roster,
      nextStartingXIIds,
      nextBenchIds
    );
    nextStartingXIIds = reconciled.startingXIIds;
    nextBenchIds = reconciled.benchIds;
  }

  // 4. Check League Title at Week 10
  if (week === 10 && userClub) {
    const sorted = sortStandings(nextStandings[userClub.leagueId] || []);
    if (sorted[0]?.clubId === manager.clubId) {
      const leagueName = LEAGUES.find((l) => l.id === userClub.leagueId)?.name || 'League';
      nextTrophies.push(`${leagueName} Champions (S${manager.seasonNumber})`);
    }
  }

  const nextWeek = week >= 10 ? 1 : week + 1;
  const nextSeason = week >= 10 ? manager.seasonNumber + 1 : manager.seasonNumber;

  // Reset fixtures if wrapping into next season
  let finalFixtures = nextFixtures;
  let finalStandings = nextStandings;
  let finalCupTies = nextCupTies;
  if (week >= 10) {
    finalFixtures = LEAGUES.flatMap((l) => generateLeagueFixtures(l));
    finalCupTies = generateContinentalCup(nextClubs, manager.clubId);
    finalStandings = {};
    for (const l of LEAGUES) {
      finalStandings[l.id] = l.clubIds.map((id) => ({
        clubId: id,
        played: 0,
        won: 0,
        drawn: 0,
        lost: 0,
        gf: 0,
        ga: 0,
        points: 0,
        form: [],
      }));
    }
  }

  return {
    clubs: nextClubs,
    manager: {
      ...manager,
      seasonNumber: nextSeason,
      currentWeek: nextWeek,
      startingXIIds: nextStartingXIIds,
      benchIds: nextBenchIds,
      standingsByLeague: finalStandings,
      fixtures: finalFixtures,
      cupTies: finalCupTies,
      trophies: nextTrophies,
      ledger: nextLedger.slice(0, 30),
      careerStats: nextCareer,
      injuryReportLog: nextInjuryLog.slice(0, 25),
      lastMatchSummary: summaryText,
    },
  };
}

export type LiveTacticalUrgency = 'critical' | 'shift' | 'hold';

export interface LiveTacticalSuggestion {
  scenarioKey: string;
  urgency: LiveTacticalUrgency;
  situationLabel: string;
  headline: string;
  reason: string;
  recommendedTactics: TacticalSetup;
  formationChanged: boolean;
  isAlreadyApplied: boolean;
}

export function evaluateLiveTacticalSuggestion(params: {
  homeScore: number;
  awayScore: number;
  matchMinute: number;
  possessionHome: number;
  currentTactics: TacticalSetup;
  opponentName: string;
}): LiveTacticalSuggestion {
  const {
    homeScore,
    awayScore,
    matchMinute,
    possessionHome,
    currentTactics,
    opponentName,
  } = params;

  const diff = homeScore - awayScore;
  const min = Math.max(0, Math.min(95, Math.round(matchMinute)));
  const scoreTag = `${homeScore}-${awayScore}`;

  const phase: 'early' | 'mid' | 'late' | 'clutch' =
    min < 20 ? 'early' : min < 60 ? 'mid' : min < 75 ? 'late' : 'clutch';

  const scoreBucket =
    diff <= -2
      ? 'down_2plus'
      : diff === -1
        ? 'down_1'
        : diff === 0
          ? 'level'
          : diff === 1
            ? 'up_1'
            : 'up_2plus';

  let recommendedTactics: TacticalSetup = { ...currentTactics };
  let urgency: LiveTacticalUrgency = 'hold';
  let situationLabel = `${min}' · Level ${scoreTag}`;
  let headline = `Hold ${currentTactics.formation} Shape`;
  let reason = `Shape is balanced against ${opponentName}. Keep patience in possession.`;

  if (phase === 'clutch') {
    if (diff <= -1) {
      urgency = 'critical';
      situationLabel = `${min}' · Trailing ${scoreTag}`;
      recommendedTactics = {
        formation: '3-5-2',
        mentality: 'All-Out Attack',
        pressing: 'Gegenpress',
        passingStyle: 'Direct',
        defensiveLine: 'High',
      };
      headline = 'Push Twin Strikers & Wing-Backs';
      reason = `Final stretch down ${Math.abs(diff)}. Switch to 3-5-2 to overload ${opponentName}'s penalty area.`;
    } else if (diff === 0) {
      urgency = 'shift';
      situationLabel = `${min}' · Tied ${scoreTag}`;
      const push352 = min >= 82 || currentTactics.formation === '4-3-3';
      recommendedTactics = push352
        ? {
            formation: '3-5-2',
            mentality: 'All-Out Attack',
            pressing: 'Gegenpress',
            passingStyle: 'Direct',
            defensiveLine: 'High',
          }
        : {
            formation: '4-3-3',
            mentality: 'Attacking',
            pressing: 'Gegenpress',
            passingStyle: 'Direct',
            defensiveLine: 'High',
          };
      headline = push352 ? 'Go 3-5-2 for the Late Winner' : 'Press High with 4-3-3 Front Three';
      reason = `Level late on — pin ${opponentName} back with wide forwards and aggressive pressing.`;
    } else if (diff === 1) {
      urgency = 'critical';
      situationLabel = `${min}' · Protecting ${scoreTag}`;
      recommendedTactics = {
        formation: '5-3-2',
        mentality: 'Ultra Defensive',
        pressing: 'Low Block',
        passingStyle: 'Direct',
        defensiveLine: 'Deep',
      };
      headline = 'Lock the Box with Back Five';
      reason = `Defending a 1-goal lead in clutch time. Drop into a 5-3-2 low block to deny space behind.`;
    } else {
      urgency = 'shift';
      situationLabel = `${min}' · Leading ${scoreTag}`;
      recommendedTactics = {
        formation: '5-3-2',
        mentality: 'Defensive',
        pressing: 'Low Block',
        passingStyle: 'Tiki-Taka',
        defensiveLine: 'Deep',
      };
      headline = 'See Out Victory with 5-3-2';
      reason = `Two-goal cushion late on. Shield the penalty box and circulate safe short passes.`;
    }
  } else if (phase === 'late') {
    if (diff <= -2) {
      urgency = 'critical';
      situationLabel = `${min}' · Down ${Math.abs(diff)} (${scoreTag})`;
      recommendedTactics = {
        formation: '3-5-2',
        mentality: 'All-Out Attack',
        pressing: 'Gegenpress',
        passingStyle: 'Direct',
        defensiveLine: 'High',
      };
      headline = 'Switch to 3-5-2 High Press';
      reason = `Need goals quickly after 60'. Two strikers plus advancing wing-backs stretch ${opponentName}'s backline.`;
    } else if (diff === -1) {
      urgency = 'shift';
      situationLabel = `${min}' · Trailing ${scoreTag}`;
      recommendedTactics = {
        formation: '3-5-2',
        mentality: 'Attacking',
        pressing: 'Gegenpress',
        passingStyle: 'Direct',
        defensiveLine: 'High',
      };
      headline = 'Overload Attack with 3-5-2';
      reason = `Down one entering the last third — pair two strikers up top and press higher up the pitch.`;
    } else if (diff === 0) {
      urgency = 'shift';
      situationLabel = `${min}' · Level ${scoreTag}`;
      recommendedTactics = {
        formation: '4-2-3-1',
        mentality: 'Attacking',
        pressing: 'Gegenpress',
        passingStyle: 'Balanced',
        defensiveLine: 'High',
      };
      headline = 'Deploy #10 Playmaker in 4-2-3-1';
      reason = `Deadlocked past the hour mark. Add a central CAM between ${opponentName}'s midfield and defense.`;
    } else if (diff === 1) {
      urgency = 'shift';
      situationLabel = `${min}' · Leading ${scoreTag}`;
      recommendedTactics = {
        formation: '4-4-2',
        mentality: 'Defensive',
        pressing: 'Low Block',
        passingStyle: 'Direct',
        defensiveLine: 'Normal',
      };
      headline = 'Compact Two Banks in 4-4-2';
      reason = `Holding a narrow lead past 60'. Two structured lines of four close down wide channels.`;
    } else {
      urgency = 'hold';
      situationLabel = `${min}' · Control ${scoreTag}`;
      recommendedTactics = {
        formation: '4-3-3',
        mentality: 'Balanced',
        pressing: 'Mid Press',
        passingStyle: 'Tiki-Taka',
        defensiveLine: 'Normal',
      };
      headline = 'Manage Tempo in 4-3-3';
      reason = `Comfortable lead — keep possession triangles alive and conserve sprint stamina.`;
    }
  } else if (phase === 'mid') {
    if (diff <= -2) {
      urgency = 'critical';
      situationLabel = `${min}' · Trailing ${scoreTag}`;
      recommendedTactics = {
        formation: '3-5-2',
        mentality: 'Attacking',
        pressing: 'Gegenpress',
        passingStyle: 'Direct',
        defensiveLine: 'High',
      };
      headline = 'Commit Wing-Backs in 3-5-2';
      reason = `Down two goals early. Extra central bodies and dual strikers speed up the comeback.`;
    } else if (diff === -1) {
      urgency = 'shift';
      situationLabel = `${min}' · Trailing ${scoreTag}`;
      recommendedTactics = {
        formation: '4-2-3-1',
        mentality: 'Attacking',
        pressing: 'Gegenpress',
        passingStyle: 'Balanced',
        defensiveLine: 'High',
      };
      headline = 'Add Half-Space Creator (4-2-3-1)';
      reason = `One goal behind — push a dedicated CAM behind the striker to unlock ${opponentName}'s block.`;
    } else if (diff === 0 && possessionHome < 44) {
      urgency = 'shift';
      situationLabel = `${min}' · Low Ball (${possessionHome}%)`;
      recommendedTactics = {
        formation: '4-2-3-1',
        mentality: 'Balanced',
        pressing: 'Mid Press',
        passingStyle: 'Tiki-Taka',
        defensiveLine: 'Normal',
      };
      headline = 'Stabilize Midfield with 4-2-3-1';
      reason = `${opponentName} controls ${100 - possessionHome}% possession. Double pivot regains midfield control.`;
    } else if (diff === 1 && possessionHome < 45) {
      urgency = 'shift';
      situationLabel = `${min}' · Ahead ${scoreTag}`;
      recommendedTactics = {
        formation: '4-4-2',
        mentality: 'Balanced',
        pressing: 'Mid Press',
        passingStyle: 'Direct',
        defensiveLine: 'Normal',
      };
      headline = 'Counter on the Break with 4-4-2';
      reason = `Leading without the ball — twin forwards punish ${opponentName} in transition.`;
    } else if (diff >= 2) {
      urgency = 'hold';
      situationLabel = `${min}' · Dominant ${scoreTag}`;
      recommendedTactics = {
        formation: '4-3-3',
        mentality: 'Balanced',
        pressing: 'Mid Press',
        passingStyle: 'Tiki-Taka',
        defensiveLine: 'Normal',
      };
      headline = 'Circulate & Control in 4-3-3';
      reason = `Two goals clear — stretch ${opponentName} horizontally to avoid risky transitions.`;
    } else {
      urgency = 'hold';
      situationLabel = `${min}' · Balanced ${scoreTag}`;
      recommendedTactics = {
        formation: currentTactics.formation,
        mentality: 'Balanced',
        pressing: 'Mid Press',
        passingStyle: currentTactics.passingStyle,
        defensiveLine: 'Normal',
      };
      headline = `${currentTactics.formation} Holding Steady`;
      reason = `Even contest with ${possessionHome}% ball share. Keep pressing triggers disciplined.`;
    }
  } else {
    // Early phase (0' - 19')
    if (diff <= -2) {
      urgency = 'critical';
      situationLabel = `${min}' · Early Deficit ${scoreTag}`;
      recommendedTactics = {
        formation: '4-2-3-1',
        mentality: 'Attacking',
        pressing: 'Gegenpress',
        passingStyle: 'Balanced',
        defensiveLine: 'High',
      };
      headline = 'Rebalance Early with 4-2-3-1';
      reason = `Two down early — keep double defensive protection while pushing three attacking mids forward.`;
    } else if (diff >= 2) {
      urgency = 'hold';
      situationLabel = `${min}' · Fast Start ${scoreTag}`;
      recommendedTactics = {
        formation: '4-3-3',
        mentality: 'Balanced',
        pressing: 'Mid Press',
        passingStyle: 'Tiki-Taka',
        defensiveLine: 'Normal',
      };
      headline = 'Settle Rhythm in 4-3-3';
      reason = `Bright opening spell. Maintain controlled spacing without overcommitting full-backs.`;
    } else if (possessionHome < 42 && min >= 8) {
      urgency = 'shift';
      situationLabel = `${min}' · Early Pressure`;
      recommendedTactics = {
        formation: '4-4-2',
        mentality: 'Balanced',
        pressing: 'Mid Press',
        passingStyle: 'Direct',
        defensiveLine: 'Normal',
      };
      headline = 'Tighten Channels via 4-4-2';
      reason = `${opponentName} is dictating early tempo. Flatten into two compact lines of four.`;
    } else {
      urgency = 'hold';
      situationLabel = `${min}' · Opening Phase`;
      recommendedTactics = { ...currentTactics };
      headline = `${currentTactics.formation} On Gameplan`;
      reason = `Reading ${opponentName}'s early buildup. Tactical adjustments ready as match develops.`;
    }
  }

  const formationChanged = currentTactics.formation !== recommendedTactics.formation;
  const isAlreadyApplied =
    currentTactics.formation === recommendedTactics.formation &&
    currentTactics.mentality === recommendedTactics.mentality &&
    currentTactics.pressing === recommendedTactics.pressing &&
    currentTactics.defensiveLine === recommendedTactics.defensiveLine;

  return {
    scenarioKey: `${phase}_${scoreBucket}_${recommendedTactics.formation}`,
    urgency: isAlreadyApplied ? 'hold' : urgency,
    situationLabel,
    headline: isAlreadyApplied ? `${recommendedTactics.formation} Active` : headline,
    reason,
    recommendedTactics,
    formationChanged,
    isAlreadyApplied,
  };
}

