import {
  BodyType,
  CreatedPlayerProfile,
  FaceStyle,
  HairStyle,
  PlayerTraitId,
  PlaystyleId,
  Position,
  PreferredFoot,
} from '../types/game';

export const BASE_STAT_MIN = 50;
export const STAT_MAX = 95;
export const SKILL_POINT_POOL = 190; // 6 * 50 base (300) + 190 allocatable = 490 total budget
export const MAX_TRAITS = 3;

export const SKIN_TONES = ['#F2C9AC', '#E0AC8B', '#C68652', '#8D5524', '#5C381C'];
export const HAIR_COLORS = ['#1C1917', '#3B2F2F', '#78350F', '#D97706', '#E2E8F0', '#991B1B'];
export const BOOT_COLORS = ['#10B981', '#F59E0B', '#38BDF8', '#EF4444', '#F8FAFC', '#0F172A'];
export const PREFERRED_FEET: PreferredFoot[] = ['Right', 'Left', 'Both'];
export const POSITIONS: Position[] = ['FWD', 'MID', 'DEF', 'GK'];

export const FACE_STYLES: { id: FaceStyle; label: string; detail: string }[] = [
  { id: 'athletic', label: 'Athletic', detail: 'Clean-shaven, defined brow' },
  { id: 'sharp', label: 'Sharp', detail: 'Angular jaw & light goatee' },
  { id: 'sculpted', label: 'Sculpted', detail: 'Trimmed designer beard' },
  { id: 'veteran', label: 'Veteran', detail: 'Full beard & rugged brow' },
  { id: 'youthful', label: 'Youthful', detail: 'Smooth academy profile' },
];

export const HAIR_STYLES: { id: HairStyle; label: string }[] = [
  { id: 'short_crop', label: 'Short Crop' },
  { id: 'fade', label: 'High Fade' },
  { id: 'swept', label: 'Swept Back' },
  { id: 'mohawk', label: 'Mohawk' },
  { id: 'afro', label: 'Full Crown' },
  { id: 'buzz', label: 'Buzz Cut' },
];

export const BODY_TYPES: {
  id: BodyType;
  label: string;
  detail: string;
  widthScale: number;
  limbScale: number;
  defaultHeight: number;
}[] = [
  {
    id: 'lean',
    label: 'Lean',
    detail: 'Agile wing frame · faster turns',
    widthScale: 0.88,
    limbScale: 0.88,
    defaultHeight: 0.96,
  },
  {
    id: 'athletic',
    label: 'Athletic',
    detail: 'Balanced pro proportions',
    widthScale: 1.0,
    limbScale: 1.0,
    defaultHeight: 1.0,
  },
  {
    id: 'stocky',
    label: 'Stocky',
    detail: 'Broad shoulders · strong shielding',
    widthScale: 1.15,
    limbScale: 1.14,
    defaultHeight: 0.98,
  },
  {
    id: 'towering',
    label: 'Towering',
    detail: 'Tall aerial target physique',
    widthScale: 1.08,
    limbScale: 1.06,
    defaultHeight: 1.07,
  },
];

export interface PlaystyleOption {
  id: PlaystyleId;
  primaryRole: Position;
  secondaryRole: Position | null;
  summary: string;
  recommendedStats: {
    pace: number;
    shooting: number;
    passing: number;
    dribbling: number;
    defending: number;
    physical: number;
  };
}

export const PLAYSTYLES: PlaystyleOption[] = [
  {
    id: 'Target Striker',
    primaryRole: 'FWD',
    secondaryRole: 'MID',
    summary: 'Clinical penalty-box finisher with physical hold-up presence.',
    recommendedStats: { pace: 84, shooting: 92, passing: 74, dribbling: 82, defending: 62, physical: 96 > 95 ? 95 : 88 },
  },
  {
    id: 'Inside Forward',
    primaryRole: 'FWD',
    secondaryRole: 'MID',
    summary: 'Explosive wide attacker cutting inside on curved finesse shots.',
    recommendedStats: { pace: 93, shooting: 88, passing: 81, dribbling: 92, defending: 56, physical: 80 },
  },
  {
    id: 'Deep-Lying Playmaker',
    primaryRole: 'MID',
    secondaryRole: 'DEF',
    summary: 'Tempo controller dictating buildup with incisive long passes.',
    recommendedStats: { pace: 76, shooting: 78, passing: 94, dribbling: 88, defending: 78, physical: 76 },
  },
  {
    id: 'Box-to-Box Engine',
    primaryRole: 'MID',
    secondaryRole: 'FWD',
    summary: 'Relentless two-way midfielder covering every blade of grass.',
    recommendedStats: { pace: 85, shooting: 80, passing: 86, dribbling: 84, defending: 79, physical: 76 },
  },
  {
    id: 'Ball-Playing Defender',
    primaryRole: 'DEF',
    secondaryRole: 'MID',
    summary: 'Composed center-back stepping out to launch counter-attacks.',
    recommendedStats: { pace: 82, shooting: 62, passing: 83, dribbling: 76, defending: 94, physical: 93 },
  },
  {
    id: 'Sweeper Keeper',
    primaryRole: 'GK',
    secondaryRole: 'DEF',
    summary: 'Commanding shot-stopper initiating rapid distribution from the back.',
    recommendedStats: { pace: 72, shooting: 58, passing: 87, dribbling: 76, defending: 92, physical: 95 },
  },
];

export interface PlayerTraitOption {
  id: PlayerTraitId;
  name: string;
  category: 'Attacking' | 'Playmaking' | 'Defensive' | 'Physical';
  effect: string;
}

export const PLAYER_TRAITS: PlayerTraitOption[] = [
  {
    id: 'speedster',
    name: 'Speedster',
    category: 'Physical',
    effect: '+12% top sprint velocity & lower sprint stamina drain on pitch.',
  },
  {
    id: 'finesse_shot',
    name: 'Finesse Curler',
    category: 'Attacking',
    effect: '+35% Magnus curve spin and higher top-corner shot velocity.',
  },
  {
    id: 'clinical_finisher',
    name: 'Clinical Finisher',
    category: 'Attacking',
    effect: 'Stronger goal-frame targeting assist inside the attacking third.',
  },
  {
    id: 'playmaker',
    name: 'Vision Maestro',
    category: 'Playmaking',
    effect: 'Wider smart pass-assist cone and crisper ground distribution.',
  },
  {
    id: 'set_piece_specialist',
    name: 'Dead-Ball Whip',
    category: 'Playmaking',
    effect: 'Enhanced lofted pass trajectory and extra ball dip over walls.',
  },
  {
    id: 'box_to_box',
    name: 'Relentless Engine',
    category: 'Physical',
    effect: '+35% passive stamina recovery across both halves and gym drills.',
  },
  {
    id: 'brick_wall',
    name: 'Brick Wall',
    category: 'Defensive',
    effect: '+25% press/tackle lunge surge and tighter defensive interception reach.',
  },
  {
    id: 'aerial_threat',
    name: 'Aerial Dominance',
    category: 'Defensive',
    effect: 'Wins contested lofted clearances and boosts corner xG rating.',
  },
];

export type AttributeKey =
  | 'pace'
  | 'shooting'
  | 'passing'
  | 'dribbling'
  | 'defending'
  | 'physical';

export const ATTRIBUTE_META: {
  key: AttributeKey;
  label: string;
  short: string;
  keyFor: Position[];
}[] = [
  { key: 'pace', label: 'Pace & Sprint', short: 'PAC', keyFor: ['FWD', 'DEF'] },
  { key: 'shooting', label: 'Finishing & Shot Curve', short: 'SHO', keyFor: ['FWD', 'MID'] },
  { key: 'passing', label: 'Vision & Passing', short: 'PAS', keyFor: ['MID', 'GK'] },
  { key: 'dribbling', label: 'Ball Control & Dribble', short: 'DRI', keyFor: ['FWD', 'MID'] },
  { key: 'defending', label: 'Tackling & Marking', short: 'DEF', keyFor: ['DEF', 'GK'] },
  { key: 'physical', label: 'Gym Strength & Stamina', short: 'PHY', keyFor: ['DEF', 'GK', 'FWD'] },
];

export function getSkillPointsUsed(stats: Pick<CreatedPlayerProfile, AttributeKey>): number {
  return (
    stats.pace -
    BASE_STAT_MIN +
    (stats.shooting - BASE_STAT_MIN) +
    (stats.passing - BASE_STAT_MIN) +
    (stats.dribbling - BASE_STAT_MIN) +
    (stats.defending - BASE_STAT_MIN) +
    (stats.physical - BASE_STAT_MIN)
  );
}

export function computePositionOvr(
  stats: Pick<CreatedPlayerProfile, AttributeKey>,
  position: Position
): number {
  let weighted = 0;
  if (position === 'FWD') {
    weighted =
      stats.shooting * 0.3 +
      stats.pace * 0.24 +
      stats.dribbling * 0.24 +
      stats.passing * 0.1 +
      stats.physical * 0.1 +
      stats.defending * 0.02;
  } else if (position === 'MID') {
    weighted =
      stats.passing * 0.3 +
      stats.dribbling * 0.26 +
      stats.shooting * 0.14 +
      stats.pace * 0.12 +
      stats.defending * 0.1 +
      stats.physical * 0.08;
  } else if (position === 'DEF') {
    weighted =
      stats.defending * 0.34 +
      stats.physical * 0.24 +
      stats.pace * 0.18 +
      stats.passing * 0.14 +
      stats.dribbling * 0.08 +
      stats.shooting * 0.02;
  } else {
    weighted =
      stats.defending * 0.34 +
      stats.physical * 0.3 +
      stats.passing * 0.2 +
      stats.dribbling * 0.08 +
      stats.pace * 0.06 +
      stats.shooting * 0.02;
  }
  return Math.max(55, Math.min(97, Math.round(weighted + 3)));
}

export function normalizeBudgetStats(
  raw: Pick<CreatedPlayerProfile, AttributeKey>
): Pick<CreatedPlayerProfile, AttributeKey> {
  const keys: AttributeKey[] = ['pace', 'shooting', 'passing', 'dribbling', 'defending', 'physical'];
  const result = { ...raw };
  for (const k of keys) {
    result[k] = Math.max(BASE_STAT_MIN, Math.min(STAT_MAX, Math.round(result[k])));
  }

  let used = getSkillPointsUsed(result);
  let guard = 0;
  while (used > SKILL_POINT_POOL && guard < 300) {
    guard++;
    // Trim from highest stat
    let bestKey: AttributeKey = keys[0];
    for (const k of keys) {
      if (result[k] > result[bestKey]) bestKey = k;
    }
    if (result[bestKey] <= BASE_STAT_MIN) break;
    result[bestKey] -= 1;
    used -= 1;
  }
  return result;
}

export function createRolePresetStats(
  position: Position,
  playstyle?: PlaystyleId
): Pick<CreatedPlayerProfile, AttributeKey> {
  const styleMatch = PLAYSTYLES.find((p) => p.id === playstyle && p.primaryRole === position);
  if (styleMatch) {
    return normalizeBudgetStats(styleMatch.recommendedStats);
  }
  if (position === 'FWD') {
    return normalizeBudgetStats({
      pace: 91,
      shooting: 91,
      passing: 78,
      dribbling: 90,
      defending: 56,
      physical: 84,
    });
  }
  if (position === 'MID') {
    return normalizeBudgetStats({
      pace: 82,
      shooting: 80,
      passing: 93,
      dribbling: 89,
      defending: 74,
      physical: 72,
    });
  }
  if (position === 'DEF') {
    return normalizeBudgetStats({
      pace: 82,
      shooting: 60,
      passing: 81,
      dribbling: 75,
      defending: 94,
      physical: 93,
    });
  }
  return normalizeBudgetStats({
    pace: 72,
    shooting: 55,
    passing: 87,
    dribbling: 76,
    defending: 93,
    physical: 94,
  });
}

export const DEFAULT_CREATED_PLAYER: CreatedPlayerProfile = {
  name: 'Alex Mercer',
  nationality: 'ENG',
  position: 'FWD',
  secondaryPosition: 'MID',
  number: 10,
  age: 21,
  preferredFoot: 'Right',
  ovr: 90,
  pace: 91,
  shooting: 91,
  passing: 78,
  dribbling: 90,
  defending: 56,
  physical: 84,
  skinTone: '#E0AC8B',
  hairColor: '#1C1917',
  faceStyle: 'athletic',
  hairStyle: 'fade',
  bodyType: 'athletic',
  bootColor: '#10B981',
  heightScale: 1.0,
  playstyle: 'Inside Forward',
  traits: ['speedster', 'finesse_shot'],
};
