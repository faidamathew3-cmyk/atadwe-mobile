type MusicListener = (playing: boolean) => void;

interface VocalNote {
  step: number;
  freq: number;
  durSteps: number;
  vowel: 'ah' | 'oh' | 'eh' | 'ee';
  harmonyFreq?: number;
}

const VOWEL_FORMANTS: Record<VocalNote['vowel'], [number, number]> = {
  ah: [740, 1120],
  oh: [540, 860],
  eh: [520, 1780],
  ee: [310, 2150],
};

// Uplifting Ghanaian Highlife / Afrobeats chord progression (Fmaj7 -> G6 -> Em7 -> Am7)
const CHORD_BARS: { root: number; bass: number; notes: number[]; guitar: number[] }[] = [
  {
    root: 174.61,
    bass: 87.31,
    notes: [261.63, 329.63, 349.23, 440.0],
    guitar: [349.23, 440.0, 523.25, 659.25, 523.25, 440.0],
  },
  {
    root: 196.0,
    bass: 98.0,
    notes: [293.66, 329.63, 392.0, 493.88],
    guitar: [392.0, 493.88, 587.33, 659.25, 587.33, 493.88],
  },
  {
    root: 164.81,
    bass: 82.41,
    notes: [246.94, 293.66, 329.63, 392.0],
    guitar: [329.63, 392.0, 493.88, 587.33, 493.88, 392.0],
  },
  {
    root: 220.0,
    bass: 110.0,
    notes: [261.63, 329.63, 392.0, 440.0],
    guitar: [440.0, 523.25, 659.25, 783.99, 659.25, 523.25],
  },
];

// Kuami Eugene Highlife / Afrobeats inspired singing hook across 64 16th-note steps
const VOCAL_MELODY: VocalNote[] = [
  // Bar 1 (Fmaj7): "Oh na-na, A-ta-dwe..."
  { step: 0, freq: 523.25, durSteps: 3, vowel: 'oh', harmonyFreq: 659.25 },
  { step: 3, freq: 587.33, durSteps: 3, vowel: 'ah' },
  { step: 6, freq: 659.25, durSteps: 4, vowel: 'ah', harmonyFreq: 783.99 },
  { step: 11, freq: 587.33, durSteps: 2, vowel: 'eh' },
  { step: 13, freq: 523.25, durSteps: 3, vowel: 'ah' },

  // Bar 2 (G6): "Rock-star feel-ing high..."
  { step: 16, freq: 587.33, durSteps: 3, vowel: 'oh', harmonyFreq: 739.99 },
  { step: 19, freq: 659.25, durSteps: 3, vowel: 'ah' },
  { step: 22, freq: 783.99, durSteps: 5, vowel: 'ee', harmonyFreq: 987.77 },
  { step: 28, freq: 659.25, durSteps: 2, vowel: 'eh' },
  { step: 30, freq: 587.33, durSteps: 2, vowel: 'oh' },

  // Bar 3 (Em7): "Step on the pitch, yeah..."
  { step: 32, freq: 493.88, durSteps: 3, vowel: 'eh', harmonyFreq: 587.33 },
  { step: 35, freq: 587.33, durSteps: 3, vowel: 'ah' },
  { step: 38, freq: 659.25, durSteps: 4, vowel: 'oh', harmonyFreq: 783.99 },
  { step: 43, freq: 587.33, durSteps: 2, vowel: 'eh' },
  { step: 45, freq: 493.88, durSteps: 3, vowel: 'ah' },

  // Bar 4 (Am7): "E-le-le-le, we go shine..."
  { step: 48, freq: 440.0, durSteps: 2, vowel: 'ee' },
  { step: 50, freq: 523.25, durSteps: 2, vowel: 'eh' },
  { step: 52, freq: 587.33, durSteps: 3, vowel: 'ah', harmonyFreq: 659.25 },
  { step: 55, freq: 659.25, durSteps: 5, vowel: 'oh', harmonyFreq: 783.99 },
  { step: 61, freq: 523.25, durSteps: 3, vowel: 'ah' },
];

class ProceduralSoundEngine {
  private ctx: AudioContext | null = null;
  private muted = false;
  private musicMasterGain: GainNode | null = null;
  private musicPlaying = false;
  private musicDesired = true;
  private musicDucked = false;
  private schedulerTimer = 0;
  private nextNoteTime = 0;
  private currentStep = 0;
  private listeners = new Set<MusicListener>();

  private readonly stepDuration = 60 / 102 / 4; // 102 BPM Afrobeats/Highlife 16th-note (~147ms)

  private ensureContext(allowWhenMuted = false): AudioContext | null {
    if (this.muted && !allowWhenMuted) return null;
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (!this.ctx) return null;

    if (!this.musicMasterGain) {
      const lp = this.ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 5200;

      const master = this.ctx.createGain();
      master.gain.value = 0;
      master.connect(lp);
      lp.connect(this.ctx.destination);
      this.musicMasterGain = master;
    }

    if (this.ctx.state === 'suspended') {
      void this.ctx.resume().then(() => {
        if (this.musicDesired && !this.muted && !this.musicPlaying) {
          this.beginMusicLoop();
        }
      }).catch(() => {});
    }
    return this.ctx;
  }

  public subscribeMusicState(listener: MusicListener): () => void {
    this.listeners.add(listener);
    listener(this.musicPlaying && !this.muted);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyMusicListeners() {
    const active = this.musicPlaying && !this.muted;
    this.listeners.forEach((cb) => cb(active));
  }

  private getTargetMusicVolume(): number {
    if (this.muted || !this.musicPlaying) return 0;
    return this.musicDucked ? 0.14 : 0.28;
  }

  private updateMusicGain() {
    if (!this.ctx || !this.musicMasterGain) return;
    const target = this.getTargetMusicVolume();
    this.musicMasterGain.gain.cancelScheduledValues(this.ctx.currentTime);
    this.musicMasterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.12);
  }

  public setMusicDuck(ducked: boolean) {
    this.musicDucked = ducked;
    this.updateMusicGain();
  }

  public startKuamiEugeneSong(): boolean {
    this.musicDesired = true;
    const ctx = this.ensureContext(false);
    if (!ctx) return false;
    if (ctx.state === 'running') {
      this.beginMusicLoop();
      return true;
    }
    return false;
  }

  public stopKuamiEugeneSong() {
    this.musicDesired = false;
    this.musicPlaying = false;
    if (this.schedulerTimer) {
      window.clearInterval(this.schedulerTimer);
      this.schedulerTimer = 0;
    }
    this.updateMusicGain();
    this.notifyMusicListeners();
  }

  public toggleMusic(): boolean {
    if (this.musicPlaying && !this.muted) {
      this.stopKuamiEugeneSong();
      return false;
    }
    if (this.muted) {
      this.setMuted(false);
    }
    this.startKuamiEugeneSong();
    return true;
  }

  public isMusicPlaying(): boolean {
    return this.musicPlaying && !this.muted;
  }

  private beginMusicLoop() {
    if (!this.ctx || this.musicPlaying || this.muted) return;
    this.musicPlaying = true;
    this.currentStep = 0;
    this.nextNoteTime = this.ctx.currentTime + 0.05;
    this.updateMusicGain();
    this.notifyMusicListeners();

    this.schedulerTimer = window.setInterval(() => {
      this.scheduleAhead();
    }, 45);
  }

  private scheduleAhead() {
    if (!this.ctx || !this.musicPlaying || this.muted || this.ctx.state !== 'running') return;
    const lookahead = 0.16;
    while (this.nextNoteTime < this.ctx.currentTime + lookahead) {
      this.scheduleStep(this.currentStep, this.nextNoteTime);
      this.nextNoteTime += this.stepDuration;
      this.currentStep = (this.currentStep + 1) % 64;
    }
  }

  private scheduleStep(step: number, time: number) {
    const ctx = this.ctx;
    const out = this.musicMasterGain;
    if (!ctx || !out) return;

    const barIdx = Math.floor(step / 16);
    const barStep = step % 16;
    const chord = CHORD_BARS[barIdx];

    // 1. Afrobeats Tresillo Kick (steps 0, 3, 6, 10, 12 in feel -> crisp 0, 6, 10, 14 bounce)
    if (barStep === 0 || barStep === 6 || barStep === 10 || (barIdx % 2 === 1 && barStep === 14)) {
      this.playMusicKick(ctx, out, time);
    }

    // 2. Highlife Wooden Rimshot Clave (3-2 Afrobeats bounce)
    if (barStep === 3 || barStep === 6 || barStep === 10 || barStep === 12) {
      this.playMusicRimshot(ctx, out, time, barStep === 12 ? 0.24 : 0.16);
    }

    // 3. Soft Cabasa / Shaker on 8th-note offbeats & 16th ghost groove
    if (barStep % 2 === 0 || barStep % 4 === 3) {
      this.playMusicShaker(ctx, out, time, barStep % 2 === 0 ? 0.07 : 0.035);
    }

    // 4. Warm Log-Drum / Highlife Bass
    if (barStep === 0 || barStep === 6 || barStep === 10) {
      const bassFreq = barStep === 10 ? chord.bass * 1.122 : chord.bass;
      this.playMusicBass(ctx, out, time, bassFreq, this.stepDuration * 2.6);
    }

    // 5. Electric Piano Warm Stabs on bar downbeat & syncopated "and" of 2
    if (barStep === 0 || barStep === 6) {
      const stabDur = barStep === 0 ? this.stepDuration * 5 : this.stepDuration * 3.5;
      for (const f of chord.notes) {
        this.playMusicKeys(ctx, out, time, f, stabDur);
      }
    }

    // 6. Signature Ghanaian Highlife Plucked Guitar Riff
    if (barStep === 0 || barStep === 2 || barStep === 4 || barStep === 7 || barStep === 9 || barStep === 12 || barStep === 14) {
      const gNote = chord.guitar[(step >> 1) % chord.guitar.length];
      this.playHighlifeGuitar(ctx, out, time, gNote, this.stepDuration * 2.1);
    }

    // 7. Kuami Eugene Style Singing Vocal Formant Hook
    for (const v of VOCAL_MELODY) {
      if (v.step === step) {
        const dur = v.durSteps * this.stepDuration;
        this.playSingingVocal(ctx, out, time, v.freq, dur, v.vowel, 0.34);
        if (v.harmonyFreq) {
          this.playSingingVocal(ctx, out, time, v.harmonyFreq, dur, v.vowel, 0.14);
        }
      }
    }
  }

  private playMusicKick(ctx: AudioContext, out: GainNode, time: number) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(125, time);
    osc.frequency.exponentialRampToValueAtTime(44, time + 0.14);
    gain.gain.setValueAtTime(0.52, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.2);
    osc.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc.stop(time + 0.22);
  }

  private playMusicRimshot(ctx: AudioContext, out: GainNode, time: number, vol: number) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(920, time);
    osc.frequency.exponentialRampToValueAtTime(420, time + 0.045);
    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.06);
    osc.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc.stop(time + 0.07);
  }

  private playMusicShaker(ctx: AudioContext, out: GainNode, time: number, vol: number) {
    const dur = 0.04;
    const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 5400;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + dur);
    src.connect(hp);
    hp.connect(gain);
    gain.connect(out);
    src.start(time);
  }

  private playMusicBass(ctx: AudioContext, out: GainNode, time: number, freq: number, dur: number) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq * 1.15, time);
    osc.frequency.exponentialRampToValueAtTime(freq, time + 0.05);
    gain.gain.setValueAtTime(0.001, time);
    gain.gain.linearRampToValueAtTime(0.38, time + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, time + dur);
    osc.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc.stop(time + dur + 0.02);
  }

  private playMusicKeys(ctx: AudioContext, out: GainNode, time: number, freq: number, dur: number) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, time);
    gain.gain.setValueAtTime(0.001, time);
    gain.gain.linearRampToValueAtTime(0.065, time + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.001, time + dur);
    osc.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc.stop(time + dur + 0.02);
  }

  private playHighlifeGuitar(ctx: AudioContext, out: GainNode, time: number, freq: number, dur: number) {
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, time);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(2100, time);
    filter.frequency.exponentialRampToValueAtTime(650, time + dur);

    gain.gain.setValueAtTime(0.001, time);
    gain.gain.linearRampToValueAtTime(0.14, time + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(out);
    osc.start(time);
    osc.stop(time + dur + 0.02);
  }

  private playSingingVocal(
    ctx: AudioContext,
    out: GainNode,
    time: number,
    freq: number,
    dur: number,
    vowel: VocalNote['vowel'],
    volume: number
  ) {
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const vib = ctx.createOscillator();
    const vibGain = ctx.createGain();

    osc1.type = 'sawtooth';
    osc2.type = 'triangle';
    // Natural human vocal pitch scoop on syllable onset
    osc1.frequency.setValueAtTime(freq * 0.94, time);
    osc1.frequency.exponentialRampToValueAtTime(freq, time + 0.055);
    osc2.frequency.setValueAtTime(freq * 0.94, time);
    osc2.frequency.exponentialRampToValueAtTime(freq, time + 0.055);

    // Expressive vibrato
    vib.frequency.setValueAtTime(5.6, time);
    vibGain.gain.setValueAtTime(0, time);
    vibGain.gain.linearRampToValueAtTime(freq * 0.014, time + Math.min(0.14, dur * 0.45));
    vib.connect(vibGain);
    vibGain.connect(osc1.frequency);
    vibGain.connect(osc2.frequency);

    // Dual vocal tract Formant filters (F1 + F2)
    const [f1Freq, f2Freq] = VOWEL_FORMANTS[vowel];
    const f1 = ctx.createBiquadFilter();
    f1.type = 'bandpass';
    f1.frequency.setValueAtTime(f1Freq, time);
    f1.Q.value = 4.2;

    const f2 = ctx.createBiquadFilter();
    f2.type = 'bandpass';
    f2.frequency.setValueAtTime(f2Freq, time);
    f2.Q.value = 6.0;

    const env = ctx.createGain();
    env.gain.setValueAtTime(0.001, time);
    env.gain.linearRampToValueAtTime(volume, time + 0.045);
    env.gain.setValueAtTime(volume * 0.85, Math.max(time + 0.06, time + dur - 0.08));
    env.gain.exponentialRampToValueAtTime(0.001, time + dur + 0.04);

    // Subtle vocal echo repeat for stadium atmosphere
    const delay = ctx.createDelay(0.5);
    delay.delayTime.value = this.stepDuration * 2;
    const echoGain = ctx.createGain();
    echoGain.gain.value = 0.24;

    osc1.connect(f1);
    osc1.connect(f2);
    osc2.connect(f1);
    osc2.connect(f2);
    f1.connect(env);
    f2.connect(env);

    env.connect(out);
    env.connect(delay);
    delay.connect(echoGain);
    echoGain.connect(out);

    vib.start(time);
    osc1.start(time);
    osc2.start(time);
    vib.stop(time + dur + 0.06);
    osc1.stop(time + dur + 0.06);
    osc2.stop(time + dur + 0.06);
  }

  public setMuted(muted: boolean) {
    this.muted = muted;
    if (muted) {
      this.updateMusicGain();
    } else if (this.musicDesired) {
      this.startKuamiEugeneSong();
    }
    this.notifyMusicListeners();
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public playKick(power = 0.7) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    const clampedPower = Math.max(0.2, Math.min(1, power));
    osc.frequency.setValueAtTime(140 + clampedPower * 80, now);
    osc.frequency.exponentialRampToValueAtTime(38, now + 0.11);

    gain.gain.setValueAtTime(0.32 * clampedPower, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);
  }

  public playPostHit() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(310, now + 0.25);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.28);
  }

  public playWhistle(kind: 'kickoff' | 'fulltime' = 'kickoff') {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const triggerBlast = (start: number, dur: number) => {
      const osc = ctx.createOscillator();
      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(2850, start);

      lfo.frequency.setValueAtTime(36, start);
      lfoGain.gain.setValueAtTime(95, start);
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);

      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(0.14, start + 0.02);
      gain.gain.setValueAtTime(0.14, start + dur - 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, start + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      lfo.start(start);
      osc.start(start);
      lfo.stop(start + dur);
      osc.stop(start + dur);
    };

    if (kind === 'kickoff') {
      triggerBlast(now, 0.32);
    } else {
      triggerBlast(now, 0.18);
      triggerBlast(now + 0.24, 0.18);
      triggerBlast(now + 0.48, 0.45);
    }
  }

  public playCrowdGoalRoar() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const duration = 1.6;
    const bufferSize = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);

    let lastOut = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + 0.05 * white) / 1.05;
      lastOut = data[i];
      data[i] *= 2.5;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(520, now);
    filter.frequency.linearRampToValueAtTime(920, now + 0.4);
    filter.frequency.linearRampToValueAtTime(480, now + duration);
    filter.Q.value = 0.8;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.24, now + 0.18);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    noise.start(now);
    noise.stop(now + duration);
  }
}

export const soundEngine = new ProceduralSoundEngine();
