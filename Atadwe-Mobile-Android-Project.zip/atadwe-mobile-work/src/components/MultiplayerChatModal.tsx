import React, { useState } from 'react';
import {
  Cloud,
  Globe,
  Mic,
  MicOff,
  Send,
  Trophy,
  Users,
  X,
  LogIn,
  LogOut,
  Download,
  Upload,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  ChatMessage,
  LeaderboardEntry,
  MultiplayerRoom,
  Platform,
} from '../types/game';
import { CloudSaveRecord } from '../firebase';

interface MultiplayerChatModalProps {
  wsConnected: boolean;
  peerId: string;
  platform: Platform;
  onChangePlatform: (p: Platform) => void;
  rooms: MultiplayerRoom[];
  activeRoom: MultiplayerRoom | null;
  onCreateRoom: (roomName: string) => void;
  onJoinRoom: (roomId: string) => void;
  onLeaveRoom: () => void;
  chatMessages: ChatMessage[];
  onSendChat: (text: string, channel: 'global' | 'room') => void;
  voiceActive: boolean;
  voiceError: string | null;
  onToggleVoice: () => void;
  leaderboard: LeaderboardEntry[];
  // Firebase Cross-Platform Cloud Save
  firebaseUser: User | null;
  cloudSaves: CloudSaveRecord[];
  cloudStatus: string | null;
  onSignInGoogle: () => void;
  onSignOut: () => void;
  onSaveCloud: (slotName: string) => void;
  onLoadCloud: (save: CloudSaveRecord) => void;
  onClose: () => void;
}

export const MultiplayerChatModal: React.FC<MultiplayerChatModalProps> = ({
  wsConnected,
  platform,
  onChangePlatform,
  rooms,
  activeRoom,
  onCreateRoom,
  onJoinRoom,
  onLeaveRoom,
  chatMessages,
  onSendChat,
  voiceActive,
  voiceError,
  onToggleVoice,
  leaderboard,
  firebaseUser,
  cloudSaves,
  cloudStatus,
  onSignInGoogle,
  onSignOut,
  onSaveCloud,
  onLoadCloud,
  onClose,
}) => {
  const [tab, setTab] = useState<'multiplayer' | 'leaderboard' | 'cloud'>('multiplayer');
  const [roomName, setRoomName] = useState('Champions Night Lobby');
  const [chatChannel, setChatChannel] = useState<'global' | 'room'>('global');
  const [chatText, setChatText] = useState('');
  const [slotName, setSlotName] = useState('Main Cross-Platform Career');

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatText.trim()) return;
    onSendChat(chatText.trim(), chatChannel);
    setChatText('');
  };

  const visibleMessages = chatMessages.filter((m) =>
    chatChannel === 'global' ? m.channel === 'global' : m.channel !== 'global'
  );

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 p-3 md:p-5">
      <div className="w-full max-w-5xl h-[88vh] flex flex-col rounded-xl border border-white/10 bg-[#0B111B] shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-6 py-4 bg-[#0E1624]">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-wide text-white">
              Online Multiplayer · Voice Chat · Cross-Platform Cloud
            </h2>
            <p className="text-xs text-slate-400">
              Sync {wsConnected ? 'Connected' : 'Reconnecting'} · Device Mode{' '}
              <span className="text-emerald-400 font-semibold">{platform}</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={platform}
              onChange={(e) => onChangePlatform(e.target.value as Platform)}
              className="rounded-lg border border-white/15 bg-[#111927] px-3 py-1.5 text-xs text-white"
              aria-label="Select Platform Profile"
            >
              <option value="PC">PC</option>
              <option value="Console">Console</option>
              <option value="Mobile">Mobile</option>
            </select>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
              aria-label="Close Multiplayer Hub"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Sub-nav */}
        <div className="flex items-center gap-1 border-b border-white/10 px-6 py-2 bg-[#090E17]">
          <button
            onClick={() => setTab('multiplayer')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold ${
              tab === 'multiplayer'
                ? 'bg-emerald-500 text-slate-950'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Match Lobbies & Voice Chat
          </button>
          <button
            onClick={() => setTab('leaderboard')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold ${
              tab === 'leaderboard'
                ? 'bg-emerald-500 text-slate-950'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            Global Leaderboards
          </button>
          <button
            onClick={() => setTab('cloud')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold ${
              tab === 'cloud'
                ? 'bg-emerald-500 text-slate-950'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Cloud className="w-3.5 h-3.5" />
            Cross-Platform Cloud Save
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {tab === 'multiplayer' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
              {/* Left: Lobbies & Voice Controls */}
              <div className="space-y-4">
                {activeRoom ? (
                  <div className="rounded-xl border border-emerald-500/30 bg-[#111927] p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-emerald-400 font-semibold">
                          Active Match Room · {activeRoom.id}
                        </p>
                        <h3 className="font-display text-xl font-bold text-white">
                          {activeRoom.name}
                        </h3>
                      </div>
                      <button
                        onClick={onLeaveRoom}
                        className="px-3 py-1.5 rounded-lg bg-rose-500/20 text-rose-300 text-xs font-semibold hover:bg-rose-500/30"
                      >
                        Leave Room
                      </button>
                    </div>

                    <div className="space-y-2">
                      <p className="text-xs text-slate-400">Connected Players</p>
                      {activeRoom.peers.map((peer) => (
                        <div
                          key={peer.id}
                          className="flex items-center justify-between rounded-lg bg-[#0B111B] px-3 py-2 text-xs"
                        >
                          <span className="text-white font-medium">
                            {peer.name} · {peer.clubName}
                          </span>
                          <span className="text-slate-400">
                            {peer.platform} · {peer.role.toUpperCase()}
                            {peer.voiceEnabled ? ' · Mic On' : ''}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* WebRTC Voice Chat Toggle */}
                    <div className="border-t border-white/10 pt-3 flex items-center justify-between">
                      <div>
                        <p className="text-xs font-semibold text-white">
                          Room Voice Comms (WebRTC)
                        </p>
                        <p className="text-[11px] text-slate-400">
                          {voiceError
                            ? voiceError
                            : voiceActive
                              ? 'Microphone live — broadcasting to room peers'
                              : 'Enable microphone to speak with squadmates'}
                        </p>
                      </div>
                      <button
                        onClick={onToggleVoice}
                        className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
                          voiceActive
                            ? 'bg-emerald-500 text-slate-950'
                            : 'bg-white/10 text-white hover:bg-white/15'
                        }`}
                      >
                        {voiceActive ? (
                          <>
                            <Mic className="w-4 h-4" /> Mic Active
                          </>
                        ) : (
                          <>
                            <MicOff className="w-4 h-4" /> Enable Mic
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-4">
                    <h3 className="font-display text-lg font-bold text-white">
                      Host Cross-Platform Match
                    </h3>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={roomName}
                        onChange={(e) => setRoomName(e.target.value)}
                        className="flex-1 rounded-lg border border-white/10 bg-[#0B111B] px-3 py-2 text-xs text-white"
                      />
                      <button
                        onClick={() => onCreateRoom(roomName)}
                        className="px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400"
                      >
                        Create Lobby
                      </button>
                    </div>

                    <div className="space-y-2 pt-2">
                      <p className="text-xs font-medium text-slate-400">
                        Live Multiplayer Rooms ({rooms.length})
                      </p>
                      {rooms.length === 0 ? (
                        <p className="text-xs text-slate-500 py-3">
                          No open lobbies right now — host a room above or open a second tab to test real-time cross-client play & voice sync.
                        </p>
                      ) : (
                        rooms.map((r) => (
                          <div
                            key={r.id}
                            className="flex items-center justify-between rounded-lg border border-white/10 bg-[#0B111B] px-3 py-2.5 text-xs"
                          >
                            <div>
                              <p className="text-white font-semibold">{r.name}</p>
                              <p className="text-slate-400">
                                {r.peers.length} connected · {r.status}
                              </p>
                            </div>
                            <button
                              onClick={() => onJoinRoom(r.id)}
                              className="px-3 py-1.5 rounded bg-sky-500 text-slate-950 font-bold"
                            >
                              Join
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Right: Integrated Text & Voice Chat */}
              <div className="rounded-xl border border-white/10 bg-[#111927] p-5 flex flex-col h-[430px]">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setChatChannel('global')}
                      className={`px-3 py-1 rounded text-xs font-semibold ${
                        chatChannel === 'global'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-[#0B111B] text-slate-300'
                      }`}
                    >
                      Global Lounge
                    </button>
                    <button
                      disabled={!activeRoom}
                      onClick={() => setChatChannel('room')}
                      className={`px-3 py-1 rounded text-xs font-semibold disabled:opacity-40 ${
                        chatChannel === 'room'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-[#0B111B] text-slate-300'
                      }`}
                    >
                      Match Room Chat
                    </button>
                  </div>
                  <Globe className="w-4 h-4 text-slate-400" />
                </div>

                <div className="flex-1 overflow-y-auto space-y-2 pr-1 mb-3">
                  {visibleMessages.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      No messages yet. Say hello to managers across PC, Console, and Mobile.
                    </p>
                  ) : (
                    visibleMessages.map((msg) => (
                      <div
                        key={msg.id}
                        className="rounded-lg bg-[#0B111B] px-3 py-2 text-xs border border-white/5"
                      >
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-0.5">
                          <span className="font-semibold text-emerald-400">
                            {msg.senderName} · {msg.clubName}
                          </span>
                          <span>{msg.platform}</span>
                        </div>
                        <p className="text-slate-100">{msg.text}</p>
                      </div>
                    ))
                  )}
                </div>

                <form onSubmit={handleChatSubmit} className="flex gap-2">
                  <input
                    type="text"
                    value={chatText}
                    onChange={(e) => setChatText(e.target.value)}
                    placeholder="Message players..."
                    className="flex-1 rounded-lg border border-white/10 bg-[#0B111B] px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold"
                    aria-label="Send Chat Message"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>
          )}

          {tab === 'leaderboard' && (
            <div className="rounded-xl border border-white/10 bg-[#111927] overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#0B111B] text-slate-400 border-b border-white/10">
                  <tr>
                    <th className="px-4 py-3">Rank</th>
                    <th className="px-3 py-3">Manager</th>
                    <th className="px-3 py-3">Club</th>
                    <th className="px-3 py-3">Platform</th>
                    <th className="px-3 py-3">ELO</th>
                    <th className="px-3 py-3">W-D-L</th>
                    <th className="px-3 py-3">Goals</th>
                    <th className="px-3 py-3">Trophies</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {leaderboard.map((row, idx) => (
                    <tr key={row.id} className="hover:bg-white/[0.03]">
                      <td className="px-4 py-3 font-mono-tabular font-bold text-emerald-400">
                        #{idx + 1}
                      </td>
                      <td className="px-3 py-3 font-semibold text-white">{row.managerName}</td>
                      <td className="px-3 py-3 text-slate-200">
                        <span
                          className="inline-block w-2.5 h-2.5 rounded-sm mr-2"
                          style={{ backgroundColor: row.clubColor }}
                        />
                        {row.clubName}
                      </td>
                      <td className="px-3 py-3 text-slate-400">{row.platform}</td>
                      <td className="px-3 py-3 font-mono-tabular font-bold text-white">
                        {row.eloRating}
                      </td>
                      <td className="px-3 py-3 font-mono-tabular text-slate-300">
                        {row.wins}-{row.draws}-{row.losses}
                      </td>
                      <td className="px-3 py-3 font-mono-tabular text-slate-300">
                        {row.goalsScored}
                      </td>
                      <td className="px-3 py-3 font-mono-tabular text-amber-300">
                        {row.trophiesWon}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {tab === 'cloud' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-display text-xl font-bold text-white">
                      Cross-Platform Cloud Account
                    </h3>
                    <p className="text-xs text-slate-400">
                      Sync your Created Player, Tactics, Finances & Season Progress across PC, Console, and Mobile.
                    </p>
                  </div>
                  {firebaseUser ? (
                    <button
                      onClick={onSignOut}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/15 text-xs text-slate-300 hover:text-white"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Sign Out
                    </button>
                  ) : (
                    <button
                      onClick={onSignInGoogle}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400"
                    >
                      <LogIn className="w-3.5 h-3.5" /> Sign in with Google
                    </button>
                  )}
                </div>

                {firebaseUser && (
                  <div className="space-y-3 border-t border-white/10 pt-4">
                    <p className="text-xs text-slate-300">
                      Signed in as <span className="font-semibold text-white">{firebaseUser.displayName || firebaseUser.email}</span>
                    </p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={slotName}
                        onChange={(e) => setSlotName(e.target.value)}
                        className="flex-1 rounded-lg border border-white/10 bg-[#0B111B] px-3 py-2 text-xs text-white"
                      />
                      <button
                        onClick={() => onSaveCloud(slotName)}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400"
                      >
                        <Upload className="w-3.5 h-3.5" /> Sync Save to Cloud
                      </button>
                    </div>
                  </div>
                )}

                {cloudStatus && (
                  <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-200">
                    {cloudStatus}
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-3">
                <h4 className="font-display text-lg font-bold text-white">
                  Synced Cloud Save Slots
                </h4>
                {!firebaseUser ? (
                  <p className="text-xs text-slate-400">
                    Sign in with Google to access your encrypted cross-platform Firestore cloud saves.
                  </p>
                ) : cloudSaves.length === 0 ? (
                  <p className="text-xs text-slate-400">
                    No cloud saves found yet. Click &ldquo;Sync Save to Cloud&rdquo; to upload your current career.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {cloudSaves.map((save) => (
                      <div
                        key={save.saveId}
                        className="flex items-center justify-between rounded-lg border border-white/10 bg-[#0B111B] p-3 text-xs"
                      >
                        <div>
                          <p className="font-semibold text-white">{save.slotName}</p>
                          <p className="text-slate-400">
                            {save.clubId.toUpperCase()} · S{save.seasonNumber} W{save.currentWeek} ·{' '}
                            {save.platform} · Star {save.createdPlayer?.name}
                          </p>
                        </div>
                        <button
                          onClick={() => onLoadCloud(save)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-sky-500 text-slate-950 font-bold"
                        >
                          <Download className="w-3.5 h-3.5" /> Load
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
