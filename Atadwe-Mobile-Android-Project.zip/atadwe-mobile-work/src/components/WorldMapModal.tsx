import React, { useState } from 'react';
import { MapPin, X, Play, Dumbbell } from 'lucide-react';
import { Club, StadiumTheme } from '../types/game';
import { LEAGUES, getClubAvgOvr } from '../data/leagues';

interface WorldMapModalProps {
  clubs: Record<string, Club>;
  activeClubId: string;
  onSelectClubStadium: (clubId: string, theme: StadiumTheme) => void;
  onEnterTrainingComplex: (clubId: string) => void;
  onClose: () => void;
}

export const WorldMapModal: React.FC<WorldMapModalProps> = ({
  clubs,
  activeClubId,
  onSelectClubStadium,
  onEnterTrainingComplex,
  onClose,
}) => {
  const [selectedId, setSelectedId] = useState(activeClubId);
  const [filterLeague, setFilterLeague] = useState<string>('all');
  const [mapTab, setMapTab] = useState<'world' | 'campus'>('world');

  const selectedClub = clubs[selectedId] || clubs[activeClubId];
  const visibleClubs = Object.values(clubs).filter(
    (c) => filterLeague === 'all' || c.leagueId === filterLeague
  );

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-xl border border-white/10 bg-[#0B111B] p-6 shadow-2xl space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-wide text-white">
              Global Stadium & Facility Maps
            </h2>
            <p className="text-xs text-slate-400">
              5 Licensed Leagues · 30 Authentic Stadiums · Club Training Grounds & Gyms
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMapTab('world')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                mapTab === 'world'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-[#111927] text-slate-300 hover:text-white'
              }`}
            >
              Europe League Map
            </button>
            <button
              onClick={() => setMapTab('campus')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                mapTab === 'campus'
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-[#111927] text-slate-300 hover:text-white'
              }`}
            >
              Club Training & Gym Blueprint
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
              aria-label="Close Maps"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {mapTab === 'world' ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className="lg:col-span-2 space-y-3">
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setFilterLeague('all')}
                  className={`px-2.5 py-1 rounded text-xs font-medium ${
                    filterLeague === 'all'
                      ? 'bg-white text-slate-950'
                      : 'bg-[#111927] text-slate-300'
                  }`}
                >
                  All 5 Leagues
                </button>
                {LEAGUES.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => setFilterLeague(l.id)}
                    className={`px-2.5 py-1 rounded text-xs font-medium ${
                      filterLeague === l.id
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-[#111927] text-slate-300'
                    }`}
                  >
                    {l.name}
                  </button>
                ))}
              </div>

              {/* Interactive SVG Europe Football Stadium Map */}
              <div className="relative rounded-xl border border-white/10 bg-[#070E1A] overflow-hidden aspect-[16/10]">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <defs>
                    <pattern id="mapgrid" width="10" height="10" patternUnits="userSpaceOnUse">
                      <path
                        d="M 10 0 L 0 0 0 10"
                        fill="none"
                        stroke="rgba(148,163,184,0.08)"
                        strokeWidth="0.3"
                      />
                    </pattern>
                  </defs>
                  <rect width="100" height="100" fill="url(#mapgrid)" />

                  {/* Stylized Regional Landmass Silhouettes */}
                  {/* UK */}
                  <path
                    d="M 18 14 L 30 14 L 32 34 L 19 36 Z"
                    fill="#111C2D"
                    stroke="#1E293B"
                    strokeWidth="0.5"
                  />
                  {/* Spain / Iberia */}
                  <path
                    d="M 14 58 L 33 58 L 32 82 L 13 80 Z"
                    fill="#111C2D"
                    stroke="#1E293B"
                    strokeWidth="0.5"
                  />
                  {/* France */}
                  <path
                    d="M 32 35 L 48 34 L 49 63 L 32 60 Z"
                    fill="#111C2D"
                    stroke="#1E293B"
                    strokeWidth="0.5"
                  />
                  {/* Germany */}
                  <path
                    d="M 48 22 L 66 22 L 65 48 L 48 46 Z"
                    fill="#111C2D"
                    stroke="#1E293B"
                    strokeWidth="0.5"
                  />
                  {/* Italy */}
                  <path
                    d="M 48 53 L 62 53 L 69 80 L 58 82 L 50 62 Z"
                    fill="#111C2D"
                    stroke="#1E293B"
                    strokeWidth="0.5"
                  />

                  {/* Country Labels */}
                  <text x="20" y="12" fontSize="2.8" fill="#64748B" fontWeight="600">ENGLAND</text>
                  <text x="36" y="32" fontSize="2.8" fill="#64748B" fontWeight="600">FRANCE</text>
                  <text x="53" y="20" fontSize="2.8" fill="#64748B" fontWeight="600">GERMANY</text>
                  <text x="15" y="56" fontSize="2.8" fill="#64748B" fontWeight="600">SPAIN</text>
                  <text x="54" y="51" fontSize="2.8" fill="#64748B" fontWeight="600">ITALY</text>

                  {/* Travel Line from Home Club to Selected Club */}
                  {clubs[activeClubId] && selectedClub && activeClubId !== selectedClub.id && (
                    <line
                      x1={clubs[activeClubId].mapX}
                      y1={clubs[activeClubId].mapY}
                      x2={selectedClub.mapX}
                      y2={selectedClub.mapY}
                      stroke="#10B981"
                      strokeWidth="0.5"
                      strokeDasharray="1.5 1"
                    />
                  )}

                  {/* Stadium Pins */}
                  {visibleClubs.map((club) => {
                    const isSel = club.id === selectedClub?.id;
                    const isHome = club.id === activeClubId;
                    return (
                      <g
                        key={club.id}
                        className="cursor-pointer"
                        onClick={() => setSelectedId(club.id)}
                      >
                        <circle
                          cx={club.mapX}
                          cy={club.mapY}
                          r={isSel ? 2.4 : 1.5}
                          fill={club.homeKit.primary}
                          stroke={isSel || isHome ? '#10B981' : '#FFFFFF'}
                          strokeWidth={isSel ? 0.7 : 0.35}
                        />
                        {isSel && (
                          <text
                            x={club.mapX}
                            y={club.mapY - 3.2}
                            textAnchor="middle"
                            fontSize="2.8"
                            fill="#F8FAFC"
                            fontWeight="700"
                          >
                            {club.shortName}
                          </text>
                        )}
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>

            {selectedClub && (
              <div className="rounded-xl border border-white/10 bg-[#111927] p-5 flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg border border-white/20 flex items-center justify-center font-display font-bold text-sm text-white"
                      style={{ backgroundColor: selectedClub.homeKit.primary }}
                    >
                      {selectedClub.shortName}
                    </div>
                    <div>
                      <h3 className="font-display text-xl font-bold text-white">
                        {selectedClub.name}
                      </h3>
                      <p className="text-xs text-slate-400">
                        {selectedClub.city}, {selectedClub.country} · OVR {getClubAvgOvr(selectedClub)}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2 border-t border-white/10 pt-3 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Home Stadium</span>
                      <span className="text-white font-medium">{selectedClub.stadiumName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Capacity</span>
                      <span className="font-mono-tabular text-white">
                        {selectedClub.stadiumCapacity.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Training Gym</span>
                      <span className="text-emerald-300 font-medium">{selectedClub.gymName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Kit Colors</span>
                      <span className="flex items-center gap-1.5">
                        <span
                          className="w-3.5 h-3.5 rounded-sm border border-white/20"
                          style={{ backgroundColor: selectedClub.homeKit.primary }}
                          title="Home Primary"
                        />
                        <span
                          className="w-3.5 h-3.5 rounded-sm border border-white/20"
                          style={{ backgroundColor: selectedClub.trainingKit.primary }}
                          title="Training Kit"
                        />
                        <span
                          className="w-3.5 h-3.5 rounded-sm border border-white/20"
                          style={{ backgroundColor: selectedClub.trainingKit.secondary }}
                          title="Training Accent"
                        />
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 pt-3 border-t border-white/10">
                  <button
                    onClick={() => onSelectClubStadium(selectedClub.id, 'night_floodlights')}
                    className="w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Play Match at {selectedClub.stadiumName}
                  </button>
                  <button
                    onClick={() => onEnterTrainingComplex(selectedClub.id)}
                    className="w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-lg border border-white/15 bg-white/5 text-white font-semibold text-xs hover:bg-white/10 transition-colors"
                  >
                    <Dumbbell className="w-3.5 h-3.5 text-sky-400" />
                    Visit {selectedClub.shortName} Gym & Training Pitch
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Club Campus & Training Ground Blueprint */
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="md:col-span-2 rounded-xl border border-white/10 bg-[#070E1A] p-4">
              <svg viewBox="0 0 120 75" className="w-full h-auto">
                <rect x="0" y="0" width="120" height="75" fill="#0B1912" rx="3" />
                {/* Club Gym Pavilion */}
                <rect
                  x="6"
                  y="14"
                  width="24"
                  height="42"
                  fill="#1E293B"
                  stroke={selectedClub.trainingKit.secondary}
                  strokeWidth="0.8"
                  rx="1.5"
                />
                <text x="18" y="21" textAnchor="middle" fontSize="3.2" fill="#F8FAFC" fontWeight="700">
                  CLUB GYM
                </text>
                <rect x="9" y="25" width="7" height="5" fill="#334155" />
                <rect x="9" y="33" width="7" height="5" fill="#334155" />
                <rect x="9" y="41" width="7" height="5" fill="#334155" />
                <rect x="20" y="25" width="6" height="24" fill={selectedClub.trainingKit.secondary} opacity="0.55" />
                <text x="18" y="53" textAnchor="middle" fontSize="2.2" fill="#94A3B8">
                  Squat Racks · Track
                </text>

                {/* Main Training Pitch */}
                <rect
                  x="38"
                  y="8"
                  width="74"
                  height="58"
                  fill="#176B30"
                  stroke="#F8FAFC"
                  strokeWidth="0.6"
                />
                <line x1="75" y1="8" x2="75" y2="66" stroke="#F8FAFC" strokeWidth="0.5" />
                <circle cx="75" cy="37" r="8" fill="none" stroke="#F8FAFC" strokeWidth="0.5" />
                <rect x="38" y="22" width="12" height="30" fill="none" stroke="#F8FAFC" strokeWidth="0.5" />
                <rect x="100" y="22" width="12" height="30" fill="none" stroke="#F8FAFC" strokeWidth="0.5" />

                {/* Agility Cones */}
                {[0, 1, 2, 3, 4].map((i) => (
                  <circle key={i} cx={48 + i * 5} cy={16 + (i % 2) * 4} r="1.1" fill="#F97316" />
                ))}
                <text x="58" y="13" fontSize="2.4" fill="#FDBA74">
                  Agility Slalom
                </text>
                <text x="75" y="61" textAnchor="middle" fontSize="2.8" fill="#DCFCE7" fontWeight="600">
                  FULL FREE-ROAM TRAINING PITCH
                </text>
              </svg>
            </div>
            <div className="rounded-xl border border-white/10 bg-[#111927] p-5 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-semibold">
                  <MapPin className="w-4 h-4" />
                  {selectedClub.gymName}
                </div>
                <h3 className="font-display text-xl font-bold text-white">
                  Walkable Pitch & Gym Complex
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Control your Created Star Player directly across the full training pitch, weave through agility cones, strike curved shots at goal, and walk directly inside the Club Gym Pavilion for stamina recovery.
                </p>
              </div>
              <button
                onClick={() => onEnterTrainingComplex(selectedClub.id)}
                className="w-full py-2.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors"
              >
                Launch 3D Training & Gym Map
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
