import React from 'react';
import {
  ArrowRight,
  Check,
  ChevronDown,
  ChevronUp,
  Sparkles,
  X,
} from 'lucide-react';
import { LiveTacticalSuggestion } from '../state/managerEngine';
import { TacticalSetup } from '../types/game';

interface Props {
  suggestion: LiveTacticalSuggestion;
  currentTactics: TacticalSetup;
  minimized: boolean;
  onToggleMinimize: () => void;
  onApply: (tactics: TacticalSetup) => void;
  onDismiss: () => void;
}

export const LiveTacticalAIOverlay: React.FC<Props> = ({
  suggestion,
  currentTactics,
  minimized,
  onToggleMinimize,
  onApply,
  onDismiss,
}) => {
  const {
    urgency,
    situationLabel,
    headline,
    reason,
    recommendedTactics,
    formationChanged,
    isAlreadyApplied,
  } = suggestion;

  const borderTone =
    urgency === 'critical'
      ? 'border-amber-400/50'
      : urgency === 'shift'
        ? 'border-emerald-400/45'
        : 'border-white/15';

  const accentText =
    urgency === 'critical'
      ? 'text-amber-300'
      : urgency === 'shift'
        ? 'text-emerald-400'
        : 'text-slate-300';

  if (minimized) {
    return (
      <div className="pointer-events-auto inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#0B111B]/95 px-2.5 py-1.5 shadow-lg">
        <button
          type="button"
          onClick={onToggleMinimize}
          className="inline-flex items-center gap-2 text-left text-xs font-semibold text-slate-100 hover:text-white transition-colors"
          title="Expand Real-Time Tactical AI"
        >
          <Sparkles className={`w-3.5 h-3.5 shrink-0 ${accentText}`} />
          <span className="font-mono-tabular text-[11px] uppercase tracking-wider text-slate-400">
            AI
          </span>
          <span className="font-mono-tabular font-bold text-white">
            {isAlreadyApplied
              ? `${currentTactics.formation} In Sync`
              : formationChanged
                ? `${currentTactics.formation} → ${recommendedTactics.formation}`
                : `${recommendedTactics.mentality}`}
          </span>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
        </button>

        {!isAlreadyApplied && (
          <button
            type="button"
            onClick={() => onApply(recommendedTactics)}
            className="ml-1 px-2 py-0.5 rounded bg-emerald-500 text-slate-950 font-mono-tabular text-[11px] font-bold hover:bg-emerald-400 transition-colors"
          >
            Apply
          </button>
        )}
      </div>
    );
  }

  return (
    <div
      className={`pointer-events-auto w-[284px] sm:w-[320px] rounded-xl border ${borderTone} bg-[#0B111B]/95 p-3 shadow-2xl space-y-2.5`}
    >
      {/* Top Meta Row */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <Sparkles className={`w-3.5 h-3.5 shrink-0 ${accentText}`} />
          <span className="text-[11px] font-bold tracking-[0.14em] uppercase text-slate-300">
            Tactical AI
          </span>
          <span className="text-slate-600">·</span>
          <span className={`font-mono-tabular text-[11px] font-bold truncate ${accentText}`}>
            {situationLabel}
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={onToggleMinimize}
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            aria-label="Collapse Tactical AI"
            title="Collapse"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onDismiss}
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            aria-label="Dismiss Tactical AI Suggestion"
            title="Dismiss until score or phase changes"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Formation Shift & Tactical Headline */}
      <div className="space-y-1">
        <div className="flex items-center justify-between gap-2">
          <p className="text-xs font-bold text-white leading-snug">{headline}</p>
          <div className="flex items-center gap-1 font-mono-tabular text-xs font-extrabold shrink-0">
            {formationChanged ? (
              <>
                <span className="text-slate-400">{currentTactics.formation}</span>
                <ArrowRight className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">{recommendedTactics.formation}</span>
              </>
            ) : (
              <span className="text-emerald-400">{recommendedTactics.formation}</span>
            )}
          </div>
        </div>

        <p className="text-[11px] leading-relaxed text-slate-300">{reason}</p>
      </div>

      {/* Key Tactical Adjustments */}
      <div className="grid grid-cols-3 gap-1.5 rounded-lg bg-[#111927] border border-white/10 px-2.5 py-1.5 text-[10px]">
        <div className="min-w-0">
          <span className="block text-slate-400 uppercase tracking-wider">Shape</span>
          <span className="font-mono-tabular font-bold text-white truncate block">
            {recommendedTactics.formation}
          </span>
        </div>
        <div className="min-w-0">
          <span className="block text-slate-400 uppercase tracking-wider">Mentality</span>
          <span className="font-semibold text-slate-100 truncate block">
            {recommendedTactics.mentality}
          </span>
        </div>
        <div className="min-w-0">
          <span className="block text-slate-400 uppercase tracking-wider">Press / Line</span>
          <span className="font-semibold text-slate-100 truncate block">
            {recommendedTactics.pressing} · {recommendedTactics.defensiveLine}
          </span>
        </div>
      </div>

      {/* Action Footer */}
      {isAlreadyApplied ? (
        <div className="flex items-center justify-between text-[11px] text-emerald-400 font-semibold pt-0.5">
          <span className="inline-flex items-center gap-1.5">
            <Check className="w-3.5 h-3.5" />
            Active on pitch ({currentTactics.formation})
          </span>
          <button
            type="button"
            onClick={onToggleMinimize}
            className="text-slate-400 hover:text-white font-medium"
          >
            Minimize
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onApply(recommendedTactics)}
            className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            <span>
              {formationChanged
                ? `Switch to ${recommendedTactics.formation}`
                : `Apply ${recommendedTactics.mentality}`}
            </span>
          </button>
          <button
            type="button"
            onClick={onDismiss}
            className="px-2.5 py-1.5 rounded-lg border border-white/10 bg-[#111927] hover:bg-white/10 text-slate-300 text-xs font-semibold transition-colors"
          >
            Ignore
          </button>
        </div>
      )}
    </div>
  );
};
