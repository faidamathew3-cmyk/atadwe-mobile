import React, { useState } from 'react';
import { Brain, Shield, X } from 'lucide-react';
import {
  AICoachAnalysis,
  Club,
  FormationId,
  ManagerState,
  Mentality,
  PassingStyle,
  PressingIntensity,
} from '../types/game';
import { getClubAvgOvr } from '../data/leagues';

interface LiveTacticsDrawerProps {
  club: Club;
  opponent: Club;
  manager: ManagerState;
  matchMinute: number;
  homeScore: number;
  awayScore: number;
  onUpdateTactics: (tactics: ManagerState['tactics']) => void;
  onSwapPlayers: (starterId: string, benchId: string) => void;
  onClose: () => void;
}

const FORMATIONS: FormationId[] = ['4-3-3', '4-4-2', '4-2-3-1', '3-5-2', '5-3-2'];
const MENTALITIES: Mentality[] = [
  'Ultra Defensive',
  'Defensive',
  'Balanced',
  'Attacking',
  'All-Out Attack',
];
const PRESSING: PressingIntensity[] = ['Low Block', 'Mid Press', 'Gegenpress'];
const PASSING: PassingStyle[] = ['Direct', 'Balanced', 'Tiki-Taka'];

export const LiveTacticsDrawer: React.FC<LiveTacticsDrawerProps> = ({
  club,
  opponent,
  manager,
  matchMinute,
  homeScore,
  awayScore,
  onUpdateTactics,
  onSwapPlayers,
  onClose,
}) => {
  const [starterPick, setStarterPick] = useState<string | null>(null);
  const [aiTip, setAiTip] = useState<AICoachAnalysis | null>(null);
  const [loadingTip, setLoadingTip] = useState(false);
  const [tipError, setTipError] = useState<string | null>(null);

  const starters = manager.startingXIIds
    .map((id) => club.roster.find((p) => p.id === id))
    .filter(Boolean) as Club['roster'];
  const bench = manager.benchIds
    .map((id) => club.roster.find((p) => p.id === id))
    .filter(Boolean) as Club['roster'];

  const requestLiveAdvice = async () => {
    setLoadingTip(true);
    setTipError(null);
    try {
      const res = await fetch('/api/coach/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clubName: club.name,
          formation: manager.tactics.formation,
          mentality: manager.tactics.mentality,
          pressing: manager.tactics.pressing,
          passingStyle: manager.tactics.passingStyle,
          teamOvr: getClubAvgOvr(club),
          opponentName: opponent.name,
          opponentOvr: getClubAvgOvr(opponent),
          matchMinute,
          scoreHome: homeScore,
          scoreAway: awayScore,
          isLiveMatch: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Unable to reach AI Coach.');
      setAiTip(data.analysis);
    } catch (err) {
      setTipError(err instanceof Error ? err.message : 'Unable to reach AI Coach.');
    } finally {
      setLoadingTip(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-4">
      <div className="w-full max-w-4xl max-h-[88vh] overflow-y-auto rounded-xl border border-white/10 bg-[#0B111B] p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-display text-xl font-bold text-white">
                Touchline Tactical Adjustments ({matchMinute}&apos;)
              </h3>
              <p className="text-xs text-slate-400">
                {club.shortName} {homeScore} - {awayScore} {opponent.shortName} · Changes apply immediately on the 3D pitch
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
            aria-label="Resume Match"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                Live Formation
              </label>
              <div className="grid grid-cols-5 gap-1.5">
                {FORMATIONS.map((f) => (
                  <button
                    key={f}
                    onClick={() => onUpdateTactics({ ...manager.tactics, formation: f })}
                    className={`py-2 rounded-lg font-mono-tabular text-xs font-bold border ${
                      manager.tactics.formation === f
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                        : 'bg-[#111927] text-slate-300 border-white/10'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">
                Mentality
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {MENTALITIES.map((m) => (
                  <button
                    key={m}
                    onClick={() => onUpdateTactics({ ...manager.tactics, mentality: m })}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold border text-left ${
                      manager.tactics.mentality === m
                        ? 'bg-sky-500 text-slate-950 border-sky-400'
                        : 'bg-[#111927] text-slate-300 border-white/10'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">
                  Pressing
                </label>
                <select
                  value={manager.tactics.pressing}
                  onChange={(e) =>
                    onUpdateTactics({
                      ...manager.tactics,
                      pressing: e.target.value as PressingIntensity,
                    })
                  }
                  className="w-full rounded-lg border border-white/10 bg-[#111927] px-3 py-2 text-xs text-white"
                >
                  {PRESSING.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">
                  Passing Tempo
                </label>
                <select
                  value={manager.tactics.passingStyle}
                  onChange={(e) =>
                    onUpdateTactics({
                      ...manager.tactics,
                      passingStyle: e.target.value as PassingStyle,
                    })
                  }
                  className="w-full rounded-lg border border-white/10 bg-[#111927] px-3 py-2 text-xs text-white"
                >
                  {PASSING.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Live AI Touchline Advice */}
            <div className="rounded-xl border border-white/10 bg-[#111927] p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <Brain className="w-4 h-4" /> AI Assistant Coach
                </span>
                <button
                  disabled={loadingTip}
                  onClick={requestLiveAdvice}
                  className="px-3 py-1 rounded bg-emerald-500 text-slate-950 font-bold text-[11px]"
                >
                  {loadingTip ? 'Analyzing...' : 'Live Advice'}
                </button>
              </div>
              {tipError && <p className="text-xs text-rose-400">{tipError}</p>}
              {aiTip && (
                <div className="space-y-2 text-xs">
                  <p className="font-semibold text-white">{aiTip.headline}</p>
                  <p className="text-slate-300">{aiTip.tacticalSummary}</p>
                  <button
                    onClick={() =>
                      onUpdateTactics({
                        ...manager.tactics,
                        formation: aiTip.recommendedFormation,
                        mentality: aiTip.recommendedMentality,
                        pressing: aiTip.recommendedPressing,
                        passingStyle: aiTip.recommendedPassing,
                      })
                    }
                    className="w-full py-1.5 rounded bg-sky-500 text-slate-950 font-bold"
                  >
                    Apply {aiTip.recommendedFormation} · {aiTip.recommendedMentality}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Substitutions */}
          <div className="rounded-xl border border-white/10 bg-[#111927] p-4 space-y-3">
            <p className="text-xs font-semibold text-white">
              Substitutions {starterPick ? '(Select a bench player)' : '(Select a starter to sub off)'}
            </p>
            <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
              <div className="space-y-1">
                <p className="text-[11px] text-slate-400">On Pitch</p>
                {starters.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setStarterPick(starterPick === p.id ? null : p.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-[11px] border ${
                      starterPick === p.id
                        ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                        : p.injury
                          ? 'bg-rose-500/10 border-rose-500/40 text-rose-200'
                          : 'bg-[#0B111B] border-white/10 text-slate-200'
                    }`}
                  >
                    <span className="truncate">
                      {p.name.split(' ').slice(-1)[0]}
                      {p.injury ? ' (INJ)' : ''}
                    </span>
                    <span className="font-mono-tabular">{p.ovr}</span>
                  </button>
                ))}
              </div>
              <div className="space-y-1">
                <p className="text-[11px] text-slate-400">Bench</p>
                {bench.map((p) => {
                  const isInjured = Boolean(p.injury);
                  return (
                    <button
                      key={p.id}
                      disabled={!starterPick || isInjured}
                      onClick={() => {
                        if (starterPick && !isInjured) {
                          onSwapPlayers(starterPick, p.id);
                          setStarterPick(null);
                        }
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-[11px] border ${
                        isInjured
                          ? 'border-rose-500/30 bg-rose-500/10 text-rose-300 opacity-70 cursor-not-allowed'
                          : 'border-white/10 bg-[#0B111B] text-slate-200 hover:border-emerald-400 disabled:opacity-50'
                      }`}
                    >
                      <span className="truncate">
                        {p.name.split(' ').slice(-1)[0]}
                        {p.injury ? ` · INJ ${p.injury.weeksRemaining}w` : ''}
                      </span>
                      <span className="font-mono-tabular text-emerald-400">{p.ovr}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end border-t border-white/10 pt-3">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400"
          >
            Resume 3D Match
          </button>
        </div>
      </div>
    </div>
  );
};
