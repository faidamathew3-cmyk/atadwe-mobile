import React, { useMemo, useState } from 'react';
import {
  Check,
  Dumbbell,
  Eye,
  Minus,
  Plus,
  RotateCcw,
  Shuffle,
  User,
  X,
} from 'lucide-react';
import {
  Club,
  CreatedPlayerProfile,
  PlayerTraitId,
  PlaystyleId,
  Position,
} from '../types/game';
import {
  ATTRIBUTE_META,
  AttributeKey,
  BASE_STAT_MIN,
  BODY_TYPES,
  BOOT_COLORS,
  FACE_STYLES,
  HAIR_COLORS,
  HAIR_STYLES,
  MAX_TRAITS,
  PLAYER_TRAITS,
  PLAYSTYLES,
  POSITIONS,
  PREFERRED_FEET,
  SKILL_POINT_POOL,
  SKIN_TONES,
  STAT_MAX,
  computePositionOvr,
  createRolePresetStats,
  getSkillPointsUsed,
} from '../data/playerCustomization';
import { PlayerPreview3D } from './PlayerPreview3D';

interface CreatePlayerModalProps {
  profile: CreatedPlayerProfile;
  club: Club;
  onChange: (next: CreatedPlayerProfile) => void;
  onEnterTrainingGym: () => void;
  onSaveToSquad: () => void;
  onClose: () => void;
}

type CustomizerTab = 'identity' | 'appearance' | 'skills' | 'traits';

const QUICK_NATIONS = ['ENG', 'FRA', 'ESP', 'BRA', 'ARG', 'GER', 'ITA', 'POR', 'NGA', 'JPN'];

const AttributeRadar: React.FC<{ profile: CreatedPlayerProfile }> = ({ profile }) => {
  const values = ATTRIBUTE_META.map((a) => profile[a.key]);
  const cx = 92;
  const cy = 92;
  const maxR = 64;

  const polygonPoints = (scaleFactor: number, customVals?: number[]) =>
    ATTRIBUTE_META.map((_, idx) => {
      const angle = (idx / 6) * Math.PI * 2 - Math.PI / 2;
      const valRatio = customVals ? (customVals[idx] - 40) / 55 : scaleFactor;
      const r = Math.max(0.12, Math.min(1, valRatio)) * maxR;
      const x = cx + Math.cos(angle) * r;
      const y = cy + Math.sin(angle) * r;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');

  return (
    <svg
      width="184"
      height="184"
      viewBox="0 0 184 184"
      className="mx-auto shrink-0"
      aria-label="Attribute shape radar"
    >
      {[0.35, 0.65, 1.0].map((ring) => (
        <polygon
          key={ring}
          points={polygonPoints(ring)}
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="1"
        />
      ))}
      {ATTRIBUTE_META.map((meta, idx) => {
        const angle = (idx / 6) * Math.PI * 2 - Math.PI / 2;
        const x2 = cx + Math.cos(angle) * maxR;
        const y2 = cy + Math.sin(angle) * maxR;
        const lx = cx + Math.cos(angle) * (maxR + 17);
        const ly = cy + Math.sin(angle) * (maxR + 15);
        return (
          <g key={meta.key}>
            <line
              x1={cx}
              y1={cy}
              x2={x2}
              y2={y2}
              stroke="rgba(255,255,255,0.1)"
              strokeWidth="1"
            />
            <text
              x={lx}
              y={ly}
              textAnchor="middle"
              dominantBaseline="middle"
              fill={meta.keyFor.includes(profile.position) ? '#34D399' : '#94A3B8'}
              fontSize="10"
              fontWeight="700"
            >
              {meta.short}
            </text>
          </g>
        );
      })}
      <polygon
        points={polygonPoints(1, values)}
        fill="rgba(16, 185, 129, 0.25)"
        stroke="#10B981"
        strokeWidth="2"
      />
    </svg>
  );
};

export const CreatePlayerModal: React.FC<CreatePlayerModalProps> = ({
  profile,
  club,
  onChange,
  onEnterTrainingGym,
  onSaveToSquad,
  onClose,
}) => {
  const [tab, setTab] = useState<CustomizerTab>('identity');
  const [kitVariant, setKitVariant] = useState<'home' | 'away' | 'training'>('home');
  const [cameraFocus, setCameraFocus] = useState<'full' | 'head'>('full');

  const pointsUsed = useMemo(() => getSkillPointsUsed(profile), [profile]);
  const pointsRemaining = Math.max(0, SKILL_POINT_POOL - pointsUsed);

  const secondaryOvr = useMemo(
    () =>
      profile.secondaryPosition
        ? computePositionOvr(profile, profile.secondaryPosition)
        : null,
    [profile]
  );

  const heightMeters = (1.82 * profile.heightScale).toFixed(2);

  const updateWithOvr = (next: CreatedPlayerProfile) => {
    const ovr = computePositionOvr(next, next.position);
    onChange({ ...next, ovr });
  };

  const setStatValue = (key: AttributeKey, rawTarget: number) => {
    const clampedTarget = Math.max(BASE_STAT_MIN, Math.min(STAT_MAX, Math.round(rawTarget)));
    const currentVal = profile[key];
    const delta = clampedTarget - currentVal;
    const allowedDelta = delta > 0 ? Math.min(delta, pointsRemaining) : delta;
    const nextVal = currentVal + allowedDelta;
    if (nextVal === currentVal) return;
    updateWithOvr({ ...profile, [key]: nextVal });
  };

  const handlePrimaryPosition = (pos: Position) => {
    const nextSecondary =
      profile.secondaryPosition === pos ? null : profile.secondaryPosition;
    const matchingStyle =
      PLAYSTYLES.find((p) => p.id === profile.playstyle)?.primaryRole === pos
        ? profile.playstyle
        : PLAYSTYLES.find((p) => p.primaryRole === pos)?.id || profile.playstyle;

    updateWithOvr({
      ...profile,
      position: pos,
      secondaryPosition: nextSecondary,
      playstyle: matchingStyle,
    });
  };

  const handleAutoAllocate = (pos: Position = profile.position, style: PlaystyleId = profile.playstyle) => {
    const preset = createRolePresetStats(pos, style);
    updateWithOvr({ ...profile, ...preset });
  };

  const handleResetStats = () => {
    updateWithOvr({
      ...profile,
      pace: BASE_STAT_MIN,
      shooting: BASE_STAT_MIN,
      passing: BASE_STAT_MIN,
      dribbling: BASE_STAT_MIN,
      defending: BASE_STAT_MIN,
      physical: BASE_STAT_MIN,
    });
  };

  const toggleTrait = (traitId: PlayerTraitId) => {
    const has = profile.traits.includes(traitId);
    if (has) {
      onChange({
        ...profile,
        traits: profile.traits.filter((t) => t !== traitId),
      });
    } else if (profile.traits.length < MAX_TRAITS) {
      onChange({
        ...profile,
        traits: [...profile.traits, traitId],
      });
    } else {
      // Replace oldest trait cleanly so user can switch smoothly
      onChange({
        ...profile,
        traits: [...profile.traits.slice(1), traitId],
      });
    }
  };

  const handleRandomize = () => {
    const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
    const pos = pick(POSITIONS);
    const otherPositions = POSITIONS.filter((p) => p !== pos);
    const body = pick(BODY_TYPES);
    const styleCandidates = PLAYSTYLES.filter((s) => s.primaryRole === pos);
    const chosenStyle = pick(styleCandidates.length > 0 ? styleCandidates : PLAYSTYLES);
    const stats = createRolePresetStats(pos, chosenStyle.id);

    const shuffledTraits = [...PLAYER_TRAITS].sort(() => Math.random() - 0.5);
    const nextTraits = shuffledTraits.slice(0, 2).map((t) => t.id);

    const next: CreatedPlayerProfile = {
      ...profile,
      nationality: pick(QUICK_NATIONS),
      position: pos,
      secondaryPosition: Math.random() > 0.2 ? pick(otherPositions) : null,
      number: Math.floor(Math.random() * 98) + 1,
      age: 18 + Math.floor(Math.random() * 11),
      preferredFoot: pick(PREFERRED_FEET),
      skinTone: pick(SKIN_TONES),
      hairColor: pick(HAIR_COLORS),
      faceStyle: pick(FACE_STYLES).id,
      hairStyle: pick(HAIR_STYLES).id,
      bodyType: body.id,
      bootColor: pick(BOOT_COLORS),
      heightScale: body.defaultHeight,
      playstyle: chosenStyle.id,
      traits: nextTraits,
      ...stats,
    };
    updateWithOvr(next);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 p-3 md:p-5">
      <div className="w-full max-w-5xl max-h-[92vh] overflow-y-auto rounded-xl border border-white/10 bg-[#0B111B] p-5 md:p-6 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h2 className="font-display text-2xl md:text-3xl font-bold tracking-wide text-white">
              Player Creation Studio
            </h2>
            <p className="text-xs text-slate-400">
              {club.name}
              <span className="mx-1.5" aria-hidden="true">·</span>
              {profile.playstyle}
              <span className="mx-1.5" aria-hidden="true">·</span>
              {profile.position}
              {profile.secondaryPosition ? ` / ${profile.secondaryPosition}` : ''}
              <span className="mx-1.5" aria-hidden="true">·</span>
              OVR <span className="font-mono-tabular text-emerald-400 font-bold">{profile.ovr}</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRandomize}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-white/10 bg-[#111927] text-xs font-semibold text-slate-200 hover:border-white/25 transition-colors whitespace-nowrap shrink-0"
            >
              <Shuffle className="w-3.5 h-3.5 text-sky-400" />
              Randomize
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
              aria-label="Close Player Creation Studio"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main 2-Column Studio Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Column: Live 3D Showcase & Identity Card */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1 p-1 rounded-lg bg-[#111927] border border-white/10">
                  {(['home', 'away', 'training'] as const).map((variant) => (
                    <button
                      key={variant}
                      type="button"
                      onClick={() => setKitVariant(variant)}
                      className={`px-2.5 py-1.5 rounded-md text-xs font-semibold capitalize transition-colors whitespace-nowrap shrink-0 ${
                        kitVariant === variant
                          ? 'bg-emerald-500 text-slate-950'
                          : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      {variant} Kit
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setCameraFocus((prev) => (prev === 'full' ? 'head' : 'full'))
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 bg-[#111927] text-xs font-semibold text-slate-200 hover:border-sky-400/50 transition-colors whitespace-nowrap shrink-0"
                >
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  {cameraFocus === 'full' ? 'Zoom Face' : 'Full Body'}
                </button>
              </div>

              <PlayerPreview3D
                profile={profile}
                club={club}
                kitVariant={kitVariant}
                cameraFocus={cameraFocus}
              />

              <p className="text-[11px] text-slate-400 text-center">
                Drag across 3D player to inspect face, hairstyle, build, dorsal #{profile.number}, and cleats
              </p>
            </div>

            {/* Clean Player Summary Strip */}
            <div className="rounded-xl border border-white/10 bg-[#111927] p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="min-w-0">
                  <p className="font-display text-xl font-bold text-white truncate">
                    #{profile.number} {profile.name || 'Unnamed Player'}
                  </p>
                  <p className="text-xs text-slate-400">
                    {profile.nationality || 'INT'} · Age{' '}
                    <span className="font-mono-tabular">{profile.age}</span> ·{' '}
                    <span className="font-mono-tabular">{heightMeters}m</span> ·{' '}
                    {profile.preferredFoot} Foot
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="font-mono-tabular text-2xl font-extrabold text-emerald-400 leading-none">
                    {profile.ovr}
                  </p>
                  <p className="text-[11px] text-slate-400 font-semibold">
                    {profile.position}
                    {secondaryOvr !== null && profile.secondaryPosition
                      ? ` / ${profile.secondaryPosition} ${secondaryOvr}`
                      : ''}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-6 gap-1.5 text-center">
                {ATTRIBUTE_META.map((a) => (
                  <div key={a.key} className="rounded bg-[#0B111B] py-1.5 border border-white/5">
                    <p className="text-[10px] text-slate-400 font-semibold">{a.short}</p>
                    <p className="font-mono-tabular text-sm font-bold text-white">
                      {profile[a.key]}
                    </p>
                  </div>
                ))}
              </div>

              <div className="text-xs text-slate-300">
                <span className="text-slate-400">Traits: </span>
                {profile.traits.length > 0
                  ? profile.traits
                      .map((id) => PLAYER_TRAITS.find((t) => t.id === id)?.name || id)
                      .join(' · ')
                  : 'None selected'}
              </div>
            </div>
          </div>

          {/* Right Column: 4-Tab Customizer Controls */}
          <div className="lg:col-span-7 flex flex-col space-y-4">
            {/* Segmented Tab Navigation */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-lg bg-[#111927] border border-white/10">
              {(
                [
                  ['identity', 'Identity & Roles'],
                  ['appearance', 'Appearance'],
                  ['skills', `Skill Points (${pointsRemaining})`],
                  ['traits', `Traits (${profile.traits.length}/${MAX_TRAITS})`],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setTab(id)}
                  className={`px-3 py-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    tab === id
                      ? 'bg-emerald-500 text-slate-950'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Tab 1: Identity & Positions */}
            {tab === 'identity' && (
              <div className="space-y-5 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1.5">
                      Player Full Name
                    </label>
                    <input
                      type="text"
                      maxLength={32}
                      value={profile.name}
                      onChange={(e) => onChange({ ...profile, name: e.target.value })}
                      className="w-full rounded-lg border border-white/10 bg-[#111927] px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2.5">
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1.5">
                        Nation
                      </label>
                      <input
                        type="text"
                        maxLength={3}
                        value={profile.nationality}
                        onChange={(e) =>
                          onChange({
                            ...profile,
                            nationality: e.target.value.toUpperCase().replace(/[^A-Z]/g, ''),
                          })
                        }
                        className="w-full rounded-lg border border-white/10 bg-[#111927] px-3 py-2.5 text-sm text-white uppercase focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1.5">
                        Number
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={99}
                        value={profile.number}
                        onChange={(e) =>
                          onChange({
                            ...profile,
                            number: Math.max(1, Math.min(99, Number(e.target.value) || 10)),
                          })
                        }
                        className="w-full rounded-lg border border-white/10 bg-[#111927] px-2.5 py-2.5 text-sm text-white font-mono-tabular focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1.5">
                        Age
                      </label>
                      <input
                        type="number"
                        min={17}
                        max={36}
                        value={profile.age}
                        onChange={(e) =>
                          onChange({
                            ...profile,
                            age: Math.max(17, Math.min(36, Number(e.target.value) || 21)),
                          })
                        }
                        className="w-full rounded-lg border border-white/10 bg-[#111927] px-2.5 py-2.5 text-sm text-white font-mono-tabular focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Quick Nation Selector */}
                <div>
                  <span className="block text-xs font-medium text-slate-400 mb-1.5">
                    Quick Nationality Presets
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {QUICK_NATIONS.map((nat) => (
                      <button
                        key={nat}
                        type="button"
                        onClick={() => onChange({ ...profile, nationality: nat })}
                        className={`px-2.5 py-1.5 rounded text-xs font-mono-tabular font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                          profile.nationality === nat
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                            : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                        }`}
                      >
                        {nat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Primary & Secondary Position */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1 border-t border-white/10">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-2">
                      Primary Position (Determines Main OVR)
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {POSITIONS.map((pos) => (
                        <button
                          key={pos}
                          type="button"
                          onClick={() => handlePrimaryPosition(pos)}
                          className={`py-2.5 rounded-lg text-xs font-bold border transition-colors whitespace-nowrap shrink-0 ${
                            profile.position === pos
                              ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                              : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                          }`}
                        >
                          {pos}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-2">
                      Secondary Position (Versatility Role)
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      <button
                        type="button"
                        onClick={() => onChange({ ...profile, secondaryPosition: null })}
                        className={`py-2.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                          profile.secondaryPosition === null
                            ? 'bg-sky-500/20 border-sky-400 text-sky-300'
                            : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                        }`}
                      >
                        None
                      </button>
                      {POSITIONS.filter((p) => p !== profile.position).map((pos) => (
                        <button
                          key={pos}
                          type="button"
                          onClick={() => onChange({ ...profile, secondaryPosition: pos })}
                          className={`py-2.5 rounded-lg text-xs font-bold border transition-colors whitespace-nowrap shrink-0 ${
                            profile.secondaryPosition === pos
                              ? 'bg-sky-500/20 border-sky-400 text-sky-300'
                              : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                          }`}
                        >
                          {pos}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Preferred Foot */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    Preferred Foot
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {PREFERRED_FEET.map((foot) => (
                      <button
                        key={foot}
                        type="button"
                        onClick={() => onChange({ ...profile, preferredFoot: foot })}
                        className={`py-2.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                          profile.preferredFoot === foot
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                            : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                        }`}
                      >
                        {foot} Foot
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Physical Appearance (Body Type, Height, Face, Hair, Cleats) */}
            {tab === 'appearance' && (
              <div className="space-y-5 pt-1">
                {/* Body Type */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    Body Type &amp; Build
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {BODY_TYPES.map((bt) => (
                      <button
                        key={bt.id}
                        type="button"
                        onClick={() =>
                          onChange({
                            ...profile,
                            bodyType: bt.id,
                            heightScale: bt.defaultHeight,
                          })
                        }
                        className={`p-2.5 rounded-lg text-left border transition-colors ${
                          profile.bodyType === bt.id
                            ? 'bg-emerald-500/15 border-emerald-500 text-white'
                            : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                        }`}
                      >
                        <p className="text-xs font-bold">{bt.label}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                          {bt.detail}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Height Slider */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-medium">Player Height</span>
                    <span className="font-mono-tabular font-bold text-emerald-400">
                      {heightMeters} m
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.93}
                    max={1.09}
                    step={0.01}
                    value={profile.heightScale}
                    onChange={(e) =>
                      onChange({ ...profile, heightScale: Number(e.target.value) })
                    }
                    className="w-full accent-emerald-500 cursor-pointer"
                  />
                </div>

                {/* Face Style */}
                <div className="border-t border-white/10 pt-4">
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    Face &amp; Facial Hair Profile
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {FACE_STYLES.map((fs) => (
                      <button
                        key={fs.id}
                        type="button"
                        onClick={() => {
                          onChange({ ...profile, faceStyle: fs.id });
                          setCameraFocus('head');
                        }}
                        className={`px-2.5 py-2 rounded-lg text-left border transition-colors ${
                          profile.faceStyle === fs.id
                            ? 'bg-emerald-500/15 border-emerald-500 text-white'
                            : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                        }`}
                      >
                        <p className="text-xs font-bold whitespace-nowrap">{fs.label}</p>
                        <p className="text-[10px] text-slate-400 leading-tight mt-0.5">
                          {fs.detail}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Hair Style */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    Hairstyle
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {HAIR_STYLES.map((hs) => (
                      <button
                        key={hs.id}
                        type="button"
                        onClick={() => {
                          onChange({ ...profile, hairStyle: hs.id });
                          setCameraFocus('head');
                        }}
                        className={`py-2 px-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                          profile.hairStyle === hs.id
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                            : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                        }`}
                      >
                        {hs.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color Swatches: Skin, Hair, Cleats */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-white/10 pt-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-2">
                      Skin Tone
                    </label>
                    <div className="flex flex-wrap items-center gap-2">
                      {SKIN_TONES.map((tone) => (
                        <button
                          key={tone}
                          type="button"
                          onClick={() => onChange({ ...profile, skinTone: tone })}
                          style={{ backgroundColor: tone }}
                          className={`w-7 h-7 rounded-full border-2 transition-transform ${
                            profile.skinTone === tone
                              ? 'border-emerald-400 scale-110'
                              : 'border-white/20'
                          }`}
                          aria-label={`Select skin tone ${tone}`}
                        />
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-2">
                      Hair Color
                    </label>
                    <div className="flex flex-wrap items-center gap-2">
                      {HAIR_COLORS.map((hair) => (
                        <button
                          key={hair}
                          type="button"
                          onClick={() => onChange({ ...profile, hairColor: hair })}
                          style={{ backgroundColor: hair }}
                          className={`w-7 h-7 rounded-full border-2 transition-transform ${
                            profile.hairColor === hair
                              ? 'border-emerald-400 scale-110'
                              : 'border-white/20'
                          }`}
                          aria-label={`Select hair color ${hair}`}
                        />
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-2">
                      Boots / Cleats
                    </label>
                    <div className="flex flex-wrap items-center gap-2">
                      {BOOT_COLORS.map((boot) => (
                        <button
                          key={boot}
                          type="button"
                          onClick={() => {
                            onChange({ ...profile, bootColor: boot });
                            setCameraFocus('full');
                          }}
                          style={{ backgroundColor: boot }}
                          className={`w-7 h-7 rounded-full border-2 transition-transform ${
                            profile.bootColor === boot
                              ? 'border-emerald-400 scale-110'
                              : 'border-white/20'
                          }`}
                          aria-label={`Select boot color ${boot}`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: Skill Points Allocation */}
            {tab === 'skills' && (
              <div className="space-y-4 pt-1">
                <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-white/10 bg-[#111927] px-4 py-3">
                  <div>
                    <p className="text-xs text-slate-400">Skill Points Bank</p>
                    <p className="text-sm font-semibold text-white">
                      Remaining:{' '}
                      <span
                        className={`font-mono-tabular font-extrabold ${
                          pointsRemaining > 0 ? 'text-emerald-400' : 'text-slate-300'
                        }`}
                      >
                        {pointsRemaining}
                      </span>{' '}
                      <span className="font-mono-tabular text-xs text-slate-400">
                        / {SKILL_POINT_POOL} pts
                      </span>
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleAutoAllocate(profile.position, profile.playstyle)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/50 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/30 transition-colors whitespace-nowrap shrink-0"
                    >
                      Auto-Fit {profile.position}
                    </button>
                    <button
                      type="button"
                      onClick={handleResetStats}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-white/10 bg-[#0B111B] text-xs font-semibold text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0"
                    >
                      <RotateCcw className="w-3 h-3" />
                      Reset
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                  <div className="md:col-span-8 space-y-3">
                    {ATTRIBUTE_META.map((attr) => {
                      const val = profile[attr.key];
                      const isKeyAttr = attr.keyFor.includes(profile.position);
                      return (
                        <div key={attr.key} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className={isKeyAttr ? 'text-white font-semibold' : 'text-slate-300'}>
                              {attr.label}
                              {isKeyAttr ? ' · Key' : ''}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => setStatValue(attr.key, val - 5)}
                                disabled={val <= BASE_STAT_MIN}
                                className="px-1.5 py-0.5 rounded bg-[#111927] border border-white/10 text-[11px] font-mono-tabular text-slate-300 disabled:opacity-40 hover:border-white/30"
                                aria-label={`Decrease ${attr.label} by 5`}
                              >
                                -5
                              </button>
                              <button
                                type="button"
                                onClick={() => setStatValue(attr.key, val - 1)}
                                disabled={val <= BASE_STAT_MIN}
                                className="p-1 rounded bg-[#111927] border border-white/10 text-slate-300 disabled:opacity-40 hover:border-white/30"
                                aria-label={`Decrease ${attr.label} by 1`}
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="w-7 text-center font-mono-tabular font-bold text-emerald-400">
                                {val}
                              </span>
                              <button
                                type="button"
                                onClick={() => setStatValue(attr.key, val + 1)}
                                disabled={val >= STAT_MAX || pointsRemaining <= 0}
                                className="p-1 rounded bg-[#111927] border border-white/10 text-slate-300 disabled:opacity-40 hover:border-white/30"
                                aria-label={`Increase ${attr.label} by 1`}
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setStatValue(attr.key, val + 5)}
                                disabled={val >= STAT_MAX || pointsRemaining <= 0}
                                className="px-1.5 py-0.5 rounded bg-[#111927] border border-white/10 text-[11px] font-mono-tabular text-slate-300 disabled:opacity-40 hover:border-white/30"
                                aria-label={`Increase ${attr.label} by 5`}
                              >
                                +5
                              </button>
                            </div>
                          </div>
                          <input
                            type="range"
                            min={BASE_STAT_MIN}
                            max={STAT_MAX}
                            value={val}
                            onChange={(e) => setStatValue(attr.key, Number(e.target.value))}
                            className="w-full accent-emerald-500 cursor-pointer"
                          />
                        </div>
                      );
                    })}
                  </div>

                  <div className="md:col-span-4 rounded-xl border border-white/10 bg-[#111927] p-3 text-center space-y-1">
                    <p className="text-[11px] font-semibold text-slate-400">
                      Role Profile ({profile.position})
                    </p>
                    <AttributeRadar profile={profile} />
                    <p className="text-[11px] text-slate-400">
                      Primary OVR{' '}
                      <span className="font-mono-tabular text-emerald-400 font-bold">
                        {profile.ovr}
                      </span>
                      {secondaryOvr !== null && profile.secondaryPosition && (
                        <>
                          {' '}
                          · {profile.secondaryPosition}{' '}
                          <span className="font-mono-tabular text-sky-400 font-bold">
                            {secondaryOvr}
                          </span>
                        </>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 4: Playstyles & Unique Traits */}
            {tab === 'traits' && (
              <div className="space-y-5 pt-1">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-medium text-slate-400">
                      Signature Playstyle (1 Active)
                    </label>
                    <button
                      type="button"
                      onClick={() => handleAutoAllocate(profile.position, profile.playstyle)}
                      className="text-xs font-semibold text-emerald-400 hover:text-emerald-300"
                    >
                      Apply Recommended Stats
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {PLAYSTYLES.map((style) => {
                      const active = profile.playstyle === style.id;
                      return (
                        <button
                          key={style.id}
                          type="button"
                          onClick={() =>
                            onChange({
                              ...profile,
                              playstyle: style.id,
                            })
                          }
                          className={`p-3 rounded-lg text-left border transition-colors ${
                            active
                              ? 'bg-emerald-500/15 border-emerald-500 text-white'
                              : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-bold text-white">{style.id}</span>
                            <span className="text-[11px] font-mono-tabular text-slate-400">
                              {style.primaryRole}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                            {style.summary}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="border-t border-white/10 pt-4">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-medium text-slate-400">
                      Unique Match Traits (Choose up to {MAX_TRAITS})
                    </label>
                    <span className="font-mono-tabular text-xs font-semibold text-emerald-400">
                      {profile.traits.length} / {MAX_TRAITS} Selected
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {PLAYER_TRAITS.map((trait) => {
                      const selected = profile.traits.includes(trait.id);
                      return (
                        <button
                          key={trait.id}
                          type="button"
                          onClick={() => toggleTrait(trait.id)}
                          className={`p-3 rounded-lg text-left border transition-colors ${
                            selected
                              ? 'bg-sky-500/15 border-sky-400 text-white'
                              : 'bg-[#111927] border-white/10 text-slate-300 hover:border-white/25'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-bold text-white">{trait.name}</span>
                            <span className="text-[10px] font-semibold text-slate-400">
                              {trait.category}
                              {selected ? ' · Active' : ''}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                            {trait.effect}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-4">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <User className="w-4 h-4 text-emerald-400" />
            <span>
              Training Kit: {club.shortName} · {club.gymName}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onSaveToSquad}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-white/15 bg-[#111927] text-sm font-semibold text-white hover:bg-white/10 transition-colors whitespace-nowrap shrink-0"
            >
              <Check className="w-4 h-4 text-emerald-400" />
              Save &amp; Insert into Squad
            </button>
            <button
              type="button"
              onClick={onEnterTrainingGym}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-500 text-slate-950 text-sm font-bold hover:bg-emerald-400 transition-colors whitespace-nowrap shrink-0"
            >
              <Dumbbell className="w-4 h-4" />
              Free-Roam Pitch &amp; Club Gym
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
