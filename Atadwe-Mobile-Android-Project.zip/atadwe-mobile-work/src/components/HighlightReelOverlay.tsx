import React from 'react';
import {
  ArrowLeft,
  Camera,
  ChevronLeft,
  ChevronRight,
  Film,
  Pause,
  Play,
  RotateCcw,
  Shield,
  Target,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import {
  Club,
  HighlightType,
  MatchHighlightSummary,
  ReplayCameraAngle,
  ReplayHUDState,
  ReplaySpeed,
} from '../types/game';

interface HighlightReelOverlayProps {
  highlights: MatchHighlightSummary[];
  replayState: ReplayHUDState;
  homeClub: Club;
  awayClub: Club;
  muted: boolean;
  onToggleMute: () => void;
  onSelectHighlight: (highlightId: string) => void;
  onTogglePlay: () => void;
  onRestartClip: () => void;
  onSeek: (timeSec: number) => void;
  onChangeSpeed: (speed: ReplaySpeed) => void;
  onChangeCamera: (camera: ReplayCameraAngle) => void;
  onToggleAutoPlay: () => void;
  onExitReplay: () => void;
}

const SPEED_OPTIONS: { value: ReplaySpeed; label: string }[] = [
  { value: 0.5, label: '0.5x' },
  { value: 1, label: '1.0x' },
  { value: 1.5, label: '1.5x' },
];

const CAMERA_OPTIONS: { value: ReplayCameraAngle; label: string }[] = [
  { value: 'tv_broadcast', label: 'TV Angle' },
  { value: 'goal_cam', label: 'Goal Net' },
  { value: 'action_follow', label: 'Action Cam' },
];

function getTypeStyle(type: HighlightType): {
  badge: string;
  textClass: string;
  borderClass: string;
  Icon: typeof Target;
} {
  switch (type) {
    case 'goal':
      return {
        badge: 'GOAL',
        textClass: 'text-emerald-400',
        borderClass: 'border-emerald-500/40 bg-emerald-500/15',
        Icon: Target,
      };
    case 'save':
      return {
        badge: 'KEY SAVE',
        textClass: 'text-sky-400',
        borderClass: 'border-sky-500/40 bg-sky-500/15',
        Icon: Shield,
      };
    case 'woodwork':
      return {
        badge: 'WOODWORK',
        textClass: 'text-amber-400',
        borderClass: 'border-amber-500/40 bg-amber-500/15',
        Icon: Zap,
      };
    default:
      return {
        badge: 'BIG CHANCE',
        textClass: 'text-slate-200',
        borderClass: 'border-white/20 bg-white/10',
        Icon: Film,
      };
  }
}

export const HighlightReelOverlay: React.FC<HighlightReelOverlayProps> = ({
  highlights,
  replayState,
  homeClub,
  awayClub,
  muted,
  onToggleMute,
  onSelectHighlight,
  onTogglePlay,
  onRestartClip,
  onSeek,
  onChangeSpeed,
  onChangeCamera,
  onToggleAutoPlay,
  onExitReplay,
}) => {
  const activeIdx = Math.max(
    0,
    highlights.findIndex((h) => h.id === replayState.highlightId)
  );
  const active = highlights[activeIdx] || highlights[0];

  if (!active) return null;

  const style = getTypeStyle(active.type);
  const TypeIcon = style.Icon;
  const duration = Math.max(0.5, replayState.duration || active.durationSec);
  const currentTime = Math.min(duration, Math.max(0, replayState.currentTime));
  const peakPercent = Math.min(98, Math.max(2, (active.peakSec / duration) * 100));
  const teamColor =
    active.team === 'home' ? homeClub.homeKit.primary : awayClub.awayKit.primary;

  const handlePrev = () => {
    const prevIdx = (activeIdx - 1 + highlights.length) % highlights.length;
    onSelectHighlight(highlights[prevIdx].id);
  };

  const handleNext = () => {
    const nextIdx = (activeIdx + 1) % highlights.length;
    onSelectHighlight(highlights[nextIdx].id);
  };

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4">
      {/* Top Broadcast Replay Bug & Exit Trigger */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="pointer-events-auto flex items-stretch rounded-xl border border-white/15 bg-[#0B111B]/95 overflow-hidden shadow-2xl">
          <div className="w-1.5" style={{ backgroundColor: teamColor }} />
          <div className="px-4 py-2.5 space-y-0.5">
            <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold tracking-wider uppercase">
              <span className="text-emerald-400">Match Highlights</span>
              <span className="text-slate-500">·</span>
              <span className={`inline-flex items-center gap-1 ${style.textClass}`}>
                <TypeIcon className="w-3 h-3" />
                {style.badge}
              </span>
              <span className="text-slate-500">·</span>
              <span className="font-mono-tabular text-slate-300">{active.minute}&apos;</span>
              <span className="text-slate-500">·</span>
              <span className="font-mono-tabular text-white">{active.scoreText}</span>
              {active.shotSpeedKmh > 0 && (
                <>
                  <span className="text-slate-500">·</span>
                  <span className="font-mono-tabular text-amber-300">
                    {active.shotSpeedKmh} km/h
                  </span>
                </>
              )}
            </div>
            <div className="flex items-center gap-2">
              <p className="font-display text-xl font-bold text-white leading-tight">
                {active.title}
              </p>
              <span className="text-xs text-slate-400 hidden sm:inline">
                {active.subtitle}
              </span>
            </div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={onToggleMute}
            className="p-2.5 rounded-lg bg-[#0B111B]/95 border border-white/15 text-slate-200 hover:text-white"
            aria-label="Toggle Replay Audio"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            onClick={onExitReplay}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#0B111B]/95 border border-white/15 text-xs font-semibold text-white hover:border-emerald-400/60"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-emerald-400" />
            Back to Full-Time
          </button>
        </div>
      </div>

      {/* Bottom Cinema Control Dock */}
      <div className="pointer-events-auto w-full max-w-5xl mx-auto rounded-xl border border-white/15 bg-[#0B111B]/95 p-3.5 space-y-3 shadow-2xl">
        {/* Highlight Clip Selector Strip */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {highlights.map((clip, idx) => {
            const clipStyle = getTypeStyle(clip.type);
            const isSelected = clip.id === active.id;
            return (
              <button
                key={clip.id}
                onClick={() => onSelectHighlight(clip.id)}
                className={`shrink-0 text-left px-3 py-1.5 rounded-lg border transition-colors ${
                  isSelected
                    ? 'border-emerald-400 bg-emerald-500/15'
                    : 'border-white/10 bg-[#111927] hover:border-white/25'
                }`}
              >
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider">
                  <span className="font-mono-tabular text-slate-400">
                    {String(idx + 1).padStart(2, '0')}
                  </span>
                  <span className={clipStyle.textClass}>{clipStyle.badge}</span>
                  <span className="font-mono-tabular text-slate-300">{clip.minute}&apos;</span>
                </div>
                <p className="text-xs font-semibold text-white truncate max-w-[155px]">
                  #{clip.playerNumber} {clip.playerName}
                </p>
              </button>
            );
          })}
        </div>

        {/* Timeline Scrubber with Peak Moment Marker */}
        <div className="flex items-center gap-3">
          <span className="font-mono-tabular text-xs font-semibold text-slate-300 w-12">
            {currentTime.toFixed(1)}s
          </span>
          <div className="relative flex-1 flex items-center h-6">
            <div
              className="absolute top-1/2 -translate-y-1/2 w-1 h-4 rounded-sm bg-emerald-400 pointer-events-none z-10"
              style={{ left: `${peakPercent}%` }}
              title="Key Moment"
            />
            <input
              type="range"
              min={0}
              max={duration}
              step={0.05}
              value={currentTime}
              onChange={(e) => onSeek(Number(e.target.value))}
              aria-label="Highlight Timeline Scrubber"
              className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-white/15 rounded-lg"
            />
          </div>
          <span className="font-mono-tabular text-xs font-semibold text-slate-400 w-12 text-right">
            {duration.toFixed(1)}s
          </span>
        </div>

        {/* Playback Transport, Speed & Camera Angles */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Transport Buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handlePrev}
              disabled={highlights.length <= 1}
              className="p-2 rounded-lg border border-white/10 bg-[#111927] text-slate-200 hover:text-white disabled:opacity-40"
              title="Previous Highlight"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={onTogglePlay}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400"
            >
              {replayState.paused ? (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Play
                </>
              ) : (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  Pause
                </>
              )}
            </button>
            <button
              onClick={onRestartClip}
              className="p-2 rounded-lg border border-white/10 bg-[#111927] text-slate-200 hover:text-white"
              title="Restart Clip"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              disabled={highlights.length <= 1}
              className="p-2 rounded-lg border border-white/10 bg-[#111927] text-slate-200 hover:text-white disabled:opacity-40"
              title="Next Highlight"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={onToggleAutoPlay}
              className={`ml-1 px-2.5 py-2 rounded-lg border text-xs font-semibold transition-colors ${
                replayState.autoPlay
                  ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300'
                  : 'border-white/10 bg-[#111927] text-slate-400 hover:text-white'
              }`}
            >
              Auto-Next: {replayState.autoPlay ? 'On' : 'Off'}
            </button>
          </div>

          {/* Speed & Camera Angle Selectors */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center rounded-lg border border-white/10 bg-[#111927] p-0.5">
              {SPEED_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => onChangeSpeed(opt.value)}
                  className={`px-2.5 py-1 rounded-md font-mono-tabular text-xs font-bold transition-colors ${
                    replayState.speed === opt.value
                      ? 'bg-emerald-500 text-slate-950'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            <div className="flex items-center rounded-lg border border-white/10 bg-[#111927] p-0.5">
              <span className="px-2 text-sky-400">
                <Camera className="w-3.5 h-3.5" />
              </span>
              {CAMERA_OPTIONS.map((cam) => (
                <button
                  key={cam.value}
                  onClick={() => onChangeCamera(cam.value)}
                  className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors ${
                    replayState.camera === cam.value
                      ? 'bg-sky-500 text-slate-950'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {cam.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
