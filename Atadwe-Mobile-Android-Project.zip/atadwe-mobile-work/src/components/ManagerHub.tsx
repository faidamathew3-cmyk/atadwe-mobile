import React, { useMemo, useState } from 'react';
import {
  Activity,
  Brain,
  Briefcase,
  Coins,
  Dumbbell,
  FastForward,
  HeartPulse,
  Play,
  Send,
  Shield,
  Stethoscope,
  Trophy,
  X,
} from 'lucide-react';
import {
  AICoachAnalysis,
  Club,
  DefensiveLine,
  FormationId,
  ManagerState,
  Mentality,
  PassingStyle,
  Position,
  PressingIntensity,
  TrainingFocus,
  TreatmentProtocol,
} from '../types/game';
import { LEAGUES, formatCurrency, getClubAvgOvr } from '../data/leagues';
import {
  FORMATIONS,
  TREATMENT_PROTOCOLS,
  getMedicalMetrics,
  sortStandings,
} from '../state/managerEngine';

interface ManagerHubProps {
  clubs: Record<string, Club>;
  manager: ManagerState;
  onSelectClub: (clubId: string) => void;
  onUpdateTactics: (tactics: ManagerState['tactics']) => void;
  onSwapPlayers: (starterId: string, benchId: string) => void;
  onSetTrainingFocus: (focus: TrainingFocus) => void;
  onRunTrainingSession: () => void;
  onBuyPlayer: (sellerClubId: string, playerId: string) => void;
  onSellPlayer: (playerId: string) => void;
  onUpgradeFacility: (facility: 'stadium' | 'gym' | 'medical') => void;
  onToggleMedicalStaff: (staffId: string) => void;
  onSetMedicalProtocol: (protocol: TreatmentProtocol) => void;
  onFastTrackRehab: (playerId: string) => void;
  onSimulateWeek: () => void;
  onPlayNextMatch: () => void;
  onEnterTrainingGym: () => void;
  onClose: () => void;
}

type ManagerTab =
  | 'overview'
  | 'tactics'
  | 'training'
  | 'medical'
  | 'transfers'
  | 'standings'
  | 'ai_coach';

const FORMATION_LIST: FormationId[] = ['4-3-3', '4-4-2', '4-2-3-1', '3-5-2', '5-3-2'];
const MENTALITIES: Mentality[] = [
  'Ultra Defensive',
  'Defensive',
  'Balanced',
  'Attacking',
  'All-Out Attack',
];
const PRESSING_OPTIONS: PressingIntensity[] = ['Low Block', 'Mid Press', 'Gegenpress'];
const PASSING_OPTIONS: PassingStyle[] = ['Direct', 'Balanced', 'Tiki-Taka'];
const LINE_OPTIONS: DefensiveLine[] = ['Deep', 'Normal', 'High'];
const TRAINING_FOCUSES: TrainingFocus[] = [
  'Finishing Drills',
  'Tactical Rondo',
  'Gym Conditioning',
  'Sprint & Agility',
  'Defensive Shape',
  'Recovery Session',
];

export const ManagerHub: React.FC<ManagerHubProps> = ({
  clubs,
  manager,
  onSelectClub,
  onUpdateTactics,
  onSwapPlayers,
  onSetTrainingFocus,
  onRunTrainingSession,
  onBuyPlayer,
  onSellPlayer,
  onUpgradeFacility,
  onToggleMedicalStaff,
  onSetMedicalProtocol,
  onFastTrackRehab,
  onSimulateWeek,
  onPlayNextMatch,
  onEnterTrainingGym,
  onClose,
}) => {
  const [tab, setTab] = useState<ManagerTab>('overview');
  const [selectedStarterId, setSelectedStarterId] = useState<string | null>(null);
  const [standingsLeagueId, setStandingsLeagueId] = useState<string>(
    clubs[manager.clubId]?.leagueId || 'premier_league'
  );
  const [marketSearch, setMarketSearch] = useState('');
  const [marketPos, setMarketPos] = useState<'ALL' | Position>('ALL');
  const [marketLeague, setMarketLeague] = useState<string>('all');

  // Gemini AI Coach State
  const [coachLoading, setCoachLoading] = useState(false);
  const [coachError, setCoachError] = useState<string | null>(null);
  const [coachAnalysis, setCoachAnalysis] = useState<AICoachAnalysis | null>(null);
  const [coachChatInput, setCoachChatInput] = useState('');
  const [coachMessages, setCoachMessages] = useState<
    { role: 'coach' | 'user'; text: string }[]
  >([
    {
      role: 'coach',
      text: 'Ready on the touchline, gaffer. Ask me about formations, opponent weaknesses, training loads, or transfer targets.',
    },
  ]);

  const userClub = clubs[manager.clubId];
  const userLeague = LEAGUES.find((l) => l.id === userClub?.leagueId) || LEAGUES[0];
  const avgOvr = userClub ? getClubAvgOvr(userClub) : 82;
  const weeklyWageBill = userClub
    ? userClub.roster.reduce((sum, p) => sum + p.weeklyWage, 0)
    : 0;

  const nextFixture = useMemo(
    () =>
      manager.fixtures.find(
        (f) =>
          f.week === manager.currentWeek &&
          !f.played &&
          (f.homeClubId === manager.clubId || f.awayClubId === manager.clubId)
      ),
    [manager.fixtures, manager.currentWeek, manager.clubId]
  );

  const nextOpponent = nextFixture
    ? clubs[
        nextFixture.homeClubId === manager.clubId
          ? nextFixture.awayClubId
          : nextFixture.homeClubId
      ]
    : undefined;

  const starters = useMemo(
    () =>
      manager.startingXIIds
        .map((id) => userClub?.roster.find((p) => p.id === id))
        .filter(Boolean) as Club['roster'],
    [manager.startingXIIds, userClub]
  );

  const bench = useMemo(
    () =>
      manager.benchIds
        .map((id) => userClub?.roster.find((p) => p.id === id))
        .filter(Boolean) as Club['roster'],
    [manager.benchIds, userClub]
  );

  const transferTargets = useMemo(() => {
    const list: { club: Club; player: Club['roster'][number] }[] = [];
    for (const c of Object.values(clubs)) {
      if (c.id === manager.clubId) continue;
      if (marketLeague !== 'all' && c.leagueId !== marketLeague) continue;
      for (const p of c.roster) {
        if (marketPos !== 'ALL' && p.position !== marketPos) continue;
        if (
          marketSearch.trim() &&
          !p.name.toLowerCase().includes(marketSearch.trim().toLowerCase())
        ) {
          continue;
        }
        list.push({ club: c, player: p });
      }
    }
    return list.sort((a, b) => b.player.ovr - a.player.ovr).slice(0, 40);
  }, [clubs, manager.clubId, marketLeague, marketPos, marketSearch]);

  const runAICoachAnalysis = async () => {
    if (!userClub) return;
    setCoachLoading(true);
    setCoachError(null);
    try {
      const avgStamina = Math.round(
        userClub.roster.reduce((acc, p) => acc + p.stamina, 0) /
          Math.max(1, userClub.roster.length)
      );
      const res = await fetch('/api/coach/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clubName: userClub.name,
          leagueName: userLeague.name,
          formation: manager.tactics.formation,
          mentality: manager.tactics.mentality,
          pressing: manager.tactics.pressing,
          passingStyle: manager.tactics.passingStyle,
          teamOvr: avgOvr,
          avgStamina,
          transferBudget: userClub.transferBudget,
          opponentName: nextOpponent?.name || 'Title Rival',
          opponentOvr: nextOpponent ? getClubAvgOvr(nextOpponent) : 84,
          opponentFormation: '4-2-3-1',
          isLiveMatch: false,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI Coach unavailable.');
      setCoachAnalysis(data.analysis as AICoachAnalysis);
    } catch (err) {
      setCoachError(err instanceof Error ? err.message : 'Unable to reach AI Coach.');
    } finally {
      setCoachLoading(false);
    }
  };

  const sendCoachChat = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = coachChatInput.trim();
    if (!q || !userClub) return;
    setCoachChatInput('');
    setCoachMessages((prev) => [...prev, { role: 'user', text: q }]);
    setCoachLoading(true);
    setCoachError(null);
    try {
      const res = await fetch('/api/coach/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: q,
          context: {
            club: userClub.name,
            league: userLeague.name,
            formation: manager.tactics.formation,
            mentality: manager.tactics.mentality,
            budget: formatCurrency(userClub.transferBudget),
            gymTier: userClub.gymTier,
            nextOpponent: nextOpponent?.name,
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI Coach unavailable.');
      setCoachMessages((prev) => [...prev, { role: 'coach', text: data.reply }]);
    } catch (err) {
      setCoachError(err instanceof Error ? err.message : 'Unable to reach AI Coach.');
    } finally {
      setCoachLoading(false);
    }
  };

  if (!userClub) return null;

  const stadiumUpgradeCost = userClub.stadiumTier * 18_000_000;
  const gymUpgradeCost = userClub.gymTier * 10_000_000;
  const medicalTier = userClub.medicalTier || 1;
  const medicalUpgradeCost = medicalTier * 12_000_000;
  const formationSlots = FORMATIONS[manager.tactics.formation];
  const injuredPlayers = userClub.roster.filter((p) => Boolean(p.injury));
  const medicalMetrics = getMedicalMetrics(userClub, manager);
  const fastTrackFee = 350_000;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 p-3 md:p-5">
      <div className="w-full max-w-6xl h-[92vh] flex flex-col rounded-xl border border-white/10 bg-[#0B111B] shadow-2xl overflow-hidden">
        {/* Top Manager Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 px-6 py-4 bg-[#0E1624]">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg border border-white/20 flex items-center justify-center font-display font-bold text-sm text-white shrink-0"
              style={{ backgroundColor: userClub.homeKit.primary }}
            >
              {userClub.shortName}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-2xl font-bold tracking-wide text-white">
                  {userClub.name} Manager Office
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                {userLeague.name} · Season {manager.seasonNumber} · Week{' '}
                <span className="font-mono-tabular text-white">{manager.currentWeek}/10</span> ·
                Budget{' '}
                <span className="font-mono-tabular text-emerald-400 font-semibold">
                  {formatCurrency(userClub.transferBudget)}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={manager.clubId}
              onChange={(e) => onSelectClub(e.target.value)}
              className="rounded-lg border border-white/15 bg-[#111927] px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              aria-label="Switch Managed Club"
            >
              {LEAGUES.map((l) => (
                <optgroup key={l.id} label={`${l.name} (${l.country})`}>
                  {l.clubIds.map((cid) => (
                    <option key={cid} value={cid}>
                      {clubs[cid]?.name}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>

            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
              aria-label="Close Manager Hub"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto border-b border-white/10 px-6 py-2 bg-[#090E17]">
          {(
            [
              ['overview', 'Club & Fixtures', Briefcase],
              ['tactics', 'Formation & Tactics', Shield],
              ['training', 'Training & Gym', Dumbbell],
              [
                'medical',
                injuredPlayers.length > 0 ? `Medical Room (${injuredPlayers.length})` : 'Medical Room',
                HeartPulse,
              ],
              ['transfers', 'Transfers & Budget', Coins],
              ['standings', 'Leagues & Cup', Trophy],
              ['ai_coach', 'AI Coach', Brain],
            ] as const
          ).map(([id, label, Icon]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                tab === id
                  ? 'bg-emerald-500 text-slate-950'
                  : id === 'medical' && injuredPlayers.length > 0
                    ? 'text-rose-300 hover:text-white hover:bg-rose-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {tab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-5">
                {/* Next Matchday Card */}
                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-xs font-medium text-emerald-400">
                        Matchweek {manager.currentWeek} · {userLeague.name}
                      </p>
                      <h3 className="font-display text-2xl font-bold text-white mt-0.5">
                        {nextFixture
                          ? `${clubs[nextFixture.homeClubId]?.name} vs ${clubs[nextFixture.awayClubId]?.name}`
                          : 'End of Season Review'}
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        {nextFixture
                          ? `${clubs[nextFixture.homeClubId]?.stadiumName} · Formation ${manager.tactics.formation} · ${manager.tactics.mentality}`
                          : 'Advance to begin next campaign'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={onSimulateWeek}
                        className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-white/15 bg-white/5 text-xs font-semibold text-white hover:bg-white/10 transition-colors"
                      >
                        <FastForward className="w-4 h-4 text-sky-400" />
                        Simulate Week
                      </button>
                      <button
                        onClick={onPlayNextMatch}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-500 text-slate-950 text-xs font-bold hover:bg-emerald-400 transition-colors"
                      >
                        <Play className="w-4 h-4" />
                        Play 3D Match
                      </button>
                    </div>
                  </div>
                  {manager.lastMatchSummary && (
                    <div className="border-t border-white/10 pt-3 text-xs text-slate-300">
                      Last Result: <span className="font-semibold text-white">{manager.lastMatchSummary}</span>
                    </div>
                  )}
                </div>

                {/* Continental Cup Bracket */}
                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-display text-lg font-bold text-white">
                      Continental Champions Cup Bracket
                    </h4>
                    <span className="text-xs text-slate-400">Knockout Weeks 4 · 7 · 10</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {manager.cupTies.map((tie) => {
                      const h = clubs[tie.homeClubId];
                      const a = clubs[tie.awayClubId];
                      return (
                        <div
                          key={tie.id}
                          className="rounded-lg border border-white/10 bg-[#0B111B] p-3 flex items-center justify-between text-xs"
                        >
                          <div>
                            <p className="text-[11px] text-amber-400 font-medium">
                              {tie.round} · Wk {tie.week}
                            </p>
                            <p className="text-white font-semibold mt-0.5">
                              {h?.shortName} vs {a?.shortName}
                            </p>
                          </div>
                          <div className="font-mono-tabular text-sm font-bold text-emerald-400">
                            {tie.played ? `${tie.homeGoals} - ${tie.awayGoals}` : 'Upcoming'}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Club Summary & Trophy Cabinet */}
              <div className="space-y-4">
                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-3">
                  <h4 className="font-display text-lg font-bold text-white">Club Operations</h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Starting XI OVR</span>
                      <span className="font-mono-tabular font-bold text-emerald-400">{avgOvr}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Stadium</span>
                      <span className="text-white">
                        {userClub.stadiumName} (Lv {userClub.stadiumTier})
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Club Gym</span>
                      <span className="text-white">
                        {userClub.gymName} (Lv {userClub.gymTier})
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Medical Wing</span>
                      <button
                        onClick={() => setTab('medical')}
                        className={`font-semibold hover:underline ${
                          injuredPlayers.length > 0 ? 'text-rose-400' : 'text-emerald-400'
                        }`}
                      >
                        Tier {medicalTier}/5 ·{' '}
                        {injuredPlayers.length > 0
                          ? `${injuredPlayers.length} Injured`
                          : 'Squad Fit'}
                      </button>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Weekly Payroll</span>
                      <span className="font-mono-tabular text-amber-300">
                        {formatCurrency(weeklyWageBill)}/wk
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Career Record</span>
                      <span className="font-mono-tabular text-white">
                        {manager.careerStats.wins}W-{manager.careerStats.draws}D-
                        {manager.careerStats.losses}L
                      </span>
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-3">
                  <h4 className="font-display text-lg font-bold text-white">Trophy Cabinet</h4>
                  {manager.trophies.length === 0 ? (
                    <p className="text-xs text-slate-400">
                      Win your domestic league or the Continental Champions Cup to claim silverware.
                    </p>
                  ) : (
                    <ul className="space-y-1.5 text-xs text-amber-300 font-medium">
                      {manager.trophies.map((t, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <Trophy className="w-3.5 h-3.5 shrink-0" />
                          <span>{t}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          )}

          {tab === 'tactics' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Interactive 2D Pitch Board */}
              <div className="lg:col-span-2 rounded-xl border border-white/10 bg-[#0D2E1A] p-4 relative aspect-[16/11] overflow-hidden">
                {/* Pitch Markings */}
                <div className="absolute inset-4 border border-white/25 rounded-sm pointer-events-none">
                  <div className="absolute left-0 right-0 top-1/2 h-px bg-white/25" />
                  <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full border border-white/25" />
                </div>

                {starters.map((player, idx) => {
                  const slot = formationSlots[idx % formationSlots.length];
                  const leftPct = 50 + slot.nx * 38;
                  const topPct = 50 - slot.nz * 42;
                  const isSelected = selectedStarterId === player.id;
                  return (
                    <button
                      key={player.id}
                      onClick={() =>
                        setSelectedStarterId(isSelected ? null : player.id)
                      }
                      style={{ left: `${leftPct}%`, top: `${topPct}%` }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group transition-transform ${
                        isSelected ? 'scale-110 z-10' : 'hover:scale-105'
                      }`}
                    >
                      <div
                        className={`w-9 h-9 rounded-full border-2 flex items-center justify-center font-mono-tabular text-xs font-bold text-white shadow ${
                          isSelected ? 'border-emerald-300 ring-2 ring-emerald-400/50' : 'border-white'
                        }`}
                        style={{ backgroundColor: userClub.homeKit.primary }}
                      >
                        {player.number}
                      </div>
                      <span className="mt-1 px-1.5 py-0.5 rounded bg-black/75 text-[10px] font-medium text-white whitespace-nowrap">
                        {slot.label} · {player.name.split(' ').slice(-1)[0]} ({player.ovr})
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Tactical Controls + Bench */}
              <div className="space-y-4">
                <div className="rounded-xl border border-white/10 bg-[#111927] p-4 space-y-3">
                  <h4 className="font-display text-lg font-bold text-white">Tactical System</h4>
                  <div className="space-y-2.5 text-xs">
                    <div>
                      <label className="block text-slate-400 mb-1">Formation</label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {FORMATION_LIST.map((f) => (
                          <button
                            key={f}
                            onClick={() =>
                              onUpdateTactics({ ...manager.tactics, formation: f })
                            }
                            className={`py-1.5 rounded font-mono-tabular font-semibold border ${
                              manager.tactics.formation === f
                                ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                                : 'bg-[#0B111B] text-slate-300 border-white/10'
                            }`}
                          >
                            {f}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">Team Mentality</label>
                      <select
                        value={manager.tactics.mentality}
                        onChange={(e) =>
                          onUpdateTactics({
                            ...manager.tactics,
                            mentality: e.target.value as Mentality,
                          })
                        }
                        className="w-full rounded-lg border border-white/10 bg-[#0B111B] px-3 py-2 text-white"
                      >
                        {MENTALITIES.map((m) => (
                          <option key={m} value={m}>
                            {m}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-slate-400 mb-1">Pressing</label>
                        <select
                          value={manager.tactics.pressing}
                          onChange={(e) =>
                            onUpdateTactics({
                              ...manager.tactics,
                              pressing: e.target.value as PressingIntensity,
                            })
                          }
                          className="w-full rounded-lg border border-white/10 bg-[#0B111B] px-2 py-2 text-white"
                        >
                          {PRESSING_OPTIONS.map((p) => (
                            <option key={p} value={p}>
                              {p}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">Passing</label>
                        <select
                          value={manager.tactics.passingStyle}
                          onChange={(e) =>
                            onUpdateTactics({
                              ...manager.tactics,
                              passingStyle: e.target.value as PassingStyle,
                            })
                          }
                          className="w-full rounded-lg border border-white/10 bg-[#0B111B] px-2 py-2 text-white"
                        >
                          {PASSING_OPTIONS.map((p) => (
                            <option key={p} value={p}>
                              {p}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-400 mb-1">Defensive Line</label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {LINE_OPTIONS.map((line) => (
                          <button
                            key={line}
                            onClick={() =>
                              onUpdateTactics({ ...manager.tactics, defensiveLine: line })
                            }
                            className={`py-1.5 rounded font-semibold border ${
                              manager.tactics.defensiveLine === line
                                ? 'bg-sky-500 text-slate-950 border-sky-400'
                                : 'bg-[#0B111B] text-slate-300 border-white/10'
                            }`}
                          >
                            {line}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Substitutes */}
                <div className="rounded-xl border border-white/10 bg-[#111927] p-4 space-y-2">
                  <p className="text-xs font-semibold text-white">
                    Substitutes {selectedStarterId ? '(Click sub to swap)' : '(Select a starter on pitch)'}
                  </p>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto">
                    {bench.map((sub) => {
                      const isInjured = Boolean(sub.injury);
                      return (
                        <button
                          key={sub.id}
                          disabled={isInjured}
                          onClick={() => {
                            if (selectedStarterId && !isInjured) {
                              onSwapPlayers(selectedStarterId, sub.id);
                              setSelectedStarterId(null);
                            }
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs border transition-colors ${
                            isInjured
                              ? 'border-rose-500/30 bg-rose-500/10 text-rose-300 opacity-75 cursor-not-allowed'
                              : selectedStarterId
                                ? 'border-emerald-500/40 bg-emerald-500/10 hover:bg-emerald-500/20 text-white'
                                : 'border-white/5 bg-[#0B111B] text-slate-300'
                          }`}
                        >
                          <span className="truncate">
                            {sub.position} · {sub.name}
                            {sub.injury
                              ? ` — INJ (${sub.injury.weeksRemaining}w)`
                              : ''}
                          </span>
                          <span className="font-mono-tabular font-bold text-emerald-400">
                            {sub.ovr}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === 'training' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-3">
                  <h4 className="font-display text-lg font-bold text-white">
                    Weekly Training Schedule
                  </h4>
                  <div className="grid grid-cols-1 gap-1.5">
                    {TRAINING_FOCUSES.map((focus) => (
                      <button
                        key={focus}
                        onClick={() => onSetTrainingFocus(focus)}
                        className={`text-left px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
                          manager.teamTrainingFocus === focus
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                            : 'bg-[#0B111B] border-white/10 text-slate-300 hover:border-white/25'
                        }`}
                      >
                        {focus}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={onRunTrainingSession}
                    className="w-full mt-2 py-2 rounded-lg border border-sky-400/40 bg-sky-500/15 text-sky-300 font-bold text-xs hover:bg-sky-500/25 transition-colors"
                  >
                    Run Squad Drill Session Now
                  </button>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-4">
                  <h4 className="font-display text-lg font-bold text-white">
                    Club Gym & Stadium Upgrades
                  </h4>
                  <div className="space-y-3 text-xs">
                    <div className="rounded-lg border border-white/10 bg-[#0B111B] p-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="font-semibold text-white">{userClub.gymName}</span>
                        <span className="font-mono-tabular text-emerald-400">
                          Tier {userClub.gymTier}/5
                        </span>
                      </div>
                      <p className="text-slate-400">
                        Boosts weekly attribute growth and match stamina recovery.
                      </p>
                      <button
                        disabled={userClub.gymTier >= 5 || userClub.transferBudget < gymUpgradeCost}
                        onClick={() => onUpgradeFacility('gym')}
                        className="w-full py-2 rounded bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-400 text-slate-950 font-bold"
                      >
                        {userClub.gymTier >= 5
                          ? 'Max Gym Tier Reached'
                          : `Upgrade Gym (${formatCurrency(gymUpgradeCost)})`}
                      </button>
                    </div>

                    <div className="rounded-lg border border-white/10 bg-[#0B111B] p-3 space-y-2">
                      <div className="flex justify-between">
                        <span className="font-semibold text-white">{userClub.stadiumName}</span>
                        <span className="font-mono-tabular text-sky-400">
                          Tier {userClub.stadiumTier}/5
                        </span>
                      </div>
                      <p className="text-slate-400">
                        Capacity {userClub.stadiumCapacity.toLocaleString()} · Increases gate ticket income.
                      </p>
                      <button
                        disabled={
                          userClub.stadiumTier >= 5 || userClub.transferBudget < stadiumUpgradeCost
                        }
                        onClick={() => onUpgradeFacility('stadium')}
                        className="w-full py-2 rounded bg-sky-500 disabled:bg-slate-700 disabled:text-slate-400 text-slate-950 font-bold"
                      >
                        {userClub.stadiumTier >= 5
                          ? 'Max Stadium Expansion'
                          : `Expand Stadium (${formatCurrency(stadiumUpgradeCost)})`}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-display text-lg font-bold text-white">
                      3D Training Ground & Gym
                    </h4>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Jump onto the pitch in {userClub.shortName} training kits and walk directly into {userClub.gymName} with your Created Star Player.
                    </p>
                    <div className="flex items-center gap-2 pt-2">
                      <span className="text-xs text-slate-400">Training Kit:</span>
                      <span
                        className="w-5 h-5 rounded border border-white/20"
                        style={{ backgroundColor: userClub.trainingKit.primary }}
                      />
                      <span
                        className="w-5 h-5 rounded border border-white/20"
                        style={{ backgroundColor: userClub.trainingKit.secondary }}
                      />
                    </div>
                  </div>
                  <button
                    onClick={onEnterTrainingGym}
                    className="w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors"
                  >
                    <Dumbbell className="w-4 h-4" />
                    Enter 3D Training & Gym
                  </button>
                </div>
              </div>

              {/* Squad Development Table */}
              <div className="rounded-xl border border-white/10 bg-[#111927] overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#0B111B] text-slate-400 border-b border-white/10">
                    <tr>
                      <th className="px-4 py-3">Player</th>
                      <th className="px-3 py-3">Pos</th>
                      <th className="px-3 py-3">Status</th>
                      <th className="px-3 py-3">OVR</th>
                      <th className="px-3 py-3">PAC</th>
                      <th className="px-3 py-3">SHO</th>
                      <th className="px-3 py-3">PAS</th>
                      <th className="px-3 py-3">DRI</th>
                      <th className="px-3 py-3">DEF</th>
                      <th className="px-3 py-3">PHY</th>
                      <th className="px-3 py-3">Stamina</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {userClub.roster.map((p) => (
                      <tr key={p.id} className="hover:bg-white/[0.03]">
                        <td className="px-4 py-2.5 font-medium text-white">
                          <div>
                            #{p.number} {p.name}
                            {p.isCreatedStar ? ' ★' : ''}
                          </div>
                          {p.playstyle && (
                            <div className="text-[10px] text-slate-400">{p.playstyle}</div>
                          )}
                        </td>
                        <td className="px-3 py-2.5 text-slate-400">
                          {p.position}
                          {p.secondaryPosition ? ` / ${p.secondaryPosition}` : ''}
                        </td>
                        <td className="px-3 py-2.5">
                          {p.injury ? (
                            <button
                              onClick={() => setTab('medical')}
                              className="text-rose-400 font-semibold hover:underline text-left"
                            >
                              {p.injury.type} · {p.injury.weeksRemaining}w
                            </button>
                          ) : (
                            <span className="text-emerald-400 font-medium">Fit</span>
                          )}
                        </td>
                        <td className="px-3 py-2.5 font-mono-tabular font-bold text-emerald-400">
                          {p.ovr}
                        </td>
                        <td className="px-3 py-2.5 font-mono-tabular text-slate-200">{p.pace}</td>
                        <td className="px-3 py-2.5 font-mono-tabular text-slate-200">{p.shooting}</td>
                        <td className="px-3 py-2.5 font-mono-tabular text-slate-200">{p.passing}</td>
                        <td className="px-3 py-2.5 font-mono-tabular text-slate-200">{p.dribbling}</td>
                        <td className="px-3 py-2.5 font-mono-tabular text-slate-200">{p.defending}</td>
                        <td className="px-3 py-2.5 font-mono-tabular text-slate-200">{p.physical}</td>
                        <td className="px-3 py-2.5 font-mono-tabular text-sky-300">{p.stamina}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === 'medical' && (
            <div className="space-y-6">
              {/* 4-Column Medical KPI Strip */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="rounded-xl border border-white/10 bg-[#111927] p-4">
                  <p className="text-xs text-slate-400">Active Squad Injuries</p>
                  <p
                    className={`font-mono-tabular text-2xl font-bold mt-1 ${
                      injuredPlayers.length > 0 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {injuredPlayers.length}
                  </p>
                </div>
                <div className="rounded-xl border border-white/10 bg-[#111927] p-4">
                  <p className="text-xs text-slate-400">Recovery Speed</p>
                  <p className="font-mono-tabular text-2xl font-bold text-emerald-400 mt-1">
                    {medicalMetrics.recoverySpeedMultiplier}x
                  </p>
                </div>
                <div className="rounded-xl border border-white/10 bg-[#111927] p-4">
                  <p className="text-xs text-slate-400">Injury Prevention</p>
                  <p className="font-mono-tabular text-2xl font-bold text-sky-400 mt-1">
                    -{medicalMetrics.injuryPreventionPct}%
                  </p>
                </div>
                <div className="rounded-xl border border-white/10 bg-[#111927] p-4">
                  <p className="text-xs text-slate-400">Weekly Medical Cost</p>
                  <p className="font-mono-tabular text-2xl font-bold text-amber-300 mt-1">
                    {formatCurrency(medicalMetrics.weeklyMedicalCost)}
                  </p>
                </div>
              </div>

              {/* Injured Players Treatment Room */}
              <div className="rounded-xl border border-white/10 bg-[#111927] overflow-hidden">
                <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-4 border-b border-white/10 bg-[#0E1624]">
                  <div className="flex items-center gap-2">
                    <HeartPulse className="w-4 h-4 text-rose-400" />
                    <h4 className="font-display text-lg font-bold text-white">
                      Treatment Room &amp; Rehabilitation Queue
                    </h4>
                  </div>
                  <span className="text-xs text-slate-400">
                    Healing rate advances every Matchweek &amp; Drill Session
                  </span>
                </div>

                {injuredPlayers.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-300">
                    All {userClub.roster.length} players in {userClub.name} are match fit. Hire medical specialists or upgrade your Medical Wing below to prevent heavy match/training knocks.
                  </div>
                ) : (
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#0B111B] text-slate-400 border-b border-white/10">
                      <tr>
                        <th className="px-4 py-3">Player</th>
                        <th className="px-3 py-3">Injury</th>
                        <th className="px-3 py-3">Severity</th>
                        <th className="px-3 py-3">Origin</th>
                        <th className="px-3 py-3">Time Remaining</th>
                        <th className="px-3 py-3">Week Progress</th>
                        <th className="px-4 py-3 text-right">Targeted Therapy</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {injuredPlayers.map((p) => {
                        const inj = p.injury!;
                        return (
                          <tr key={p.id} className="hover:bg-white/[0.03]">
                            <td className="px-4 py-3 font-medium text-white">
                              #{p.number} {p.name}{' '}
                              <span className="text-slate-400">({p.position} · {p.ovr})</span>
                            </td>
                            <td className="px-3 py-3 text-slate-200">{inj.type}</td>
                            <td className="px-3 py-3 font-semibold">
                              <span
                                className={
                                  inj.severity === 'Severe'
                                    ? 'text-rose-400'
                                    : inj.severity === 'Moderate'
                                      ? 'text-amber-300'
                                      : 'text-sky-300'
                                }
                              >
                                {inj.severity}
                              </span>
                            </td>
                            <td className="px-3 py-3 text-slate-400">
                              {inj.source} (Wk {inj.occurredWeek})
                            </td>
                            <td className="px-3 py-3 font-mono-tabular font-bold text-white">
                              {inj.weeksRemaining} {inj.weeksRemaining === 1 ? 'week' : 'weeks'}
                            </td>
                            <td className="px-3 py-3 w-40">
                              <div className="flex items-center gap-2">
                                <div className="flex-1 h-2 rounded-full bg-white/10 overflow-hidden">
                                  <div
                                    className="h-full bg-emerald-400"
                                    style={{ width: `${inj.recoveryProgress}%` }}
                                  />
                                </div>
                                <span className="font-mono-tabular text-[11px] text-slate-300">
                                  {inj.recoveryProgress}%
                                </span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <button
                                disabled={userClub.transferBudget < fastTrackFee}
                                onClick={() => onFastTrackRehab(p.id)}
                                className="px-3 py-1.5 rounded bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-400 text-slate-950 font-bold text-[11px] whitespace-nowrap"
                              >
                                Fast-Track ({formatCurrency(fastTrackFee)})
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Medical Wing Upgrade & Club Recovery Protocol */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-emerald-400" />
                      <h4 className="font-display text-lg font-bold text-white">
                        Club Medical Center
                      </h4>
                    </div>
                    <span className="font-mono-tabular text-xs font-bold text-emerald-400">
                      Tier {medicalTier}/5
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Upgrading your medical laboratory installs MRI diagnostics, hydrotherapy pools, and biomechanical load sensors. Each tier adds <span className="font-mono-tabular text-white font-semibold">+25%</span> recovery speed and <span className="font-mono-tabular text-white font-semibold">+6%</span> injury prevention.
                  </p>
                  <button
                    disabled={medicalTier >= 5 || userClub.transferBudget < medicalUpgradeCost}
                    onClick={() => onUpgradeFacility('medical')}
                    className="w-full py-2.5 rounded-lg bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-400 text-slate-950 font-bold text-xs"
                  >
                    {medicalTier >= 5
                      ? 'Max Medical Center Tier Reached'
                      : `Upgrade Medical Center (${formatCurrency(medicalUpgradeCost)})`}
                  </button>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-3">
                  <div className="flex items-center gap-2">
                    <Stethoscope className="w-4 h-4 text-sky-400" />
                    <h4 className="font-display text-lg font-bold text-white">
                      Recovery Protocol
                    </h4>
                  </div>
                  <div className="space-y-2">
                    {(Object.keys(TREATMENT_PROTOCOLS) as TreatmentProtocol[]).map((proto) => {
                      const info = TREATMENT_PROTOCOLS[proto];
                      const active = (manager.medicalProtocol || 'Standard Care') === proto;
                      return (
                        <button
                          key={proto}
                          onClick={() => onSetMedicalProtocol(proto)}
                          className={`w-full text-left px-3.5 py-2.5 rounded-lg border text-xs transition-colors flex items-center justify-between gap-3 ${
                            active
                              ? 'bg-sky-500/20 border-sky-400 text-white'
                              : 'bg-[#0B111B] border-white/10 text-slate-300 hover:border-white/25'
                          }`}
                        >
                          <div>
                            <div className="font-semibold text-white">{proto}</div>
                            <div className="text-[11px] text-slate-400 mt-0.5">{info.summary}</div>
                          </div>
                          <span className="font-mono-tabular font-semibold text-amber-300 shrink-0">
                            {info.weeklyCost > 0 ? `${formatCurrency(info.weeklyCost)}/wk` : 'Free'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Medical Staff Directory */}
              <div className="rounded-xl border border-white/10 bg-[#111927] overflow-hidden">
                <div className="px-5 py-4 border-b border-white/10 bg-[#0E1624] flex items-center justify-between">
                  <h4 className="font-display text-lg font-bold text-white">
                    Medical Staff Directory ({medicalMetrics.hiredStaff.length}/{manager.medicalStaff.length} Active)
                  </h4>
                  <span className="text-xs text-slate-400">
                    Hire specialists to cut recovery weeks and reduce fatigue injuries
                  </span>
                </div>
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#0B111B] text-slate-400 border-b border-white/10">
                    <tr>
                      <th className="px-4 py-3">Specialist</th>
                      <th className="px-3 py-3">Role &amp; Focus</th>
                      <th className="px-3 py-3">Recovery Boost</th>
                      <th className="px-3 py-3">Injury Shield</th>
                      <th className="px-3 py-3">Salary / Wk</th>
                      <th className="px-4 py-3 text-right">Contract</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {(manager.medicalStaff || []).map((staff) => {
                      const canHire = userClub.transferBudget >= staff.hireCost;
                      return (
                        <tr key={staff.id} className="hover:bg-white/[0.03]">
                          <td className="px-4 py-3 font-medium text-white">
                            <div>{staff.name}</div>
                            <div className="text-[10px] text-amber-300 font-mono-tabular">
                              {'★'.repeat(staff.starRating)}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <div className="text-slate-200 font-medium">{staff.role}</div>
                            <div className="text-[11px] text-slate-400">{staff.specialty}</div>
                          </td>
                          <td className="px-3 py-3 font-mono-tabular font-bold text-emerald-400">
                            +{staff.recoveryBoostPct}%
                          </td>
                          <td className="px-3 py-3 font-mono-tabular font-semibold text-sky-300">
                            -{staff.preventionPct}% risk
                          </td>
                          <td className="px-3 py-3 font-mono-tabular text-amber-300">
                            {formatCurrency(staff.weeklySalary)}
                          </td>
                          <td className="px-4 py-3 text-right">
                            {staff.hired ? (
                              <button
                                onClick={() => onToggleMedicalStaff(staff.id)}
                                className="px-3 py-1.5 rounded border border-white/15 bg-white/5 text-slate-200 hover:bg-rose-500/20 hover:border-rose-400/50 hover:text-rose-200 font-semibold text-[11px]"
                              >
                                Release
                              </button>
                            ) : (
                              <button
                                disabled={!canHire}
                                onClick={() => onToggleMedicalStaff(staff.id)}
                                className="px-3 py-1.5 rounded bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-400 text-slate-950 font-bold text-[11px]"
                              >
                                Hire ({formatCurrency(staff.hireCost)})
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Recent Injury & Recovery Report Log */}
              {manager.injuryReportLog && manager.injuryReportLog.length > 0 && (
                <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-3">
                  <h4 className="font-display text-lg font-bold text-white">
                    Medical Incident &amp; Recovery Log
                  </h4>
                  <div className="divide-y divide-white/5 max-h-40 overflow-y-auto text-xs">
                    {manager.injuryReportLog.map((entry) => (
                      <div key={entry.id} className="py-2 flex items-center justify-between gap-4">
                        <span className="text-slate-200">
                          <span className="font-mono-tabular text-slate-400 mr-2">
                            Wk {entry.week}
                          </span>
                          <span className="font-semibold text-white">{entry.playerName}</span> ·{' '}
                          {entry.injuryType} ({entry.severity}) · {entry.source}
                        </span>
                        <span
                          className={`font-semibold shrink-0 ${
                            entry.event === 'Recovered' ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {entry.event === 'Recovered'
                            ? 'Cleared Fit'
                            : `Out ${entry.weeksOut || 1}w`}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {tab === 'transfers' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Transfer Market */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    placeholder="Search global players..."
                    value={marketSearch}
                    onChange={(e) => setMarketSearch(e.target.value)}
                    className="flex-1 min-w-[180px] rounded-lg border border-white/10 bg-[#111927] px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                  <select
                    value={marketLeague}
                    onChange={(e) => setMarketLeague(e.target.value)}
                    className="rounded-lg border border-white/10 bg-[#111927] px-3 py-2 text-xs text-white"
                  >
                    <option value="all">All Leagues</option>
                    {LEAGUES.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name}
                      </option>
                    ))}
                  </select>
                  <select
                    value={marketPos}
                    onChange={(e) => setMarketPos(e.target.value as 'ALL' | Position)}
                    className="rounded-lg border border-white/10 bg-[#111927] px-3 py-2 text-xs text-white"
                  >
                    <option value="ALL">All Pos</option>
                    <option value="GK">GK</option>
                    <option value="DEF">DEF</option>
                    <option value="MID">MID</option>
                    <option value="FWD">FWD</option>
                  </select>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#111927] overflow-hidden max-h-[55vh] overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#0B111B] text-slate-400 border-b border-white/10 sticky top-0">
                      <tr>
                        <th className="px-4 py-3">Player</th>
                        <th className="px-3 py-3">Club</th>
                        <th className="px-3 py-3">Pos</th>
                        <th className="px-3 py-3">OVR</th>
                        <th className="px-3 py-3">Fee</th>
                        <th className="px-3 py-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {transferTargets.map(({ club, player }) => {
                        const canAfford =
                          userClub.transferBudget >= player.marketValue &&
                          userClub.roster.length < 28;
                        return (
                          <tr key={player.id} className="hover:bg-white/[0.03]">
                            <td className="px-4 py-2.5 font-medium text-white">
                              {player.name}{' '}
                              <span className="text-slate-500">({player.age})</span>
                            </td>
                            <td className="px-3 py-2.5 text-slate-300">{club.shortName}</td>
                            <td className="px-3 py-2.5 text-slate-400">{player.position}</td>
                            <td className="px-3 py-2.5 font-mono-tabular font-bold text-emerald-400">
                              {player.ovr}
                            </td>
                            <td className="px-3 py-2.5 font-mono-tabular text-white">
                              {formatCurrency(player.marketValue)}
                            </td>
                            <td className="px-3 py-2.5 text-right">
                              <button
                                disabled={!canAfford}
                                onClick={() => onBuyPlayer(club.id, player.id)}
                                className="px-3 py-1 rounded bg-emerald-500 disabled:bg-slate-700 disabled:text-slate-400 text-slate-950 font-bold text-[11px]"
                              >
                                Sign
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Sell Squad Players & Financial Ledger */}
              <div className="space-y-4">
                <div className="rounded-xl border border-white/10 bg-[#111927] p-4 space-y-3">
                  <h4 className="font-display text-lg font-bold text-white">
                    Sell Players ({userClub.roster.length}/28)
                  </h4>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto">
                    {userClub.roster.map((p) => (
                      <div
                        key={p.id}
                        className="flex items-center justify-between px-3 py-2 rounded-lg bg-[#0B111B] text-xs"
                      >
                        <div className="truncate pr-2">
                          <span className="text-white font-medium">{p.name}</span>
                          <span className="text-slate-400 ml-1.5">
                            {p.position} · {p.ovr}
                          </span>
                        </div>
                        <button
                          disabled={userClub.roster.length <= 13 || p.isCreatedStar}
                          onClick={() => onSellPlayer(p.id)}
                          className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 disabled:opacity-40 font-mono-tabular text-[11px] shrink-0"
                        >
                          Sell {formatCurrency(p.marketValue)}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#111927] p-4 space-y-2">
                  <h4 className="font-display text-lg font-bold text-white">
                    Financial Ledger
                  </h4>
                  <div className="space-y-1.5 max-h-44 overflow-y-auto text-xs">
                    {manager.ledger.map((entry) => (
                      <div
                        key={entry.id}
                        className="flex items-center justify-between border-b border-white/5 pb-1.5"
                      >
                        <span className="text-slate-300 truncate pr-2">
                          W{entry.week} · {entry.description}
                        </span>
                        <span
                          className={`font-mono-tabular font-semibold shrink-0 ${
                            entry.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {entry.amount >= 0 ? '+' : ''}
                          {formatCurrency(entry.amount)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === 'standings' && (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {LEAGUES.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => setStandingsLeagueId(l.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      standingsLeagueId === l.id
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-[#111927] text-slate-300 hover:text-white'
                    }`}
                  >
                    {l.name}
                  </button>
                ))}
              </div>

              <div className="rounded-xl border border-white/10 bg-[#111927] overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#0B111B] text-slate-400 border-b border-white/10">
                    <tr>
                      <th className="px-4 py-3">#</th>
                      <th className="px-3 py-3">Club</th>
                      <th className="px-3 py-3">P</th>
                      <th className="px-3 py-3">W</th>
                      <th className="px-3 py-3">D</th>
                      <th className="px-3 py-3">L</th>
                      <th className="px-3 py-3">GF</th>
                      <th className="px-3 py-3">GA</th>
                      <th className="px-3 py-3">GD</th>
                      <th className="px-3 py-3">Pts</th>
                      <th className="px-3 py-3">Form</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {sortStandings(manager.standingsByLeague[standingsLeagueId] || []).map(
                      (row, idx) => {
                        const c = clubs[row.clubId];
                        const isMine = row.clubId === manager.clubId;
                        return (
                          <tr
                            key={row.clubId}
                            className={isMine ? 'bg-emerald-500/10' : 'hover:bg-white/[0.03]'}
                          >
                            <td className="px-4 py-3 font-mono-tabular text-slate-400">
                              {idx + 1}
                            </td>
                            <td className="px-3 py-3 font-semibold text-white">
                              <span
                                className="inline-block w-2.5 h-2.5 rounded-sm mr-2"
                                style={{ backgroundColor: c?.homeKit.primary }}
                              />
                              {c?.name}
                            </td>
                            <td className="px-3 py-3 font-mono-tabular">{row.played}</td>
                            <td className="px-3 py-3 font-mono-tabular">{row.won}</td>
                            <td className="px-3 py-3 font-mono-tabular">{row.drawn}</td>
                            <td className="px-3 py-3 font-mono-tabular">{row.lost}</td>
                            <td className="px-3 py-3 font-mono-tabular">{row.gf}</td>
                            <td className="px-3 py-3 font-mono-tabular">{row.ga}</td>
                            <td className="px-3 py-3 font-mono-tabular">
                              {row.gf - row.ga}
                            </td>
                            <td className="px-3 py-3 font-mono-tabular font-bold text-emerald-400">
                              {row.points}
                            </td>
                            <td className="px-3 py-3 font-mono-tabular text-slate-300">
                              {row.form.join(' ') || '—'}
                            </td>
                          </tr>
                        );
                      }
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === 'ai_coach' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="rounded-xl border border-white/10 bg-[#111927] p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-display text-xl font-bold text-white">
                      AI Tactical Briefing
                    </h4>
                    <p className="text-xs text-slate-400">
                      Live opponent scouting & formation tuning for {userClub.name}
                    </p>
                  </div>
                  <button
                    disabled={coachLoading}
                    onClick={runAICoachAnalysis}
                    className="px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 disabled:opacity-50"
                  >
                    {coachLoading ? 'Analyzing...' : 'Generate Tactical Plan'}
                  </button>
                </div>

                {coachError && (
                  <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-300">
                    {coachError}
                  </div>
                )}

                {coachAnalysis ? (
                  <div className="space-y-3 text-xs">
                    <div className="rounded-lg border border-emerald-500/20 bg-[#0B111B] p-4 space-y-2">
                      <h5 className="font-display text-lg font-bold text-emerald-400">
                        {coachAnalysis.headline}
                      </h5>
                      <p className="text-slate-200 leading-relaxed">
                        {coachAnalysis.tacticalSummary}
                      </p>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="rounded-lg bg-[#0B111B] p-3">
                        <span className="text-slate-400 block">Recommended Shape</span>
                        <span className="font-mono-tabular font-bold text-white">
                          {coachAnalysis.recommendedFormation} · {coachAnalysis.recommendedMentality}
                        </span>
                      </div>
                      <div className="rounded-lg bg-[#0B111B] p-3">
                        <span className="text-slate-400 block">Press & Training</span>
                        <span className="font-semibold text-white">
                          {coachAnalysis.recommendedPressing} · {coachAnalysis.recommendedTrainingFocus}
                        </span>
                      </div>
                    </div>
                    <ul className="space-y-1 text-slate-300 list-disc pl-4">
                      {coachAnalysis.keyInstructions.map((ins, i) => (
                        <li key={i}>{ins}</li>
                      ))}
                    </ul>
                    <p className="text-slate-400 italic">{coachAnalysis.scoutingNote}</p>
                    <button
                      onClick={() => {
                        onUpdateTactics({
                          ...manager.tactics,
                          formation: coachAnalysis.recommendedFormation,
                          mentality: coachAnalysis.recommendedMentality,
                          pressing: coachAnalysis.recommendedPressing,
                          passingStyle: coachAnalysis.recommendedPassing,
                        });
                        onSetTrainingFocus(coachAnalysis.recommendedTrainingFocus);
                      }}
                      className="w-full py-2.5 rounded-lg bg-sky-500 text-slate-950 font-bold hover:bg-sky-400 transition-colors"
                    >
                      Apply Recommended Tactics & Training
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">
                    Click &ldquo;Generate Tactical Plan&rdquo; to analyze your squad fitness, formation fit, and upcoming fixture against {nextOpponent?.name || 'league rivals'}.
                  </p>
                )}
              </div>

              {/* Interactive AI Coach Chat */}
              <div className="rounded-xl border border-white/10 bg-[#111927] p-5 flex flex-col h-[420px]">
                <h4 className="font-display text-xl font-bold text-white mb-3">
                  Ask Assistant Coach
                </h4>
                <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 mb-3">
                  {coachMessages.map((m, i) => (
                    <div
                      key={i}
                      className={`rounded-lg px-3.5 py-2.5 text-xs leading-relaxed ${
                        m.role === 'user'
                          ? 'bg-emerald-500/20 text-emerald-100 ml-8'
                          : 'bg-[#0B111B] text-slate-200 mr-8 border border-white/10'
                      }`}
                    >
                      {m.text}
                    </div>
                  ))}
                </div>
                <form onSubmit={sendCoachChat} className="flex gap-2">
                  <input
                    type="text"
                    value={coachChatInput}
                    onChange={(e) => setCoachChatInput(e.target.value)}
                    placeholder="Ask about pressing, transfers, or training..."
                    className="flex-1 rounded-lg border border-white/10 bg-[#0B111B] px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="submit"
                    disabled={coachLoading}
                    className="px-3.5 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 disabled:opacity-50"
                    aria-label="Send message to AI Coach"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
