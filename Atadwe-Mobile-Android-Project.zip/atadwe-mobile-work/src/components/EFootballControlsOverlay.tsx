import React, { useRef, useState } from 'react';
import { Repeat, Zap } from 'lucide-react';

interface EFootballControlsOverlayProps {
  isDefending: boolean;
  shotPower: number;
  onStickMove: (dx: number, dz: number) => void;
  onSprintChange: (sprinting: boolean) => void;
  onStartShot: () => void;
  onReleaseShot: () => void;
  onAction: (
    action: 'pass' | 'through' | 'shoot' | 'lob' | 'switch' | 'tackle' | 'press' | 'matchup' | 'clear'
  ) => void;
}

export const EFootballControlsOverlay: React.FC<EFootballControlsOverlayProps> = ({
  isDefending,
  shotPower,
  onStickMove,
  onSprintChange,
  onStartShot,
  onReleaseShot,
  onAction,
}) => {
  const padRef = useRef<HTMLDivElement | null>(null);
  const activePointerId = useRef<number | null>(null);
  const [knob, setKnob] = useState<{ x: number; y: number; active: boolean }>({
    x: 0,
    y: 0,
    active: false,
  });
  const [dashHeld, setDashHeld] = useState(false);

  const updateStickFromEvent = (clientX: number, clientY: number) => {
    const el = padRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const maxRadius = Math.max(46, rect.width * 0.34);
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }
    setKnob({ x: dx, y: dy, active: true });
    onStickMove(dx / maxRadius, dy / maxRadius);
  };

  const resetStick = () => {
    activePointerId.current = null;
    setKnob({ x: 0, y: 0, active: false });
    onStickMove(0, 0);
  };

  const currentMaxRadius = Math.max(46, (padRef.current?.clientWidth || 168) * 0.34);
  const stickAngle = Math.atan2(knob.y, knob.x) * (180 / Math.PI) + 90;
  const stickMag = Math.hypot(knob.x, knob.y) / currentMaxRadius;
  const chargeStroke = Math.round(shotPower * 164);

  return (
    <div className="fixed inset-x-0 bottom-0 z-10 pointer-events-none flex items-end justify-between px-3 pb-3 sm:px-8 sm:pb-6">
      {/* Left Thumb Zone: Big eFootball Dynamic Analog Stick */}
      <div
        ref={padRef}
        onPointerDown={(e) => {
          e.preventDefault();
          activePointerId.current = e.pointerId;
          e.currentTarget.setPointerCapture(e.pointerId);
          updateStickFromEvent(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (activePointerId.current !== e.pointerId) return;
          updateStickFromEvent(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (activePointerId.current === e.pointerId) {
            e.currentTarget.releasePointerCapture(e.pointerId);
            resetStick();
          }
        }}
        onPointerCancel={resetStick}
        className="pointer-events-auto touch-none relative w-[156px] h-[156px] sm:w-[216px] sm:h-[216px] rounded-full border-[3px] border-white/25 bg-[#0B111B]/80 flex items-center justify-center shadow-2xl cursor-grab active:cursor-grabbing"
        aria-label="Virtual Movement Stick"
      >
        {/* Crosshair guides */}
        <div className="absolute inset-4 sm:inset-5 rounded-full border border-white/15 pointer-events-none" />
        <div className="absolute w-px h-28 sm:h-36 bg-white/15 pointer-events-none" />
        <div className="absolute h-px w-28 sm:w-36 bg-white/15 pointer-events-none" />

        {/* Directional arc indicator when tilted */}
        {stickMag > 0.15 && (
          <div
            className="absolute inset-0 rounded-full border-t-[5px] border-emerald-400/95 pointer-events-none"
            style={{ transform: `rotate(${stickAngle}deg)` }}
          />
        )}

        {/* Analog Thumb Puck */}
        <div
          className={`w-[58px] h-[58px] sm:w-[82px] sm:h-[82px] rounded-full border-2 shadow-lg transition-colors pointer-events-none flex items-center justify-center ${
            stickMag > 0.85
              ? 'bg-emerald-400 border-white text-slate-950'
              : knob.active
                ? 'bg-slate-200 border-emerald-400 text-slate-950'
                : 'bg-[#182234] border-white/45 text-white/75'
          }`}
          style={{
            transform: `translate3d(${knob.x}px, ${knob.y}px, 0)`,
          }}
        >
          <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-current opacity-75" />
        </div>
      </div>

      {/* Right Thumb Zone: Big Authentic eFootball Curved 4-Button Arc */}
      <div className="pointer-events-auto relative w-[206px] h-[196px] sm:w-[340px] sm:h-[268px] touch-none select-none">
        {/* Top Utility: Player Switch / Lob Chip */}
        <button
          onClick={() => onAction(isDefending ? 'matchup' : 'switch')}
          className="absolute right-0 top-0 w-14 h-14 sm:w-[68px] sm:h-[68px] rounded-full border-2 border-white/30 bg-[#0B111B]/85 text-slate-100 hover:border-emerald-400 active:scale-95 transition-transform flex flex-col items-center justify-center shadow-lg"
          title="Switch Player (Q)"
        >
          <Repeat className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" />
          <span className="text-[10px] sm:text-xs font-bold tracking-wider uppercase mt-0.5">
            Switch
          </span>
        </button>

        {/* Top-Left of Arc: SHOOT (Attack) / CLEAR-SLIDE (Defense) */}
        {isDefending ? (
          <button
            onClick={() => onAction('clear')}
            className="absolute right-[62px] sm:right-[90px] top-0 w-[72px] h-[72px] sm:w-[90px] sm:h-[90px] rounded-full border-2 border-rose-400/85 bg-[#1B1018]/90 text-white hover:bg-rose-500/25 active:scale-95 transition-transform flex flex-col items-center justify-center shadow-xl"
          >
            <span className="font-display text-base sm:text-lg font-extrabold tracking-wide uppercase">
              Clear
            </span>
            <span className="text-[10px] sm:text-[11px] text-rose-300 font-semibold uppercase">
              Slide
            </span>
          </button>
        ) : (
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              e.currentTarget.setPointerCapture(e.pointerId);
              onStartShot();
            }}
            onPointerUp={(e) => {
              e.currentTarget.releasePointerCapture(e.pointerId);
              onReleaseShot();
            }}
            onPointerCancel={onReleaseShot}
            className="absolute right-[62px] sm:right-[90px] top-0 w-[72px] h-[72px] sm:w-[90px] sm:h-[90px] rounded-full border-2 border-rose-400/85 bg-[#1B1018]/90 text-white hover:bg-rose-500/25 active:scale-95 transition-transform flex flex-col items-center justify-center shadow-xl"
          >
            <svg
              className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none"
              viewBox="0 0 60 60"
            >
              <circle
                cx="30"
                cy="30"
                r="26"
                fill="none"
                stroke="#FB7185"
                strokeWidth="3.5"
                strokeDasharray={`${chargeStroke} 200`}
              />
            </svg>
            <span className="font-display text-base sm:text-lg font-extrabold tracking-wide uppercase">
              Shoot
            </span>
            <span className="text-[10px] sm:text-[11px] text-rose-300 font-semibold uppercase">
              Hold
            </span>
          </button>
        )}

        {/* Mid-Left of Arc: THROUGH (Attack) / MATCH-UP (Defense) */}
        <button
          onClick={() => onAction(isDefending ? 'matchup' : 'through')}
          className="absolute right-[132px] sm:right-[202px] top-[56px] sm:top-[82px] w-[70px] h-[70px] sm:w-[84px] sm:h-[84px] rounded-full border-2 border-amber-400/85 bg-[#19160E]/90 text-white hover:bg-amber-500/25 active:scale-95 transition-transform flex flex-col items-center justify-center shadow-xl"
        >
          <span className="font-display text-sm sm:text-base font-extrabold tracking-wide uppercase leading-tight">
            {isDefending ? 'Match' : 'Through'}
          </span>
          <span className="text-[10px] sm:text-[11px] text-amber-300 font-semibold uppercase">
            {isDefending ? 'Jockey' : 'Ball'}
          </span>
        </button>

        {/* Bottom-Left of Arc: PASS (Attack) / PRESS (Defense) */}
        <button
          onClick={() => onAction(isDefending ? 'press' : 'pass')}
          className="absolute right-[84px] sm:right-[114px] bottom-0 w-[70px] h-[70px] sm:w-[84px] sm:h-[84px] rounded-full border-2 border-sky-400/85 bg-[#0E1826]/90 text-white hover:bg-sky-500/25 active:scale-95 transition-transform flex flex-col items-center justify-center shadow-xl"
        >
          <span className="font-display text-base sm:text-lg font-extrabold tracking-wide uppercase">
            {isDefending ? 'Press' : 'Pass'}
          </span>
          <span className="text-[10px] sm:text-[11px] text-sky-300 font-semibold uppercase">
            {isDefending ? 'Tackle' : 'Short'}
          </span>
        </button>

        {/* Primary Bottom-Right Anchor: DASH (Sprint) */}
        <button
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            setDashHeld(true);
            onSprintChange(true);
          }}
          onPointerUp={(e) => {
            e.currentTarget.releasePointerCapture(e.pointerId);
            setDashHeld(false);
            onSprintChange(false);
          }}
          onPointerCancel={() => {
            setDashHeld(false);
            onSprintChange(false);
          }}
          className={`absolute right-0 bottom-0 w-[78px] h-[78px] sm:w-[98px] sm:h-[98px] rounded-full border-2 transition-transform flex flex-col items-center justify-center shadow-2xl ${
            dashHeld
              ? 'border-white bg-emerald-400 text-slate-950 scale-95'
              : 'border-emerald-400/90 bg-[#0B1C19]/90 text-white hover:bg-emerald-500/25'
          }`}
        >
          <Zap className="w-6 h-6 sm:w-7 sm:h-7" />
          <span className="font-display text-base sm:text-lg font-extrabold tracking-wide uppercase">
            Dash
          </span>
        </button>
      </div>
    </div>
  );
};
