import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Club, CreatedPlayerProfile } from '../types/game';
import {
  createContactShadowTexture,
  createFootballerRig,
} from '../game/ProceduralAssets';

interface PlayerPreview3DProps {
  profile: CreatedPlayerProfile;
  club: Club;
  kitVariant: 'home' | 'away' | 'training';
  cameraFocus: 'full' | 'head';
}

export const PlayerPreview3D: React.FC<PlayerPreview3DProps> = ({
  profile,
  club,
  kitVariant,
  cameraFocus,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const rigRef = useRef<THREE.Group | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const shadowTexRef = useRef<THREE.CanvasTexture | null>(null);
  const ringMatRef = useRef<THREE.MeshBasicMaterial | null>(null);
  const requestRenderRef = useRef<() => void>(() => {});
  const yawRef = useRef<number>(0.32);
  const targetFocusRef = useRef<'full' | 'head'>(cameraFocus);
  const heightScaleRef = useRef<number>(profile.heightScale);
  const draggingRef = useRef<{ active: boolean; lastX: number }>({
    active: false,
    lastX: 0,
  });

  useEffect(() => {
    targetFocusRef.current = cameraFocus;
    heightScaleRef.current = profile.heightScale;
    requestRenderRef.current();
  }, [cameraFocus, profile.heightScale]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = (() => {
      const probe = document.createElement('canvas').getContext('webgl2');
      if (!probe) return true;
      const ext = probe.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const w = container.clientWidth || 320;
    const h = container.clientHeight || 340;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(w, h);
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#090E17');
    scene.fog = new THREE.FogExp2('#090E17', 0.04);
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(34, w / h, 0.1, 40);
    camera.position.set(0, 1.35, 3.6);
    camera.lookAt(0, 0.98, 0);
    cameraRef.current = camera;

    // 3-Point Studio Lighting Rig
    const hemi = new THREE.HemisphereLight(0xdbeafe, 0x064e3b, 0.85);
    scene.add(hemi);

    const key = new THREE.DirectionalLight(0xfffbeb, 2.3);
    key.position.set(2.8, 4.5, 3.2);
    key.castShadow = !isSoftwareGl;
    key.shadow.mapSize.set(512, 512);
    key.shadow.bias = -0.0005;
    key.shadow.normalBias = 0.02;
    scene.add(key);

    const rim = new THREE.DirectionalLight(0x38bdf8, 1.15);
    rim.position.set(-3.0, 2.6, -2.5);
    scene.add(rim);

    // Turf Display Plinth
    const plinth = new THREE.Mesh(
      new THREE.CylinderGeometry(1.18, 1.25, 0.12, 36),
      new THREE.MeshStandardMaterial({ color: '#14532D', roughness: 0.82, metalness: 0.05 })
    );
    plinth.position.y = -0.06;
    plinth.receiveShadow = true;
    scene.add(plinth);

    const ringMat = new THREE.MeshBasicMaterial({ color: club.homeKit.primary });
    ringMatRef.current = ringMat;
    const plinthTrim = new THREE.Mesh(
      new THREE.TorusGeometry(1.2, 0.022, 10, 48),
      ringMat
    );
    plinthTrim.rotation.x = Math.PI / 2;
    plinthTrim.position.y = 0.005;
    scene.add(plinthTrim);

    const shadowTex = createContactShadowTexture();
    shadowTexRef.current = shadowTex;

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let disposed = false;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const requestRender = () => {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;
        const focus = targetFocusRef.current;
        const hs = heightScaleRef.current;
        const desiredY = focus === 'head' ? 1.62 * hs : 1.32;
        const desiredZ = focus === 'head' ? 1.55 : 3.55;
        const lookY = focus === 'head' ? 1.55 * hs : 0.96;

        camera.position.set(0, desiredY, desiredZ);
        camera.lookAt(0, lookY, 0);

        if (rigRef.current) {
          rigRef.current.rotation.y = yawRef.current;
        }
        renderer.render(scene, camera);
        const done = () => {
          renderBusy = false;
          if (renderDirty && !disposed) requestRender();
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    };

    requestRenderRef.current = requestRender;

    const onResize = () => {
      if (!container || disposed) return;
      const nw = container.clientWidth || 320;
      const nh = container.clientHeight || 340;
      camera.aspect = nw / nh;
      camera.updateProjectionMatrix();
      renderer.setSize(nw, nh);
      requestRender();
    };
    window.addEventListener('resize', onResize);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', onResize);
      if (rigRef.current) {
        scene.remove(rigRef.current);
      }
      shadowTex.dispose();
      scene.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) {
            m.material.forEach((mat) => {
              const std = mat as THREE.MeshStandardMaterial;
              std.map?.dispose();
              mat.dispose();
            });
          } else if (m.material) {
            const std = m.material as THREE.MeshStandardMaterial;
            std.map?.dispose();
            m.material.dispose();
          }
        }
      });
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
    // Mounted once per modal open
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Rebuild footballer rig cleanly whenever appearance, kit, or height updates
  useEffect(() => {
    const scene = sceneRef.current;
    const shadowTex = shadowTexRef.current;
    if (!scene || !shadowTex) return;

    if (rigRef.current) {
      scene.remove(rigRef.current);
      rigRef.current.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) {
            m.material.forEach((mat) => {
              const std = mat as THREE.MeshStandardMaterial;
              if (std.map && std.map !== shadowTex) std.map.dispose();
              mat.dispose();
            });
          } else if (m.material) {
            const std = m.material as THREE.MeshStandardMaterial;
            if (std.map && std.map !== shadowTex) std.map.dispose();
            m.material.dispose();
          }
        }
      });
      rigRef.current = null;
    }

    const activeKit =
      kitVariant === 'away'
        ? club.awayKit
        : kitVariant === 'training'
          ? club.trainingKit
          : club.homeKit;

    ringMatRef.current?.color.set(activeKit.primary);

    const rig = createFootballerRig(
      activeKit,
      profile.skinTone,
      profile.hairColor,
      profile.number,
      shadowTex,
      profile.heightScale,
      {
        faceStyle: profile.faceStyle,
        hairStyle: profile.hairStyle,
        bodyType: profile.bodyType,
        bootColor: profile.bootColor,
      }
    );
    rig.group.rotation.y = yawRef.current;
    scene.add(rig.group);
    rigRef.current = rig.group;
    requestRenderRef.current();
  }, [
    club,
    kitVariant,
    profile.skinTone,
    profile.hairColor,
    profile.number,
    profile.heightScale,
    profile.faceStyle,
    profile.hairStyle,
    profile.bodyType,
    profile.bootColor,
  ]);

  return (
    <div
      ref={mountRef}
      onPointerDown={(e) => {
        draggingRef.current = { active: true, lastX: e.clientX };
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      }}
      onPointerMove={(e) => {
        if (!draggingRef.current.active) return;
        const dx = e.clientX - draggingRef.current.lastX;
        draggingRef.current.lastX = e.clientX;
        yawRef.current += dx * 0.015;
        requestRenderRef.current();
      }}
      onPointerUp={(e) => {
        draggingRef.current.active = false;
        try {
          (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
        } catch {
          // ignore if pointer already released
        }
      }}
      onPointerCancel={() => {
        draggingRef.current.active = false;
      }}
      className="w-full h-72 md:h-80 rounded-lg border border-white/10 bg-[#090E17] cursor-grab active:cursor-grabbing overflow-hidden touch-none"
      title="Drag horizontally to rotate 3D player"
    />
  );
};
