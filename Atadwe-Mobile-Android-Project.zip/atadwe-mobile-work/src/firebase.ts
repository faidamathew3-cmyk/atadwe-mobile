import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  getDocs,
  collection,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import {
  CreatedPlayerProfile,
  LeaderboardEntry,
  ManagerState,
  Platform,
} from './types/game';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export const OperationType = {
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  LIST: 'list',
  GET: 'get',
  WRITE: 'write',
} as const;

export type OperationTypeValue = (typeof OperationType)[keyof typeof OperationType];

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationTypeValue;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationTypeValue,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validate connection on boot as required
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration: client is offline.');
      return false;
    }
    // Permission denied on default-deny test doc still proves live connectivity
    return true;
  }
}

void testConnection();

export function subscribeAuth(cb: (user: User | null) => void) {
  return onAuthStateChanged(auth, cb);
}

export async function signInWithGoogle(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function signOutUser(): Promise<void> {
  await signOut(auth);
}

export interface CloudSaveRecord {
  saveId: string;
  ownerId: string;
  slotName: string;
  platform: Platform;
  clubId: string;
  seasonNumber: number;
  currentWeek: number;
  transferBudget: number;
  wageBudget: number;
  stadiumLevel: number;
  gymLevel: number;
  medicalLevel?: number;
  medicalProtocol?: ManagerState['medicalProtocol'];
  formation: ManagerState['tactics']['formation'];
  mentality: ManagerState['tactics']['mentality'];
  pressing: ManagerState['tactics']['pressing'];
  passingStyle: ManagerState['tactics']['passingStyle'];
  createdPlayer: {
    name: string;
    position: CreatedPlayerProfile['position'];
    secondaryPosition?: CreatedPlayerProfile['secondaryPosition'];
    number: number;
    age?: number;
    preferredFoot?: CreatedPlayerProfile['preferredFoot'];
    ovr: number;
    pace: number;
    shooting: number;
    passing: number;
    dribbling: number;
    defending: number;
    physical: number;
    skinTone: string;
    hairColor: string;
    faceStyle?: CreatedPlayerProfile['faceStyle'];
    hairStyle?: CreatedPlayerProfile['hairStyle'];
    bodyType?: CreatedPlayerProfile['bodyType'];
    bootColor?: string;
    heightScale?: number;
    playstyle?: CreatedPlayerProfile['playstyle'];
    traits?: CreatedPlayerProfile['traits'];
  };
  squadIds: string[];
  hiredMedicalIds?: string[];
  injuredSummary?: string[];
  trophies: string[];
  careerStats: ManagerState['careerStats'];
  updatedAt?: Timestamp;
}

export async function upsertUserProfile(
  uid: string,
  displayName: string,
  platform: Platform,
  activeClubId: string
): Promise<void> {
  const path = `users/${uid}`;
  const ref = doc(db, 'users', uid);
  try {
    const existingSnap = await getDoc(ref);
    if (existingSnap.exists()) {
      await setDoc(
        ref,
        {
          uid,
          displayName: displayName.slice(0, 64) || 'Manager',
          platform,
          activeClubId,
          createdAt: existingSnap.data().createdAt,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
    } else {
      await setDoc(ref, {
        uid,
        displayName: displayName.slice(0, 64) || 'Manager',
        platform,
        activeClubId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function saveCareerToCloud(params: {
  uid: string;
  displayName: string;
  saveId: string;
  slotName: string;
  platform: Platform;
  manager: ManagerState;
  transferBudget: number;
  wageBudget: number;
  stadiumTier: number;
  gymTier: number;
  medicalTier?: number;
  injuredSummary?: string[];
  squadIds: string[];
  createdPlayer: CreatedPlayerProfile;
}): Promise<void> {
  const {
    uid,
    displayName,
    saveId,
    slotName,
    platform,
    manager,
    transferBudget,
    wageBudget,
    stadiumTier,
    gymTier,
    medicalTier = 1,
    injuredSummary = [],
    squadIds,
    createdPlayer,
  } = params;

  await upsertUserProfile(uid, displayName, platform, manager.clubId);

  const path = `users/${uid}/saves/${saveId}`;
  const ref = doc(db, 'users', uid, 'saves', saveId);

  try {
    const existingSnap = await getDoc(ref);
    const payload = {
      saveId,
      ownerId: uid,
      slotName: slotName.slice(0, 64) || 'Career Slot',
      platform,
      clubId: manager.clubId,
      seasonNumber: Math.max(1, Math.min(100, Math.round(manager.seasonNumber))),
      currentWeek: Math.max(1, Math.min(60, Math.round(manager.currentWeek))),
      transferBudget: Math.max(0, Math.min(2_000_000_000, Math.round(transferBudget))),
      wageBudget: Math.max(0, Math.min(50_000_000, Math.round(wageBudget))),
      stadiumLevel: Math.max(1, Math.min(5, Math.round(stadiumTier))),
      gymLevel: Math.max(1, Math.min(5, Math.round(gymTier))),
      medicalLevel: Math.max(1, Math.min(5, Math.round(medicalTier))),
      medicalProtocol: manager.medicalProtocol || 'Standard Care',
      formation: manager.tactics.formation,
      mentality: manager.tactics.mentality,
      pressing: manager.tactics.pressing,
      passingStyle: manager.tactics.passingStyle,
      createdPlayer: {
        name: createdPlayer.name.slice(0, 48) || 'Alex Mercer',
        position: createdPlayer.position,
        secondaryPosition: createdPlayer.secondaryPosition ?? null,
        number: Math.max(1, Math.min(99, Math.round(createdPlayer.number))),
        age: Math.max(16, Math.min(45, Math.round(createdPlayer.age))),
        preferredFoot: createdPlayer.preferredFoot,
        ovr: Math.max(40, Math.min(99, Math.round(createdPlayer.ovr))),
        pace: Math.max(30, Math.min(99, Math.round(createdPlayer.pace))),
        shooting: Math.max(30, Math.min(99, Math.round(createdPlayer.shooting))),
        passing: Math.max(30, Math.min(99, Math.round(createdPlayer.passing))),
        dribbling: Math.max(30, Math.min(99, Math.round(createdPlayer.dribbling))),
        defending: Math.max(30, Math.min(99, Math.round(createdPlayer.defending))),
        physical: Math.max(30, Math.min(99, Math.round(createdPlayer.physical))),
        skinTone: createdPlayer.skinTone.slice(0, 16),
        hairColor: createdPlayer.hairColor.slice(0, 16),
        faceStyle: createdPlayer.faceStyle,
        hairStyle: createdPlayer.hairStyle,
        bodyType: createdPlayer.bodyType,
        bootColor: createdPlayer.bootColor.slice(0, 16),
        heightScale: Math.max(0.85, Math.min(1.15, Number(createdPlayer.heightScale.toFixed(2)))),
        playstyle: createdPlayer.playstyle.slice(0, 48),
        traits: (createdPlayer.traits || []).slice(0, 3),
      },
      squadIds: squadIds.slice(0, 30),
      hiredMedicalIds: (manager.medicalStaff || [])
        .filter((s) => s.hired)
        .map((s) => s.id.slice(0, 48))
        .slice(0, 8),
      injuredSummary: injuredSummary.map((s) => s.slice(0, 96)).slice(0, 28),
      trophies: manager.trophies.slice(0, 20),
      careerStats: {
        matchesPlayed: Math.max(0, Math.round(manager.careerStats.matchesPlayed)),
        wins: Math.max(0, Math.round(manager.careerStats.wins)),
        draws: Math.max(0, Math.round(manager.careerStats.draws)),
        losses: Math.max(0, Math.round(manager.careerStats.losses)),
        goalsFor: Math.max(0, Math.round(manager.careerStats.goalsFor)),
        goalsAgainst: Math.max(0, Math.round(manager.careerStats.goalsAgainst)),
      },
      createdAt: existingSnap.exists() ? existingSnap.data().createdAt : serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    await setDoc(ref, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function loadCloudSaves(uid: string): Promise<CloudSaveRecord[]> {
  const path = `users/${uid}/saves`;
  try {
    const q = query(collection(db, 'users', uid, 'saves'), where('ownerId', '==', uid));
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as CloudSaveRecord);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function syncCloudLeaderboard(params: {
  uid: string;
  managerName: string;
  clubName: string;
  clubColor: string;
  platform: Platform;
  eloRating: number;
  wins: number;
  draws: number;
  losses: number;
  goalsScored: number;
  trophiesWon: number;
}): Promise<void> {
  const path = `leaderboards/${params.uid}`;
  const ref = doc(db, 'leaderboards', params.uid);
  try {
    const existingSnap = await getDoc(ref);
    await setDoc(ref, {
      entryId: params.uid,
      ownerId: params.uid,
      managerName: params.managerName.slice(0, 64) || 'Manager',
      clubName: params.clubName.slice(0, 64) || 'Club',
      clubColor: params.clubColor.slice(0, 16) || '#10B981',
      platform: params.platform,
      eloRating: Math.max(100, Math.min(4000, Math.round(params.eloRating))),
      wins: Math.max(0, Math.round(params.wins)),
      draws: Math.max(0, Math.round(params.draws)),
      losses: Math.max(0, Math.round(params.losses)),
      goalsScored: Math.max(0, Math.round(params.goalsScored)),
      trophiesWon: Math.max(0, Math.round(params.trophiesWon)),
      createdAt: existingSnap.exists() ? existingSnap.data().createdAt : serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function fetchCloudLeaderboard(): Promise<LeaderboardEntry[]> {
  const path = 'leaderboards';
  try {
    const q = query(
      collection(db, 'leaderboards'),
      where('eloRating', '>=', 100),
      orderBy('eloRating', 'desc'),
      limit(20)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        id: String(data.entryId || d.id),
        managerName: String(data.managerName || 'Manager'),
        clubName: String(data.clubName || 'Club'),
        clubColor: String(data.clubColor || '#10B981'),
        platform: (data.platform as Platform) || 'PC',
        eloRating: Number(data.eloRating || 1200),
        wins: Number(data.wins || 0),
        draws: Number(data.draws || 0),
        losses: Number(data.losses || 0),
        goalsScored: Number(data.goalsScored || 0),
        trophiesWon: Number(data.trophiesWon || 0),
      };
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}
