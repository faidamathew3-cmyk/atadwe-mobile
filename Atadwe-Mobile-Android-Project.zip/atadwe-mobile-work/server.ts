import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

// Initialize server-side Gemini client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured in environment secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

interface RoomPeer {
  id: string;
  name: string;
  clubId: string;
  clubName: string;
  platform: 'PC' | 'Console' | 'Mobile';
  role: 'home' | 'away' | 'spectator';
  voiceEnabled: boolean;
  ws: WebSocket;
}

interface MatchRoom {
  id: string;
  name: string;
  stadiumTheme: string;
  hostId: string;
  status: 'waiting' | 'playing';
  scoreHome: number;
  scoreAway: number;
  peers: Map<string, RoomPeer>;
  createdAt: number;
}

interface ChatRecord {
  id: string;
  channel: string;
  senderId: string;
  senderName: string;
  clubName: string;
  platform: 'PC' | 'Console' | 'Mobile';
  text: string;
  timestamp: number;
}

interface ServerLeaderboardRecord {
  id: string;
  managerName: string;
  clubName: string;
  clubColor: string;
  platform: 'PC' | 'Console' | 'Mobile';
  eloRating: number;
  wins: number;
  draws: number;
  losses: number;
  goalsScored: number;
  trophiesWon: number;
  updatedAt: number;
}

const rooms = new Map<string, MatchRoom>();
const globalChatHistory: ChatRecord[] = [];
const serverLeaderboard = new Map<string, ServerLeaderboardRecord>([
  [
    'seed_1',
    {
      id: 'seed_1',
      managerName: 'M. Arteta',
      clubName: 'Arsenal',
      clubColor: '#EF0107',
      platform: 'PC',
      eloRating: 1845,
      wins: 24,
      draws: 4,
      losses: 2,
      goalsScored: 68,
      trophiesWon: 2,
      updatedAt: Date.now() - 3600_000,
    },
  ],
  [
    'seed_2',
    {
      id: 'seed_2',
      managerName: 'C. Ancelotti',
      clubName: 'Real Madrid',
      clubColor: '#FEBE10',
      platform: 'Console',
      eloRating: 1890,
      wins: 26,
      draws: 3,
      losses: 1,
      goalsScored: 74,
      trophiesWon: 3,
      updatedAt: Date.now() - 1800_000,
    },
  ],
  [
    'seed_3',
    {
      id: 'seed_3',
      managerName: 'S. Inzaghi',
      clubName: 'Inter Milan',
      clubColor: '#010E80',
      platform: 'Mobile',
      eloRating: 1795,
      wins: 21,
      draws: 6,
      losses: 3,
      goalsScored: 59,
      trophiesWon: 1,
      updatedAt: Date.now() - 900_000,
    },
  ],
  [
    'seed_4',
    {
      id: 'seed_4',
      managerName: 'X. Alonso',
      clubName: 'Bayer Leverkusen',
      clubColor: '#E32221',
      platform: 'PC',
      eloRating: 1820,
      wins: 23,
      draws: 5,
      losses: 2,
      goalsScored: 65,
      trophiesWon: 2,
      updatedAt: Date.now() - 600_000,
    },
  ],
]);

function serializeRoom(room: MatchRoom) {
  return {
    id: room.id,
    name: room.name,
    stadiumTheme: room.stadiumTheme,
    hostId: room.hostId,
    status: room.status,
    scoreHome: room.scoreHome,
    scoreAway: room.scoreAway,
    peers: Array.from(room.peers.values()).map((p) => ({
      id: p.id,
      name: p.name,
      clubId: p.clubId,
      clubName: p.clubName,
      platform: p.platform,
      role: p.role,
      voiceEnabled: p.voiceEnabled,
    })),
  };
}

function sendJson(ws: WebSocket, payload: unknown) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastAll(wss: WebSocketServer, payload: unknown) {
  const encoded = JSON.stringify(payload);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(encoded);
    }
  });
}

function broadcastRoom(room: MatchRoom, payload: unknown, excludePeerId?: string) {
  const encoded = JSON.stringify(payload);
  room.peers.forEach((peer) => {
    if (peer.id !== excludePeerId && peer.ws.readyState === WebSocket.OPEN) {
      peer.ws.send(encoded);
    }
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // --- API Routes ---
  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      rooms: rooms.size,
      clients: wss.clients.size,
      timestamp: Date.now(),
    });
  });

  app.get('/api/rooms', (_req, res) => {
    res.json({
      rooms: Array.from(rooms.values()).map(serializeRoom),
    });
  });

  app.get('/api/leaderboard', (_req, res) => {
    const entries = Array.from(serverLeaderboard.values()).sort(
      (a, b) => b.eloRating - a.eloRating
    );
    res.json({ entries });
  });

  app.post('/api/leaderboard', (req, res) => {
    const body = req.body as Partial<ServerLeaderboardRecord>;
    if (!body.id || !body.managerName || !body.clubName) {
      res.status(400).json({ error: 'Missing required leaderboard fields.' });
      return;
    }
    const record: ServerLeaderboardRecord = {
      id: String(body.id).slice(0, 64),
      managerName: String(body.managerName).slice(0, 48),
      clubName: String(body.clubName).slice(0, 48),
      clubColor: String(body.clubColor || '#10B981').slice(0, 16),
      platform:
        body.platform === 'Console' || body.platform === 'Mobile' ? body.platform : 'PC',
      eloRating: Math.max(100, Math.min(4000, Math.round(Number(body.eloRating) || 1200))),
      wins: Math.max(0, Math.round(Number(body.wins) || 0)),
      draws: Math.max(0, Math.round(Number(body.draws) || 0)),
      losses: Math.max(0, Math.round(Number(body.losses) || 0)),
      goalsScored: Math.max(0, Math.round(Number(body.goalsScored) || 0)),
      trophiesWon: Math.max(0, Math.round(Number(body.trophiesWon) || 0)),
      updatedAt: Date.now(),
    };
    serverLeaderboard.set(record.id, record);
    const entries = Array.from(serverLeaderboard.values()).sort(
      (a, b) => b.eloRating - a.eloRating
    );
    broadcastAll(wss, { type: 'leaderboard:update', entries });
    res.json({ record, entries });
  });

  // Server-Side Gemini AI Coaching: Tactical & Squad Analysis
  app.post('/api/coach/analyze', async (req, res) => {
    try {
      const ai = getGeminiClient();
      const {
        clubName,
        leagueName,
        formation,
        mentality,
        pressing,
        passingStyle,
        teamOvr,
        avgStamina,
        transferBudget,
        opponentName,
        opponentOvr,
        opponentFormation,
        matchMinute,
        scoreHome,
        scoreAway,
        isLiveMatch,
      } = req.body ?? {};

      const prompt = `You are the elite Tactical Director & Assistant Manager for ${clubName || 'the club'} (${leagueName || 'Top Division'}).
Current Setup:
- Formation: ${formation || '4-3-3'}, Mentality: ${mentality || 'Balanced'}, Pressing: ${pressing || 'Mid Press'}, Passing: ${passingStyle || 'Balanced'}
- Squad OVR: ${teamOvr || 82}, Avg Stamina: ${avgStamina || 88}%, Transfer Budget: €${Math.round((Number(transferBudget) || 50000000) / 1000000)}M
- Opponent: ${opponentName || 'League Rival'} (OVR ${opponentOvr || 81}, Formation ${opponentFormation || '4-2-3-1'})
${isLiveMatch ? `- LIVE MATCH STATE: Minute ${matchMinute || 1}', Score ${scoreHome ?? 0} - ${scoreAway ?? 0}` : '- Pre-match & weekly club planning briefing.'}

Provide actionable, crisp football coaching advice tailored to this exact scenario.`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'You are a world-class UEFA Pro License tactical football coach. Keep summaries concise, punchy, and grounded in modern football tactics (half-spaces, gegenpressing, rest defense, transitions).',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              headline: { type: Type.STRING },
              tacticalSummary: { type: Type.STRING },
              recommendedFormation: {
                type: Type.STRING,
                enum: ['4-3-3', '4-4-2', '4-2-3-1', '3-5-2', '5-3-2'],
              },
              recommendedMentality: {
                type: Type.STRING,
                enum: ['Ultra Defensive', 'Defensive', 'Balanced', 'Attacking', 'All-Out Attack'],
              },
              recommendedPressing: {
                type: Type.STRING,
                enum: ['Low Block', 'Mid Press', 'Gegenpress'],
              },
              recommendedPassing: {
                type: Type.STRING,
                enum: ['Direct', 'Balanced', 'Tiki-Taka'],
              },
              recommendedTrainingFocus: {
                type: Type.STRING,
                enum: [
                  'Finishing Drills',
                  'Tactical Rondo',
                  'Gym Conditioning',
                  'Sprint & Agility',
                  'Defensive Shape',
                  'Recovery Session',
                ],
              },
              keyInstructions: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              scoutingNote: { type: Type.STRING },
            },
            required: [
              'headline',
              'tacticalSummary',
              'recommendedFormation',
              'recommendedMentality',
              'recommendedPressing',
              'recommendedPassing',
              'recommendedTrainingFocus',
              'keyInstructions',
              'scoutingNote',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim());
      res.json({ analysis: parsed });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : 'Failed to reach AI Coaching service.';
      console.error('Gemini coach analyze error:', message);
      res.status(500).json({ error: message });
    }
  });

  // Server-Side Gemini AI Coaching: Interactive Chat
  app.post('/api/coach/chat', async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { message, context } = req.body ?? {};
      if (!message || typeof message !== 'string') {
        res.status(400).json({ error: 'Coach message is required.' });
        return;
      }

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Club Context: ${JSON.stringify(context || {})}\n\nManager Question: ${message}`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'You are the Chief Tactical Analyst and Assistant Manager in APEX XI. Give concise, practical football management advice (under 140 words) covering formations, pressing triggers, training, gym conditioning, and transfer strategy.',
        },
      });

      res.json({ reply: response.text || 'Hold compact lines and exploit the half-spaces on transition.' });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : 'Failed to reach AI Coach chat.';
      console.error('Gemini coach chat error:', message);
      res.status(500).json({ error: message });
    }
  });

  // --- WebSocket Multiplayer, Chat & WebRTC Voice Signaling ---
  wss.on('connection', (ws) => {
    let peerId = `peer_${Math.random().toString(36).slice(2, 10)}`;
    let currentRoomId: string | null = null;

    sendJson(ws, {
      type: 'connected',
      peerId,
      rooms: Array.from(rooms.values()).map(serializeRoom),
      chatHistory: globalChatHistory.slice(-40),
    });

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(String(raw));
        if (!msg || typeof msg.type !== 'string') return;

        if (msg.type === 'room:create') {
          const roomId = `match_${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
          const room: MatchRoom = {
            id: roomId,
            name: String(msg.roomName || `${msg.clubName || 'Club'} Arena`).slice(0, 40),
            stadiumTheme: String(msg.stadiumTheme || 'night_floodlights'),
            hostId: peerId,
            status: 'waiting',
            scoreHome: 0,
            scoreAway: 0,
            peers: new Map(),
            createdAt: Date.now(),
          };
          const peer: RoomPeer = {
            id: peerId,
            name: String(msg.playerName || 'Manager').slice(0, 32),
            clubId: String(msg.clubId || 'arsenal'),
            clubName: String(msg.clubName || 'Arsenal'),
            platform:
              msg.platform === 'Console' || msg.platform === 'Mobile' ? msg.platform : 'PC',
            role: 'home',
            voiceEnabled: Boolean(msg.voiceEnabled),
            ws,
          };
          room.peers.set(peerId, peer);
          rooms.set(roomId, room);
          currentRoomId = roomId;

          sendJson(ws, { type: 'room:joined', room: serializeRoom(room), peerId });
          broadcastAll(wss, {
            type: 'rooms:list',
            rooms: Array.from(rooms.values()).map(serializeRoom),
          });
          return;
        }

        if (msg.type === 'room:join') {
          const room = rooms.get(String(msg.roomId));
          if (!room) {
            sendJson(ws, { type: 'error', message: 'Match room not found.' });
            return;
          }
          if (currentRoomId && currentRoomId !== room.id) {
            const old = rooms.get(currentRoomId);
            old?.peers.delete(peerId);
            if (old && old.peers.size === 0) rooms.delete(old.id);
          }

          const hasAway = Array.from(room.peers.values()).some((p) => p.role === 'away');
          const role = !hasAway ? 'away' : 'spectator';

          const peer: RoomPeer = {
            id: peerId,
            name: String(msg.playerName || 'Challenger').slice(0, 32),
            clubId: String(msg.clubId || 'real_madrid'),
            clubName: String(msg.clubName || 'Real Madrid'),
            platform:
              msg.platform === 'Console' || msg.platform === 'Mobile' ? msg.platform : 'PC',
            role,
            voiceEnabled: Boolean(msg.voiceEnabled),
            ws,
          };
          room.peers.set(peerId, peer);
          if (role === 'away') room.status = 'playing';
          currentRoomId = room.id;

          sendJson(ws, { type: 'room:joined', room: serializeRoom(room), peerId });
          broadcastRoom(room, { type: 'room:updated', room: serializeRoom(room) });
          broadcastAll(wss, {
            type: 'rooms:list',
            rooms: Array.from(rooms.values()).map(serializeRoom),
          });
          return;
        }

        if (msg.type === 'room:leave') {
          if (currentRoomId) {
            const room = rooms.get(currentRoomId);
            if (room) {
              room.peers.delete(peerId);
              if (room.peers.size === 0) {
                rooms.delete(room.id);
              } else {
                if (room.hostId === peerId) {
                  const first = room.peers.values().next().value;
                  if (first) {
                    room.hostId = first.id;
                    first.role = 'home';
                  }
                }
                broadcastRoom(room, { type: 'room:updated', room: serializeRoom(room) });
              }
            }
            currentRoomId = null;
            sendJson(ws, { type: 'room:left' });
            broadcastAll(wss, {
              type: 'rooms:list',
              rooms: Array.from(rooms.values()).map(serializeRoom),
            });
          }
          return;
        }

        if (msg.type === 'match:snapshot' && currentRoomId) {
          const room = rooms.get(currentRoomId);
          if (!room) return;
          if (typeof msg.scoreHome === 'number') room.scoreHome = msg.scoreHome;
          if (typeof msg.scoreAway === 'number') room.scoreAway = msg.scoreAway;
          broadcastRoom(
            room,
            {
              type: 'match:snapshot',
              fromPeerId: peerId,
              snapshot: msg.snapshot,
              scoreHome: room.scoreHome,
              scoreAway: room.scoreAway,
            },
            peerId
          );
          return;
        }

        if (msg.type === 'match:input' && currentRoomId) {
          const room = rooms.get(currentRoomId);
          if (!room) return;
          broadcastRoom(
            room,
            {
              type: 'match:input',
              fromPeerId: peerId,
              input: msg.input,
            },
            peerId
          );
          return;
        }

        if (msg.type === 'chat:send') {
          const record: ChatRecord = {
            id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            channel: String(msg.channel || 'global').slice(0, 32),
            senderId: peerId,
            senderName: String(msg.senderName || 'Manager').slice(0, 32),
            clubName: String(msg.clubName || 'Free Agent').slice(0, 32),
            platform:
              msg.platform === 'Console' || msg.platform === 'Mobile' ? msg.platform : 'PC',
            text: String(msg.text || '').slice(0, 280),
            timestamp: Date.now(),
          };
          if (!record.text.trim()) return;

          if (record.channel === 'global') {
            globalChatHistory.push(record);
            if (globalChatHistory.length > 80) globalChatHistory.shift();
            broadcastAll(wss, { type: 'chat:message', message: record });
          } else if (currentRoomId) {
            const room = rooms.get(currentRoomId);
            if (room) {
              broadcastRoom(room, { type: 'chat:message', message: record });
            }
          }
          return;
        }

        // WebRTC Voice Chat Signaling & Status
        if (msg.type === 'voice:status' && currentRoomId) {
          const room = rooms.get(currentRoomId);
          const peer = room?.peers.get(peerId);
          if (room && peer) {
            peer.voiceEnabled = Boolean(msg.enabled);
            broadcastRoom(room, { type: 'room:updated', room: serializeRoom(room) });
            if (peer.voiceEnabled) {
              broadcastRoom(room, { type: 'voice:peer-ready', peerId }, peerId);
            }
          }
          return;
        }

        if (msg.type === 'voice:signal' && currentRoomId && msg.targetPeerId) {
          const room = rooms.get(currentRoomId);
          const target = room?.peers.get(String(msg.targetPeerId));
          if (target) {
            sendJson(target.ws, {
              type: 'voice:signal',
              fromPeerId: peerId,
              signal: msg.signal,
            });
          }
          return;
        }
      } catch {
        // Ignore malformed websocket frames
      }
    });

    ws.on('close', () => {
      if (currentRoomId) {
        const room = rooms.get(currentRoomId);
        if (room) {
          room.peers.delete(peerId);
          if (room.peers.size === 0) {
            rooms.delete(room.id);
          } else {
            if (room.hostId === peerId) {
              const first = room.peers.values().next().value;
              if (first) {
                room.hostId = first.id;
                first.role = 'home';
              }
            }
            broadcastRoom(room, { type: 'room:updated', room: serializeRoom(room) });
          }
          broadcastAll(wss, {
            type: 'rooms:list',
            rooms: Array.from(rooms.values()).map(serializeRoom),
          });
        }
      }
    });
  });

  // --- Vite / Static Frontend Serving ---
  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`APEX XI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
