import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.atadwe.mobile',
  appName: 'Atadwe Mobile',
  webDir: 'dist',
  server: {
    // Loads the deployed Atadwe Mobile web app so its server-side features remain available.
    url: 'https://ais-dev-ob6q4wgywpzcrfo3mvwwfg-1010900347829.europe-west2.run.app/',
    cleartext: false
  }
};

export default config;
