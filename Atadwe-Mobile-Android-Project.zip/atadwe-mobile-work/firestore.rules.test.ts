// Security Rules Unit Verification Specification (Dirty Dozen Assertions)
// Note: Executed conceptually against DRAFT_firestore.rules & validated with ESLint security-rules plugin.

export interface DirtyDozenCase {
  name: string;
  path: string;
  operation: 'create' | 'update' | 'get' | 'list' | 'delete';
  authUid: string | null;
  emailVerified: boolean;
  payload?: Record<string, unknown>;
  expected: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_PAYLOADS: DirtyDozenCase[] = [
  {
    name: '1. Unauthenticated profile write',
    path: '/users/user_1',
    operation: 'create',
    authUid: null,
    emailVerified: false,
    payload: { uid: 'user_1', displayName: 'Anon', platform: 'PC', activeClubId: 'arsenal' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '2. Unverified email leaderboard write',
    path: '/leaderboards/user_1',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: false,
    payload: { entryId: 'user_1', ownerId: 'user_1', managerName: 'Test', eloRating: 1200 },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '3. Identity spoofing on profile creation',
    path: '/users/user_2',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: true,
    payload: { uid: 'user_2', displayName: 'Spoofer', platform: 'PC', activeClubId: 'arsenal' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '4. Shadow field injection (isAdmin)',
    path: '/users/user_1',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: true,
    payload: { uid: 'user_1', displayName: 'User', platform: 'PC', activeClubId: 'arsenal', isAdmin: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '5. Orphaned cloud save without parent user profile',
    path: '/users/user_1/saves/slot_1',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: true,
    payload: { saveId: 'slot_1', ownerId: 'user_1', slotName: 'Career 1' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '6. Cross-user save read',
    path: '/users/user_1/saves/slot_1',
    operation: 'get',
    authUid: 'user_2',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '7. Immortal field tampering (ownerId change)',
    path: '/users/user_1/saves/slot_1',
    operation: 'update',
    authUid: 'user_1',
    emailVerified: true,
    payload: { ownerId: 'user_2' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '8. Timestamp spoofing (non-request.time)',
    path: '/users/user_1',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: true,
    payload: { uid: 'user_1', displayName: 'User', platform: 'PC', activeClubId: 'arsenal', createdAt: '2020-01-01', updatedAt: '2020-01-01' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '9. Oversized string poisoning',
    path: '/users/user_1/saves/slot_1',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: true,
    payload: { saveId: 'slot_1', ownerId: 'user_1', slotName: 'A'.repeat(200) },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '10. Unbounded array injection (>30 squadIds)',
    path: '/users/user_1/saves/slot_1',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: true,
    payload: { saveId: 'slot_1', ownerId: 'user_1', squadIds: Array.from({ length: 45 }, (_, i) => `p_${i}`) },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '11. Leaderboard cross-user hijack',
    path: '/leaderboards/user_2',
    operation: 'update',
    authUid: 'user_1',
    emailVerified: true,
    payload: { eloRating: 9999 },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '12. Invalid platform enum',
    path: '/users/user_1',
    operation: 'create',
    authUid: 'user_1',
    emailVerified: true,
    payload: { uid: 'user_1', displayName: 'User', platform: 'GameBoy', activeClubId: 'arsenal' },
    expected: 'PERMISSION_DENIED',
  }
];
