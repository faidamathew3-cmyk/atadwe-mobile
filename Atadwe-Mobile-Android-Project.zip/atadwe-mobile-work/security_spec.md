# Security Specification — APEX XI

## 1. Data Invariants
1. A `UserProfile` document at `/users/{userId}` may only be created, read, or updated by the verified authenticated user whose `request.auth.uid == userId`. No PII (email, phone) is stored in public collections.
2. A `CloudSave` document at `/users/{userId}/saves/{saveId}` must belong to an existing parent `/users/{userId}` document (Master Gate) and `ownerId` must equal `request.auth.uid` and remain immutable on updates.
3. A `LeaderboardEntry` document at `/leaderboards/{entryId}` is readable by any user for global rankings, but `create` and `update` require verified email authentication, strict `ownerId == request.auth.uid`, bounded stat increments, and `entryId == request.auth.uid`.
4. All document IDs (`userId`, `saveId`, `entryId`) must match `^[a-zA-Z0-9_\-]+$` and be `<= 128` chars.
5. All `createdAt` and `updatedAt` timestamps must strictly equal `request.time`.

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated Write**: Creating `/users/u1` with `request.auth == null` -> `PERMISSION_DENIED`.
2. **Unverified Email Write**: Creating `/leaderboards/u1` with `email_verified == false` -> `PERMISSION_DENIED`.
3. **Identity Spoofing on Profile**: User `u1` creating `/users/u2` or setting `uid: "u2"` -> `PERMISSION_DENIED`.
4. **Shadow Field Injection**: Creating `/users/u1` with extra field `isAdmin: true` -> `PERMISSION_DENIED`.
5. **Orphaned Save Creation**: Creating `/users/u1/saves/slot1` when `/users/u1` does not exist -> `PERMISSION_DENIED`.
6. **Cross-User Save Read/List**: User `u2` reading or listing `/users/u1/saves` -> `PERMISSION_DENIED`.
7. **Immortal Field Tampering**: Updating `CloudSave.ownerId` or `CloudSave.createdAt` -> `PERMISSION_DENIED`.
8. **Timestamp Spoofing**: Sending client-supplied past timestamp instead of `request.time` -> `PERMISSION_DENIED`.
9. **Oversized String Poisoning**: Sending `slotName` with 500 chars -> `PERMISSION_DENIED`.
10. **Unbounded Array Injection**: Sending `squadIds` with 50 items (max 30) -> `PERMISSION_DENIED`.
11. **Leaderboard Spoofing**: User `u1` updating `/leaderboards/u2` -> `PERMISSION_DENIED`.
12. **Invalid Enum Value**: Setting `platform: "GameBoy"` or `formation: "1-1-8"` -> `PERMISSION_DENIED`.
